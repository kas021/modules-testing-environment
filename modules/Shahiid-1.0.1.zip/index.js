(() => {
  'use strict';

  const MODULE_NAME = 'Shahiid';
  const SITE = 'https://shahiid-anime.net';
  const MEGAMAX = 'https://megamax.me';
  const MAX_EPISODES = 5000;

  // Homepage snapshot so Home is never empty when Cloudflare blocks the first
  // request. Live pagev2 HTML is always preferred when available.
  const SEED_HOME = {"episodes":[{"href":"episodes/%d8%a3%d9%86%d9%85%d9%8a-katainaka-no-ossan-kensei-ni-naru-ii-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%ab%d8%a7%d9%86%d9%8a-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-5-%d9%85%d8%aa%d8%b1%d8%ac","title":"أنمي Katainaka no Ossan, Kensei ni Naru II الموسم الثاني مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157173l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/heroine-seijo-iie-all-works-maid-desu-hokori-7","title":"أنمي Heroine? Seijo? Iie, All Works Maid desu (Hokori)! مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158290l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/youjo-senki-s2-ep-5","title":"أنمي Youjo Senki II الموسم الثاني مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158371l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/clevatess-s2-ep-5","title":"أنمي Clevatess II: Majuu no Ou to Itsuwari no Yuusha Denshou الموسم الثاني مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157105l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/quanzhi-fashi-s7-ep-12-end","title":"أونا Quanzhi Fashi VII الموسم السابع مترجمة","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157370l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/kimi-ga-shinu-made-koi-wo-shitai-5","title":"أنمي Kimi ga Shinu made Koi wo Shitai مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158429l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/world-is-dancing-6","title":"أنمي World Is Dancing مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158709l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/sora-wa-akai-kawa-no-hotori-5","title":"أنمي Sora wa Akai Kawa no Hotori مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158138l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/%d8%a3%d9%86%d9%85%d9%8a-tefuda-ga-oome-no-victoria-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-5-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9","title":"أنمي Tefuda ga Oome no Victoria مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158743l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/%d8%a3%d9%86%d9%85%d9%8a-koukaku-kidoutai-tv-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-5-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9","title":"أنمي Koukaku Kidoutai (TV) مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158937l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/mujikaku-seijo-wa-kyou-mo-muishiki-ni-chikara-wo-tare-nagasu-6","title":"أنمي Mujikaku Seijo wa Kyou mo Muishiki ni Chikara wo Tare Nagasu مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158373l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/tai-ari-deshita-ojousama-wa-kakutou-game-nante-shinai-5","title":"أنمي Tai-Ari deshita. Ojousama wa Kakutou Game nante Shinai مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/156268l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/bai-ri-cheng-wang-13","title":"أونا Bai Ri Cheng Wang مترجمة","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158621l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/grand-blue-season-3-ep-5","title":"أنمي Grand Blue Season 3 الموسم الثالث مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158194l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/tenkou-saki-no-seiso-karen-na-bishoujo-ga-mukashi-danshi-to-omotte-issho-ni-asonda-osananajimi-datta-ken-5","title":"أنمي Tenkou-saki no Seiso Karen na Bishoujo ga, Mukashi Danshi to Omotte Issho ni Asonda Osananajimi","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158564l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/buchigire-reijou-wa-houfuku-wo-chikaimashita-madousho-no-chikara-de-sokoku-wo-tatakitsubushimasu-5","title":"أنمي Buchigire Reijou wa Houfuku wo Chikaimashita. Madousho no Chikara de Sokoku wo Tatakitsubushima","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157170l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/saikyou-degarashi-ouji-no-anyaku-teii-arasoi-5","title":"أنمي Saikyou Degarashi Ouji no Anyaku Teii Arasoi مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158522l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/%d8%a3%d9%86%d9%85%d9%8a-gaikotsu-kishi-sama-tadaima-isekai-e-odekakechuu-ii-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%ab%d8%a7%d9%86%d9%8a-%d8%a7%d9%84%d8%ad%d9%84%d9%82%d8%a9-5-%d9%85","title":"أنمي Gaikotsu Kishi-sama, Tadaima Isekai e Odekakechuu II الموسم الثاني مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157046l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/toumei-na-yoru-ni-kakeru-kimi-to-me-ni-mienai-koi-wo-shita-5","title":"أنمي Toumei na Yoru ni Kakeru Kimi to, Me ni Mienai Koi wo Shita. مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158339l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/one-piece-1172","title":"أنمي One Piece مترجم الملصق الرسمي","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/filters_quality95formatwebp-4.webp?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/digimon-beatbreak-41","title":"أنمي Digimon Beatbreak مترجم الملصق الرسمي","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/151242l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/azur-lane-bisoku-zenshin-ni-5","title":"الملصق الرسمي لأنمي Azur Lane: Bisoku Zenshin! Ni!! مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158715l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/%d8%a3%d9%88%d9%86%d8%a7-boku-no-hero-academia-i-am-a-hero-too-%d9%85%d8%aa%d8%b1%d8%ac%d9%85%d8%a9","title":"Boku no Hero Academia: I Am a Hero Too","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157239l.jpg?resize=200%2C283&ssl=1","kind":"episodes"},{"href":"episodes/futsutsuka-na-akujo-dewa-gozaimasu-ga-suuguu-chouso-torikae-den-4","title":"الملصق الرسمي لأنمي Futsutsuka na Akujo dewa Gozaimasu ga: Suuguu Chouso Torikae Den مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158341l.jpg?resize=200%2C283&ssl=1","kind":"episodes"}],"seasons":[{"href":"seasons/%d8%a3%d9%86%d9%85%d9%8a-tensei-shitara-slime-datta-ken-4th-season-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%b1%d8%a7%d8%a8%d8%b9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي Tensei shitara Slime Datta Ken 4th Season مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/155735l.jpg?resize=350%2C496&ssl=1","kind":"seasons"},{"href":"seasons/%d8%a3%d9%86%d9%85%d9%8a-rezero-kara-hajimeru-isekai-seikatsu-4th-season-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%b1%d8%a7%d8%a8%d8%b9-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي Re:Zero kara Hajimeru Isekai Seikatsu الموسم الرابع مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/155824l.jpg?resize=350%2C496&ssl=1","kind":"seasons"},{"href":"seasons/%d9%88%d9%86-%d8%a8%d9%8a%d8%b3-one-piece-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي One Piece مترجم الملصق الرسمي","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/filters_quality95formatwebp-4.webp?resize=240%2C360&ssl=1","kind":"seasons"},{"href":"seasons/%d8%a3%d9%86%d9%85%d9%8a-bleach-sennen-kessen-hen-kashin-tan-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي Bleach: Sennen Kessen-hen - Kashin-tan مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158595l.jpg?resize=350%2C496&ssl=1","kind":"seasons"},{"href":"seasons/%d8%a3%d9%86%d9%85%d9%8a-mushoku-tensei-iii-isekai-ittara-honki-dasu-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%ab%d8%a7%d9%84%d8%ab-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي Mushoku Tensei III: Isekai Ittara Honki Dasu الموسم الثالث مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158340l.jpg?resize=350%2C496&ssl=1","kind":"seasons"},{"href":"seasons/%d8%a3%d9%86%d9%85%d9%8a-youjo-senki-ii-%d8%a7%d9%84%d9%85%d9%88%d8%b3%d9%85-%d8%a7%d9%84%d8%ab%d8%a7%d9%86%d9%8a-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"أنمي Youjo Senki II الموسم الثاني مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158371l.jpg?resize=350%2C496&ssl=1","kind":"seasons"},{"href":"series/star-wars-visions-presents-the-ninth-jedi-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"ONA","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158843l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/mebius-dust","title":"أنمي Mebius Dust مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158352l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/thunder-3","title":"أنمي Thunder 3 مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158946l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/migawari-reijou-wo-sukutta-no-wa-reikoku-mujihi-na-koori-no-ouji-no-ai-deshita","title":"أنمي Migawari Reijou wo Sukutta no wa Reikoku Mujihi na Koori no Ouji no Ai deshita مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157799l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/tetsunabe-no-jan","title":"أنمي Tetsunabe no Jan! مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158686l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/lets-go-kaiki-gumi","title":"أنمي Let's Go Kaiki-gumi مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158581l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/%d9%86%d8%a7%d8%b1%d9%88%d8%aa%d9%88-naruto-%d8%a7%d9%84%d8%ac%d8%b2%d8%a1-1-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"مسلسل ناروتو Naruto مدبلج كامل مترجم 2007 أكشن، المغامرة، فنون الدفاع عن النفس، قوى خارقة، كوميدي، م","image":"https://shahiid-anime.net/wp-content/uploads/cat_1405905015.jpg","kind":"series"},{"href":"seasons/%d9%86%d8%a7%d8%b1%d9%88%d8%aa%d9%88-naruto-%d8%a7%d9%84%d8%ac%d8%b2%d8%a1-3-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"ناروتو Naruto الجزء 3 مدبلج","image":"https://shahiid-anime.net/wp-content/uploads/nglish-bfdbxd.jpg","kind":"seasons"},{"href":"seasons/%d9%86%d8%a7%d8%b1%d9%88%d8%aa%d9%88-naruto-%d8%a7%d9%84%d8%ac%d8%b2%d8%a1-2-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"ناروتو Naruto الجزء 2 مدبلج","image":"https://shahiid-anime.net/wp-content/uploads/78857-10.jpg","kind":"seasons"},{"href":"seasons/%d9%86%d8%a7%d8%b1%d9%88%d8%aa%d9%88-naruto-%d8%a7%d9%84%d8%ac%d8%b2%d8%a1-1-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"ناروتو Naruto الجزء 1 مدبلج","image":"https://shahiid-anime.net/wp-content/uploads/cat_1405905015.jpg","kind":"seasons"},{"href":"series/naruto-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"الملصق الرسمي لأنمي Naruto مترجم","image":"https://shahiid-anime.net/wp-content/uploads/142503l-200x283.jpg","kind":"series"},{"href":"series/naruto-shippuden-ova","title":"8.20","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/cartoon-naruto-shippuden-triangle-poster-AQU241075.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/naruto","title":"الملصق الرسمي لأنمي Naruto: Shippuuden مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/17331-1017292.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/%d8%a8%d9%88%d8%b1%d9%88%d8%aa%d9%88-boruto-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"الملصق الرسمي لأنمي Boruto: Naruto Next Generations مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/99847l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"seasons/%d8%a8%d9%88%d8%b1%d9%88%d8%aa%d9%88-boruto-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"الملصق الرسمي لأنمي Boruto: Naruto Next Generations مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/99847l.jpg?resize=200%2C283&ssl=1","kind":"seasons"},{"href":"seasons/naruto-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"الملصق الرسمي لأنمي Naruto مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/142503l.jpg?resize=200%2C283&ssl=1","kind":"seasons"},{"href":"seasons/%d8%ac%d9%85%d9%8a%d8%b9-%d8%ad%d9%84%d9%82%d8%a7%d8%aa-%d9%86%d8%a7%d8%b1%d9%88%d8%aa%d9%88-%d8%b4%d9%8a%d8%a8%d9%88%d8%af%d9%86-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9","title":"الملصق الرسمي لأنمي Naruto: Shippuuden مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/17331-1017292.jpg?resize=200%2C283&ssl=1","kind":"seasons"},{"href":"series/iwamoto-senpai-no-suisen","title":"الملصق الرسمي لأنمي Iwamoto-senpai no Suisen مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158450l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/hua-xianzi-mofa-xiang-dui-lun","title":"الملصق الرسمي لأونا Hua Xianzi: Mofa Xiang Dui Lun مترجمة","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158636l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/grow-up-show-himawari-no-circus-dan","title":"الملصق الرسمي لأنمي Grow Up Show: Himawari no Circus-dan مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158716l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/bai-ri-cheng-wang","title":"الملصق الرسمي لأونا Bai Ri Cheng Wang مترجمة","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/158621l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/uchi-no-otouto-domo-ga-sumimasen","title":"الملصق الرسمي لأنمي Uchi no Otouto-domo ga Sumimasen مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/156345l.jpg?resize=200%2C283&ssl=1","kind":"series"},{"href":"series/kore-kaite-shine","title":"الملصق الرسمي لأنمي Kore Kaite Shine مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/154997l.jpg?resize=200%2C283&ssl=1","kind":"series"}],"anime":[{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-kimetsu-no-yaiba-movie-mugen-jou-hen-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"فيلم Kimetsu no Yaiba Movie: Mugen Jou-hen مترجم الملصق الرسمي","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/148216.jpg?resize=225%2C318&ssl=1","kind":"anime"},{"href":"anime/tensei-shitara-slime-datta-ken-movie-2-soukai-no-namida-hen","title":"Tensei shitara Slime Datta Ken Movie 2: Soukai no Namida-hen مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/153665l.jpg?resize=350%2C496&ssl=1","kind":"anime"},{"href":"anime/shibou-yuugi-de-meshi-wo-kuu-44-cloudy-beach","title":"Shibou Yuugi de Meshi wo Kuu. 44: Cloudy Beach مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/157997l.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-zombieland-saga-movie-yumeginga-paradise-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"Zombieland Saga Movie: Yumeginga Paradise مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/151187l.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-ginga-tokkyuu-milky%e2%98%86subway-movie-kakueki-teisha-gekijou-yuki-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"Ginga Tokkyuu Milky☆Subway Movie مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/155303l.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-hateshinaki-scarlet-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"Hateshinaki Scarlet مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/150871l.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-madogiwa-no-totto-chan-%d8%a8%d9%84%d9%88%d8%b1%d8%a7%d9%8a-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"Madogiwa no Totto-chan مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/139067l.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-meitantei-conan-movie-20-junkoku-no-nightmare-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"Meitantei Conan Movie 20: Junkoku no Nightmare مدبلج","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/Image-Apr-14-2026-10_58_29-PM.png?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-meitantei-conan-movie-21-karakurenai-no-love-letter-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"Meitantei Conan Movie 21: Karakurenai no Love Letter مدبلج","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/Image-Apr-14-2026-11_41_39-PM.png?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-meitantei-conan-movie-22-zero-no-shikkounin-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"Meitantei Conan Movie 22: Zero no Shikkounin مدبلج","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/Image-Apr-14-2026-11_19_05-PM.png?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-meitantei-conan-movie-27-100-man-dollar-no-michishirube-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"Meitantei Conan Movie 27: 100-man Dollar no Michishirube مدبلج","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/Image-Apr-14-2026-09_21_55-PM.png?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-meitantei-conan-movie-19-gouka-no-himawari-%d9%85%d8%af%d8%a8%d9%84%d8%ac","title":"Meitantei Conan Movie 19: Gouka no Himawari مدبلج","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/Image-Apr-14-2026-11_09_11-PM.png?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/boruto-naruto-the-movie-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.79","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/78280.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/the-last-naruto-the-movie-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.79","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/67631.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/naruto-shippuuden-movie-6-road-to-ninja-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.79","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/51863.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/naruto-shippuuden-movie-5-blood-prison-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.58","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/41403.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/naruto-shippuuden-movie-4-the-lost-tower-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.52","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/23344.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/naruto-shippuuden-movie-1-%d9%85%d8%aa%d8%b1%d8%ac%d9%85-%d9%85%d8%b4%d8%a7%d9%87%d8%af%d8%a9-%d8%a3%d9%88%d9%86-%d9%84%d8%a7%d9%8a%d9%86%d8%aa%d8%ad%d9%85%d9%8a%d9%84","title":"7.40","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/79705.jpg?resize=200%2C283&ssl=1","kind":"anime"},{"href":"anime/%d9%81%d9%8a%d9%84%d9%85-virgin-punk-clockwork-girl-%d8%a8%d9%84%d9%88%d8%b1%d8%a7%d9%8a-%d9%85%d8%aa%d8%b1%d8%ac%d9%85","title":"الملصق الرسمي لفيلم Virgin Punk: Clockwork Girl مترجم","image":"https://i0.wp.com/shahiid-anime.net/wp-content/uploads/148690l.jpg?resize=200%2C283&ssl=1","kind":"anime"}]};

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  function isCloudflareHtml(html) {
    const s = String(html || '');
    return /Just a moment/i.test(s) || /security verification/i.test(s) ||
      /cf-browser-verification/i.test(s) || /Enable JavaScript and cookies/i.test(s);
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        const value = await res.json();
        return JSON.stringify(value);
      } catch (_) {}
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        let contentType = String((res && res.contentType) || '');
        if (!contentType && res && res.headers && typeof res.headers === 'object') {
          contentType = String(res.headers['content-type'] || res.headers['Content-Type'] || '');
        }
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          body: textBody,
          json: safeJsonParse(textBody),
          contentType,
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
          contentType: String((res.headers && res.headers.get) ? res.headers.get('content-type') || '' : ''),
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null, contentType: '' };
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  // pagev2 can clear CF on-device if settle is long enough. Retries help.
  async function fetchShahiidPage(url, waitForSelector) {
    const target = String(url || SITE + '/');

    if (typeof pagev2 === 'function') {
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const result = await pagev2({
            url: target,
            timeoutMs: 45000,
            settleMs: 4500 + attempt * 1500,
            includeHtml: true,
            userAgent: USER_AGENT,
            waitForSelector: waitForSelector ||
              'a[href*="/anime/"], a[href*="/episodes/"], a[href*="/seasons/"], .wrap-poster, img.wp-post-image',
          });
          const html = String((result && result.html) || '');
          if (html.length > 5000 && !isCloudflareHtml(html)) {
            log('pagev2 ok attempt=' + (attempt + 1) + ' len=' + html.length);
            return html;
          }
          log('pagev2 CF/empty attempt=' + (attempt + 1) + ' len=' + html.length);
        } catch (e) {
          log('pagev2 failed attempt=' + (attempt + 1) + ': ' + (e && e.message ? e.message : String(e)));
        }
        await sleep(600 * (attempt + 1));
      }
    }

    const res = await settleWithin(
      request(target, {
        headers: {
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
          Referer: SITE + '/',
        },
      }),
      15000,
      null,
    );
    if (!res || !res.ok || !res.body || isCloudflareHtml(res.body)) return null;
    return res.body;
  }

  function absoluteUrl(pathOrUrl) {
    const raw = String(pathOrUrl || '').trim();
    if (!raw) return SITE + '/';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('/')) return SITE + raw;
    return SITE + '/' + raw.replace(/^\/+/, '');
  }

  function normalizeHref(pathOrUrl) {
    let raw = String(pathOrUrl || '').trim();
    if (!raw) return '';
    raw = raw.replace(/^https?:\/\/shahiid-anime\.net\//i, '').replace(/^\/+/, '').replace(/\/$/, '');
    return raw;
  }

  async function megamaxStreams(hashId) {
    const iframeUrl = MEGAMAX + '/iframe/' + encodeURIComponent(hashId);
    const page = await settleWithin(
      request(iframeUrl, { headers: { Accept: 'text/html,*/*' } }),
      15000,
      null,
    );
    if (!page || !page.ok || !page.body) return [];
    const versionMatch = page.body.match(/"version":"([^"]+)"/);
    const componentMatch = page.body.match(/"component":"([^"]+)"/);
    if (!versionMatch || !componentMatch) return [];
    const version = versionMatch[1];
    const component = String(componentMatch[1]).replace(/\\\//g, '/');

    const streamsRes = await settleWithin(
      request(iframeUrl + '?prop=streams', {
        headers: {
          Accept: 'text/html, application/xhtml+xml',
          'X-Inertia': 'true',
          'X-Inertia-Version': version,
          'X-Inertia-Partial-Component': component,
          'X-Inertia-Partial-Data': 'streams,subtitles',
          Referer: iframeUrl,
        },
      }),
      15000,
      null,
    );
    if (!streamsRes || !streamsRes.ok) return [];
    const envelope = streamsRes.json || safeJsonParse(streamsRes.body);
    if (!envelope || !envelope.props || !envelope.props.streams) return [];
    const streams = envelope.props.streams;
    if (!streams || streams.status !== 'success' || !Array.isArray(streams.data)) return [];
    const mirrors = [];
    for (const item of streams.data) {
      const itemMirrors = Array.isArray(item.mirrors) ? item.mirrors : [];
      for (const mir of itemMirrors) {
        mirrors.push({
          driver: String(mir.driver || ''),
          link: String(mir.link || ''),
          hashId: String(item.hashId || ''),
          resolution: String(item.resolution || item.label || ''),
        });
      }
    }
    return mirrors;
  }

  function unpackPacked(script) {
    const m = script.match(/function\(p,a,c,k,e,d\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)',(.*?)\)\)/s);
    if (!m) return null;
    const p = m[1];
    const a = Number(m[2]);
    const c = Number(m[3]);
    const k = (m[4] || '').split('|');
    const digits = '0123456789abcdefghijklmnopqrstuvwxyz';
    function radix(n) {
      if (n === 0) return '0';
      let out = '';
      while (n) { out = digits[n % a] + out; n = Math.floor(n / a); }
      return out;
    }
    let decoded = p;
    for (let i = c - 1; i >= 0; i--) {
      const token = radix(i);
      const word = k[i];
      if (word !== undefined && word !== '') {
        const re = new RegExp('\\b' + token + '\\b', 'g');
        decoded = decoded.replace(re, word);
      }
    }
    return decoded;
  }

  async function resolveLulustream(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000, null,
    );
    if (!res || !res.ok || !res.body) return '';
    const decoded = unpackPacked(res.body);
    const haystack = decoded || res.body;
    const m3u8 = haystack.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)["']/i);
    return (m3u8 && m3u8[1]) || '';
  }

  async function resolveVoe(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000, null,
    );
    if (!res || !res.ok || !res.body) return '';
    const m3u8 = res.body.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)["']/i);
    return (m3u8 && m3u8[1]) || '';
  }

  async function resolveStreamtape(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000, null,
    );
    if (!res || !res.ok || !res.body) return '';
    const mp4 = res.body.match(/https?:\/\/[^"'\s]*\.mp4[^"'\s]*/i);
    return (mp4 && mp4[0]) || '';
  }

  async function resolveMirrors(mirrors) {
    const streams = [];
    const seen = new Set();
    const ordered = [...mirrors].sort((a, b) => {
      const score = (m) => {
        const d = String(m.driver || '').toLowerCase();
        if (d === 'lulustream') return 0;
        if (d === 'voe') return 1;
        if (d === 'streamtape') return 2;
        return 9;
      };
      return score(a) - score(b);
    });
    for (const mir of ordered) {
      const driver = String(mir.driver || '').toLowerCase();
      let link = String(mir.link || '');
      if (!link) continue;
      if (link.startsWith('//')) link = 'https:' + link;
      if (!/^https?:/i.test(link)) continue;
      let url = '';
      if (driver === 'lulustream') url = await resolveLulustream(link);
      else if (driver === 'voe') url = await resolveVoe(link);
      else if (driver === 'streamtape') url = await resolveStreamtape(link);
      else continue;
      if (!url || seen.has(url)) continue;
      seen.add(url);
      const isHls = /\.m3u8/i.test(url);
      streams.push({
        label: 'Shahiid • ' + driver + (mir.resolution ? ' • ' + mir.resolution : ''),
        url: url,
        streamType: isHls ? 'hls' : 'mp4',
        kind: isHls ? 'hls' : 'mp4',
        provider: 'shahiid-' + driver,
        headers: {
          'User-Agent': USER_AGENT,
          Referer: link,
          Origin: (link.match(/^(https?:\/\/[^/]+)/i) || [])[1] || '',
        },
      });
      if (streams.length >= 4) break;
    }
    return streams;
  }

  function cleanTitle(raw) {
    let title = cleanText(raw || '');
    title = title
      .replace(/الملصق الرسمي ل(?:فيلم\s*)?/g, '')
      .replace(/،.*$/, '')
      .replace(/\b(?:Bluray|Web)\b/gi, '')
      .replace(/\b\d+\.\d+\b/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    return title.slice(0, 120);
  }

  function parseCatalogCards(html) {
    const items = [];
    const seen = new Set();
    const re = /<a\b[^>]*href="(https?:\/\/shahiid-anime\.net\/(?:anime|series|seasons|episodes|episodesDubbed|seriesDubbed)\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(html))) {
      const full = m[1];
      const inner = m[2] || '';
      if (/\/(anime|series|seasons|episodes|episodesDubbed|seriesDubbed)\/?$/i.test(full)) continue;
      const imgM = inner.match(/<img\b[^>]*(?:src|data-src|data-lazy-src)="([^"]+)"/i);
      if (!imgM) continue;
      let img = String(imgM[1] || '').replace(/&amp;/g, '&');
      if (img.startsWith('//')) img = 'https:' + img;
      if (!img || img.startsWith('data:')) continue;
      const path = normalizeHref(full);
      if (!path || seen.has(path)) continue;
      seen.add(path);
      const alt = (inner.match(/alt="([^"]+)"/i) || [])[1] || '';
      const text = inner.replace(/<[^>]+>/g, ' ');
      let title = cleanTitle(alt || text);
      if (!title || title.length < 2) {
        title = path.split('/').pop() || path;
        try { title = decodeURIComponent(title); } catch (_) {}
        title = title.replace(/-/g, ' ');
      }
      const kind = path.split('/')[0] || 'anime';
      items.push({ href: path, title: title, image: img, poster: img, kind: kind });
    }
    return items;
  }

  function seedCards() {
    const out = [];
    const groups = [SEED_HOME.episodes || [], SEED_HOME.seasons || [], SEED_HOME.anime || []];
    for (const group of groups) {
      for (const c of group) {
        out.push({
          href: c.href,
          title: c.title,
          image: c.image,
          poster: c.image,
          kind: c.kind,
        });
      }
    }
    return out;
  }

  function filterCards(items, query) {
    const q = cleanText(query).toLowerCase();
    if (!q) return items;
    const tokens = q.split(/\s+/).filter(Boolean);
    return items.filter((item) => {
      const hay = String(item.title || '').toLowerCase() + ' ' + String(item.href || '').toLowerCase();
      try {
        const decoded = decodeURIComponent(String(item.href || '')).toLowerCase();
        if (tokens.every((t) => hay.includes(t) || decoded.includes(t))) return true;
      } catch (_) {}
      return tokens.every((t) => hay.includes(t));
    });
  }

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      let items = [];
      if (q) {
        const html = await fetchShahiidPage(
          SITE + '/?s=' + encodeURIComponent(q),
          'a[href*="/anime/"], a[href*="/episodes/"], a[href*="/seasons/"]',
        );
        if (html) items = parseCatalogCards(html);
      } else {
        const html = await fetchShahiidPage(SITE + '/', '.wrap-poster, a[href*="/episodes/"]');
        if (html) items = parseCatalogCards(html);
      }
      if (!items.length) {
        items = filterCards(seedCards(), q);
        log('search seed fallback n=' + items.length);
      }
      return items.slice((pageNumber - 1) * 30, pageNumber * 30).map((c) => ({
        id: c.href,
        href: c.href,
        title: c.title,
        image: c.image,
        poster: c.image || c.poster,
      }));
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return filterCards(seedCards(), q).slice(0, 30).map((c) => ({
        id: c.href, href: c.href, title: c.title, image: c.image, poster: c.image,
      }));
    }
  }

  function extractMegamaxCodes(html) {
    const codes = [];
    const seen = new Set();
    const frameRe = /data-frameserver="([^"]+)"/g;
    let fm;
    while ((fm = frameRe.exec(html))) {
      const codeMatch = fm[1].match(/megamax\.me\/iframe\/([A-Za-z0-9]+)/);
      if (codeMatch && !seen.has(codeMatch[1])) {
        seen.add(codeMatch[1]);
        codes.push(codeMatch[1]);
      }
    }
    if (!codes.length) {
      const altRe = /megamax\.me\/iframe\/([A-Za-z0-9]+)/g;
      let am;
      while ((am = altRe.exec(html))) {
        if (!seen.has(am[1])) { seen.add(am[1]); codes.push(am[1]); }
      }
    }
    return codes;
  }

  function parseEpisodeLinks(html) {
    const eps = [];
    const seen = new Set();
    const re = /<a\b[^>]*href="(https?:\/\/shahiid-anime\.net\/(?:episodes|episodesDubbed)\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = re.exec(html))) {
      const full = m[1];
      if (/\/(episodes|episodesDubbed)\/?$/i.test(full)) continue;
      const path = normalizeHref(full);
      if (!path || seen.has(path)) continue;
      seen.add(path);
      const inner = m[2] || '';
      const text = cleanText(inner.replace(/<[^>]+>/g, ' '));
      const numMatch =
        text.match(/(\d{1,4})/) ||
        path.match(/(?:ep|episode|الحلقة)[-_\s]?(\d{1,4})/i) ||
        path.match(/-(\d{1,4})(?:-|$)/);
      const number = numMatch ? Number(numMatch[1]) : eps.length + 1;
      eps.push({
        number: number,
        href: path,
        title: text || ('Episode ' + number),
        subAvailable: !/dubbed/i.test(path),
        dubAvailable: /dubbed|مدبلج/i.test(path + text),
      });
    }
    if (!eps.length) {
      const codes = extractMegamaxCodes(html);
      for (let i = 0; i < codes.length && i < MAX_EPISODES; i++) {
        eps.push({
          number: i + 1,
          href: 'megamax:' + codes[i],
          title: 'Episode ' + (i + 1),
          subAvailable: true,
          dubAvailable: false,
        });
      }
    }
    eps.sort((a, b) => (a.number || 0) - (b.number || 0));
    return eps.slice(0, MAX_EPISODES);
  }

  async function extractDetails(urlOrId) {
    const path = normalizeHref(urlOrId);
    if (!path) return { title: 'Unknown', description: '' };
    const seedHit = seedCards().find((c) => c.href === path);
    const html = await fetchShahiidPage(
      absoluteUrl(path) + '/',
      'meta[property="og:title"], h1, .wrap-poster',
    );
    if (!html) {
      return {
        title: (seedHit && seedHit.title) || path.split('/').pop() || path,
        description: '',
        image: (seedHit && seedHit.image) || '',
        href: path,
      };
    }
    const ogTitle = (html.match(/property="og:title" content="([^"]+)"/) || [])[1] || '';
    const ogDesc = (html.match(/property="og:description" content="([^"]+)"/) || [])[1] || '';
    const ogImage = (html.match(/property="og:image" content="([^"]+)"/) || [])[1] || '';
    const h1 = (html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '';
    return {
      title: cleanTitle(ogTitle || h1 || (seedHit && seedHit.title) || path),
      description: cleanText(ogDesc || ''),
      image: cleanText(ogImage || (seedHit && seedHit.image) || ''),
      href: path,
    };
  }

  async function extractEpisodes(seriesId) {
    const path = normalizeHref(seriesId);
    if (!path) return [];
    if (path.startsWith('megamax:')) {
      return [{ number: 1, href: path, title: 'Episode 1', subAvailable: true, dubAvailable: false }];
    }
    if (path.startsWith('episodes/') || path.startsWith('episodesDubbed/')) {
      const html = await fetchShahiidPage(absoluteUrl(path) + '/', '[data-frameserver], iframe, .server');
      if (!html) {
        return [{
          number: 1, href: path, title: 'Episode 1',
          subAvailable: true, dubAvailable: /dubbed|مدبلج/i.test(path),
        }];
      }
      const codes = extractMegamaxCodes(html);
      if (codes.length) {
        return codes.map((code, i) => ({
          number: i + 1,
          href: 'megamax:' + code,
          title: codes.length > 1 ? ('Server ' + (i + 1)) : 'Episode 1',
          subAvailable: true,
          dubAvailable: false,
        }));
      }
      return [{ number: 1, href: path, title: 'Episode 1', subAvailable: true, dubAvailable: false }];
    }

    const html = await fetchShahiidPage(absoluteUrl(path) + '/', 'a[href*="/episodes/"], [data-frameserver]');
    if (!html) return [];
    const eps = parseEpisodeLinks(html);
    if (eps.length) return eps;
    const codes = extractMegamaxCodes(html);
    return codes.map((code, i) => ({
      number: i + 1,
      href: 'megamax:' + code,
      title: codes.length > 1 ? ('Server ' + (i + 1)) : 'Movie',
      subAvailable: true,
      dubAvailable: false,
    }));
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw) return { streams: [] };
    let hashId = '';
    if (raw.startsWith('megamax:')) hashId = raw.substring('megamax:'.length);
    else {
      const m = raw.match(/megamax\.me\/iframe\/([A-Za-z0-9]+)/);
      if (m) hashId = m[1];
    }
    if (!hashId && !/^https?:/i.test(raw)) {
      const html = await fetchShahiidPage(absoluteUrl(normalizeHref(raw)) + '/', '[data-frameserver], iframe');
      if (html) {
        const codes = extractMegamaxCodes(html);
        if (codes[0]) hashId = codes[0];
      }
    }
    log('extractStreamUrl hash=' + hashId);
    if (!hashId) return { streams: [] };

    const mirrors = await megamaxStreams(hashId);
    log('mirrors count=' + mirrors.length);
    if (!mirrors.length) return { streams: [] };
    const streams = await resolveMirrors(mirrors);
    log('resolved streams=' + streams.length);
    if (!streams.length) return { streams: [] };
    return {
      streams: streams,
      subtitles: [],
      headers: streams[0].headers,
      streamType: streams[0].streamType,
      quality: 'auto',
      lang: String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub',
    };
  }

  function sectionFrom(id, title, items) {
    if (!items || !items.length) return null;
    return {
      id: id,
      title: title,
      style: 'poster',
      items: items.slice(0, 30).map((c, i) => ({
        href: c.href,
        title: c.title,
        image: c.image || c.poster || '',
        poster: c.image || c.poster || '',
        rank: i + 1,
      })),
    };
  }

  async function discoveryHome() {
    try {
      let cards = [];
      const html = await fetchShahiidPage(
        SITE + '/',
        '.wrap-poster, a[href*="/episodes/"], a[href*="/seasons/"]',
      );
      if (html) {
        cards = parseCatalogCards(html);
        log('discovery live cards=' + cards.length);
      }
      if (!cards.length) {
        cards = seedCards();
        log('discovery SEED cards=' + cards.length);
      }

      const episodes = cards.filter((c) => c.kind === 'episodes' || c.kind === 'episodesDubbed');
      const seasons = cards.filter((c) => c.kind === 'seasons' || c.kind === 'series' || c.kind === 'seriesDubbed');
      const anime = cards.filter((c) => c.kind === 'anime');
      const mixed = cards.slice(0, 30);

      const sections = [];
      const s1 = sectionFrom('latest-episodes', 'أحدث الحلقات', episodes.length ? episodes : mixed);
      const s2 = sectionFrom('seasons', 'مواسم / سلاسل', seasons);
      const s3 = sectionFrom('movies', 'أفلام الأنمي', anime);
      if (s1) sections.push(s1);
      if (s2) sections.push(s2);
      if (s3) sections.push(s3);
      if (!sections.length && mixed.length) sections.push(sectionFrom('home', 'Shahiid', mixed));
      return { sections };
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
      const sec = sectionFrom('seed', 'Shahiid', seedCards());
      return { sections: sec ? [sec] : [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    const key = String(feedId || 'latest-episodes').toLowerCase();
    try {
      let url = SITE + '/anime/page/' + pageNumber + '/';
      if (key.includes('episode')) url = SITE + '/episodes/page/' + pageNumber + '/';
      else if (key.includes('season') || key.includes('series')) url = SITE + '/series/page/' + pageNumber + '/';
      else if (key.includes('movie') || key === 'anime') url = SITE + '/anime/page/' + pageNumber + '/';

      const html = await fetchShahiidPage(url, '.wrap-poster, a[href*="/anime/"], a[href*="/episodes/"]');
      let cards = html ? parseCatalogCards(html) : [];
      if (!cards.length && pageNumber === 1) cards = seedCards();
      return {
        items: cards.map((c) => ({ href: c.href, title: c.title, image: c.image, poster: c.image })),
        page: pageNumber,
        hasMore: cards.length >= 12,
      };
    } catch (e) {
      log('feed error: ' + (e && e.message ? e.message : String(e)));
      return { items: [], page: pageNumber, hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults, extractDetails, extractEpisodes, extractStreamUrl, discoveryHome, discoveryFeed,
    };
  }
})();
