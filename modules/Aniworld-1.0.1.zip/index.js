(() => {
  'use strict';

  const MODULE_NAME = 'Aniworld';
  const SITE = 'https://aniworld.to';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const LANG_KEYS = { dub: '1', sub: '2', deSub: '3' };
  const LANG_LABELS = { '1': 'Deutsch', '2': 'EN Subs', '3': 'DE Subs' };
  const HOSTER_PRIORITY = ['Vidmoly', 'Filemoon', 'VOE', 'Doodstream'];
  const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const detailsCache = Object.create(null);
  const seasonCache = Object.create(null);
  const streamCache = Object.create(null);

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function cleanText(value) {
    return String(value == null ? '' : value)
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#0?39;|&apos;/gi, "'")
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&#8230;/gi, '...')
      .replace(/&auml;|&Auml;|&ouml;|&Ouml;|&uuml;|&Uuml;|&szlig;/gi, function (m) {
        return {
          '&auml;': '\u00e4',
          '&Auml;': '\u00c4',
          '&ouml;': '\u00f6',
          '&Ouml;': '\u00d6',
          '&uuml;': '\u00fc',
          '&Uuml;': '\u00dc',
          '&szlig;': '\u00df',
        }[m];
      })
      .replace(/\s+/g, ' ')
      .trim();
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function toAbsolute(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.indexOf('//') === 0) return 'https:' + raw;
    if (raw.charAt(0) === '/') return SITE + raw;
    return SITE + '/' + raw;
  }

  function slugFromHref(input) {
    const m = String(input || '').match(/\/anime\/stream\/([a-z0-9-]+)(?:\/|$)/i);
    if (!m || !m[1]) return '';
    const slug = m[1];
    if (/staffel|episode|filme|film/i.test(slug)) return '';
    return slug;
  }

  /* -------------------- HTTP -------------------- */

  async function readBody(res) {
    if (!res) return '';
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        return JSON.stringify(await res.json());
      } catch (_) {}
    }
    return '';
  }

  function headerValue(headers, name) {
    if (!headers) return '';
    const lower = String(name || '').toLowerCase();
    if (typeof headers.get === 'function') {
      try {
        const v = headers.get(name) || headers.get(lower);
        if (v) return v;
      } catch (_) {}
    }
    if (typeof headers === 'object') {
      const keys = Object.keys(headers);
      for (let i = 0; i < keys.length; i++) {
        if (keys[i].toLowerCase() === lower) return String(headers[keys[i]] || '');
      }
    }
    return '';
  }

  async function rawRequest(url, options) {
    const cfg = options || {};
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: cfg.accept || '*/*',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
      },
      cfg.headers || {},
    );
    const method = cfg.method || 'GET';
    const body = cfg.body == null ? null : cfg.body;
    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, method, body);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { method: method, headers: headers, body: body });
    } else {
      throw new Error('No fetch available');
    }
    const status = Number((res && res.status) || 0);
    const ok =
      res &&
      (res.ok === true ||
        res.ok === 1 ||
        (!status && res.ok !== false) ||
        (status >= 200 && status < 400));
    const text = await readBody(res);
    return { ok: !!ok, status: status, body: text || '', headers: (res && res.headers) || {}, url: url };
  }

  async function request(url, options) {
    return rawRequest(url, options || {});
  }

  async function followGet(url, options) {
    let current = url;
    let res = null;
    for (let i = 0; i < 6; i++) {
      res = await request(current, options);
      const status = Number(res.status || 0);
      if (status >= 300 && status < 400) {
        const loc = headerValue(res.headers, 'location');
        if (loc) {
          current = toAbsolute(loc);
          continue;
        }
      }
      break;
    }
    return res;
  }

  /* -------------------- card / page parsers -------------------- */

  function parseSeriesCards(html) {
    const out = [];
    const seen = Object.create(null);
    const re =
      /<a href="(\/anime\/stream\/[a-z0-9-]+)"[^>]*>[\s\S]*?data-src="(\/public\/img\/cover\/[^"]+)"[\s\S]*?<h3>([\s\S]*?)<\/h3>[\s\S]*?<small>([\s\S]*?)<\/small>/gi;
    let m;
    while ((m = re.exec(String(html || '')))) {
      const href = SITE + m[1];
      const slug = slugFromHref(m[1]);
      const title = cleanText(m[3]);
      if (!slug || !title || seen[slug]) continue;
      seen[slug] = true;
      const image = SITE + m[2];
      out.push({
        id: href,
        href: href,
        title: title,
        image: image,
        poster: image,
        type: 'tv',
        mediaType: 'tv',
      });
    }
    return out;
  }

  function parseHomeSections(html) {
    const sections = [];
    const parts = String(html || '').split(/<h2[^>]*>/i);
    for (let i = 1; i < parts.length; i++) {
      const chunk = parts[i];
      const heading = cleanText((chunk.match(/^([\s\S]{0,80}?)<\/h2>/i) || [])[1] || '');
      if (!heading) continue;
      const rest = chunk.replace(/^[\s\S]{0,80}?<\/h2>/i, '');
      const items = parseSeriesCards(rest).slice(0, 30);
      if (!items.length) continue;
      sections.push({ heading: heading, items: items });
    }
    return sections;
  }

  function parseSeasonNumbers(html, slug) {
    const seasons = [];
    const seen = Object.create(null);
    const re = new RegExp('\\/anime\\/stream\\/' + slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\/staffel-(\\d+)', 'g');
    let m;
    while ((m = re.exec(String(html || '')))) {
      const n = Number(m[1]);
      if (n > 0 && !seen[n]) {
        seen[n] = true;
        seasons.push(n);
      }
    }
    return seasons.sort((a, b) => a - b);
  }

  function parseEpisodeRows(html, slug, season) {
    const out = [];
    const seen = Object.create(null);
    const rowRe = /<tr[^>]*data-episode-id="[^"]+"[^>]*>([\s\S]*?)<\/tr>/gi;
    let rm;
    while ((rm = rowRe.exec(String(html || '')))) {
      const row = rm[1];
      const link = (row.match(/\/anime\/stream\/[a-z0-9-]+\/staffel-(\d+)\/episode-(\d+)/i) || [])[0] || '';
      if (!link) continue;
      const s = Number((link.match(/staffel-(\d+)/i) || [])[1]);
      const e = Number((link.match(/episode-(\d+)/i) || [])[1]);
      if (s !== season || !e || seen[e]) continue;
      seen[e] = true;
      const deTitle = cleanText((row.match(/<strong>([\s\S]*?)<\/strong>/i) || [])[1] || '');
      const origTitle = cleanText((row.match(/<span>([\s\S]*?)<\/span>/i) || [])[1] || '');
      const title =
        (deTitle ? (origTitle ? deTitle + ' (' + origTitle + ')' : deTitle) : origTitle) ||
        'Episode ' + e;
      out.push({
        number: e,
        season: s,
        title: 'S' + s + 'E' + e + ' - ' + title,
        href: SITE + '/anime/stream/' + slug + '/staffel-' + s + '/episode-' + e,
        subAvailable: true,
        dubAvailable: true,
      });
    }
    out.sort((a, b) => Number(a.number) - Number(b.number));
    return out;
  }

  /* -------------------- search -------------------- */

  async function homeCards() {
    const res = await request(SITE + '/', { accept: 'text/html,*/*' });
    return parseSeriesCards((res && res.body) || '').slice(0, 40);
  }

  async function fetchCoverForSlug(slug) {
    try {
      const res = await settleWithin(
        request(SITE + '/anime/stream/' + slug, { accept: 'text/html,*/*' }),
        6000,
        null,
      );
      const m = ((res && res.body) || '').match(/data-src="(\/public\/img\/cover\/[^"]+)"/i);
      return m ? SITE + m[1] : '';
    } catch (_) {
      return '';
    }
  }

  async function enrichSearchPosters(results) {
    const limit = Math.min(6, results.length);
    const CONCURRENCY = 3;
    for (let i = 0; i < limit; i += CONCURRENCY) {
      const chunk = results.slice(i, i + CONCURRENCY);
      const covers = await Promise.all(
        chunk.map((item) => fetchCoverForSlug(slugFromHref(item.href))),
      );
      for (let j = 0; j < chunk.length; j++) {
        if (covers[j]) {
          chunk[j].image = covers[j];
          chunk[j].poster = covers[j];
        }
      }
    }
    return results;
  }

  async function searchResults(query) {
    const q = String(query == null ? '' : query).trim();
    if (!q) {
      try {
        return await homeCards();
      } catch (e) {
        log('home search fail: ' + (e && e.message ? e.message : e));
        return [];
      }
    }
    try {
      const forms = searchForms(q);
      const out = [];
      const seen = Object.create(null);
      for (let fi = 0; fi < forms.length; fi++) {
        const form = forms[fi];
        let rows = [];
        try {
          rows = await siteSearch(form);
        } catch (e) {
          rows = [];
        }
        if (!rows.length) continue;
        const isFallback = fi > 0;
        for (let i = 0; i < rows.length; i++) {
          const row = rows[i];
          const slug = slugFromHref(row.href);
          if (!slug || seen[slug]) continue;
          if (isFallback && queryRelevance(q, row.title) < 1) continue;
          seen[slug] = true;
          out.push(row);
        }
        if (out.length) break;
      }
      if (out.length) await enrichSearchPosters(out);
      return out;
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : e));
      return [];
    }
  }

  function searchForms(query) {
    const q = String(query || '').trim();
    const forms = [q];
    const noPunct = q
      .replace(/['\u2019`´.]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (noPunct && noPunct !== q) forms.push(noPunct);
    const words = noPunct.split(/\s+/).filter(Boolean);
    if (words.length > 2) forms.push(words.slice(0, 2).join(' '));
    if (words.length > 1) forms.push(words[0]);
    if (words.length > 2) forms.push(words[words.length - 1]);
    const noArticle = noPunct.replace(/^(the|a|an)\s+/i, '');
    if (noArticle && noArticle !== noPunct) forms.push(noArticle);
    const seen = Object.create(null);
    return forms.filter((f) => {
      if (!f || seen[f]) return false;
      seen[f] = true;
      return true;
    });
  }

  function queryRelevance(query, title) {
    const q = String(query || '')
      .toLowerCase()
      .replace(/['\u2019`´.]/g, '')
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 1);
    const t = String(title || '')
      .toLowerCase()
      .replace(/['\u2019`´.]/g, '')
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 1);
    if (!q.length) return 0;
    let score = 0;
    for (const w of q) {
      if (t.indexOf(w) >= 0) score += 1;
    }
    if (t.join(' ').indexOf(q.join(' ')) >= 0) score += 3;
    return score;
  }

  async function siteSearch(keyword) {
    const res = await request(SITE + '/ajax/search', {
      method: 'POST',
      accept: 'application/json,*/*',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        Referer: SITE + '/search',
      },
      body: 'keyword=' + encodeURIComponent(keyword),
    });
    let rows = [];
    try {
      rows = JSON.parse(res.body);
    } catch (_) {
      rows = [];
    }
    const out = [];
    const seen = Object.create(null);
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const href = toAbsolute(row && row.link);
      const slug = slugFromHref(href);
      const title = cleanText(String((row && row.title) || '').replace(/<\/?em>/gi, ''));
      if (!href || !slug || !title || seen[slug]) continue;
      seen[slug] = true;
      out.push({
        id: href,
        href: href,
        title: title,
        image: '',
        type: 'tv',
        mediaType: 'tv',
      });
    }
    return out;
  }

  /* -------------------- details -------------------- */

  async function extractDetails(urlOrId) {
    const slug = slugFromHref(urlOrId);
    if (!slug) {
      return { title: 'Unknown title', description: 'Unable to resolve this title.' };
    }
    const key = 'd:' + slug;
    if (detailsCache[key]) return detailsCache[key];

    const res = await request(SITE + '/anime/stream/' + slug, { accept: 'text/html,*/*' });
    const html = (res && res.body) || '';
    const title =
      cleanText((String(html).match(/<h1[^>]*title="Animes Stream: ([^",]+)/i) || [])[1] || '') ||
      cleanText((String(html).match(/<h1[^>]*>([^<]+)</i) || [])[1] || '') ||
      slug;
    const description =
      cleanText((String(html).match(/data-full-description="([^"]+)"/i) || [])[1] || '') ||
      'No description available.';
    let image = (String(html).match(/data-src="(\/public\/img\/cover\/[^"]+)"/i) || [])[1] || '';
    image = image ? SITE + image : '';

    const seasons = parseSeasonNumbers(html, slug);
    const details = {
      id: SITE + '/anime/stream/' + slug,
      href: SITE + '/anime/stream/' + slug,
      url: SITE + '/anime/stream/' + slug,
      title: title,
      description: description,
      image: image,
      poster: image,
      type: 'tv',
      mediaType: 'tv',
      seasons: seasons.length || 1,
      seasonNumbers: seasons,
      subAvailable: true,
      dubAvailable: true,
      isMovie: false,
    };
    detailsCache[key] = details;
    return details;
  }

  /* -------------------- episodes -------------------- */

  async function extractEpisodes(seriesId) {
    const slug = slugFromHref(seriesId);
    if (!slug) return [];
    const cacheKey = 'e:' + slug;
    if (seasonCache[cacheKey]) return seasonCache[cacheKey];

    let seasons = [];
    try {
      const details = await extractDetails(SITE + '/anime/stream/' + slug);
      seasons = (details.seasonNumbers || []).slice();
    } catch (_) {}
    if (!seasons.length) seasons = [1];

    const episodes = [];
    const CONCURRENCY = 4;
    for (let i = 0; i < seasons.length; i += CONCURRENCY) {
      const chunk = seasons.slice(i, i + CONCURRENCY);
      const pages = await Promise.all(
        chunk.map(async (season) => {
          const url = SITE + '/anime/stream/' + slug + '/staffel-' + season;
          const res = await request(url, { accept: 'text/html,*/*' });
          return parseEpisodeRows((res && res.body) || '', slug, season);
        }),
      );
      for (let j = 0; j < pages.length; j++) {
        for (let k = 0; k < pages[j].length; k++) episodes.push(pages[j][k]);
      }
    }

    episodes.sort((a, b) => {
      const s = Number(a.season || 1) - Number(b.season || 1);
      if (s !== 0) return s;
      return Number(a.number || 0) - Number(b.number || 0);
    });
    if (episodes.length) seasonCache[cacheKey] = episodes;
    return episodes;
  }

  /* -------------------- hoster / streams -------------------- */

  function parseHosterLinks(html) {
    const byLang = Object.create(null);
    const re =
      /<li[^>]*class="[^"]*episodeLink\d+"[^>]*data-lang-key="(\d+)"[^>]*data-link-id="(\d+)"[^>]*data-link-target="(\/redirect\/\d+)"[\s\S]*?<h4>([\s\S]*?)<\/h4>/gi;
    let m;
    while ((m = re.exec(String(html || '')))) {
      const lang = m[1];
      const hoster = cleanText(m[4]);
      if (!hoster) continue;
      if (!byLang[lang]) byLang[lang] = [];
      byLang[lang].push({ hoster: hoster, target: m[3], id: m[2] });
    }
    for (const k of Object.keys(byLang)) {
      byLang[k].sort((a, b) => {
        const ia = HOSTER_PRIORITY.indexOf(a.hoster);
        const ib = HOSTER_PRIORITY.indexOf(b.hoster);
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      });
    }
    return byLang;
  }

  function hosterHeaders(referer) {
    return {
      'User-Agent': USER_AGENT,
      Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
      Referer: referer || SITE + '/',
    };
  }

  async function resolveVidmoly(target) {
    const res = await followGet(SITE + target, {
      accept: 'text/html,*/*',
      headers: { Referer: SITE + '/' },
    });
    const body = (res && res.body) || '';
    if (!body || /just a moment|attention required|cloudflare/i.test(body)) return null;
    const file =
      (body.match(/sources:\s*\[\s*\{[\s\S]*?file:\s*['"]([^'"]+)['"]/i) || [])[1] || '';
    if (!file || file.indexOf('http') !== 0) return null;
    const kind = /\.m3u8(\?|$)/i.test(file) ? 'hls' : 'mp4';
    return {
      url: file,
      kind: kind,
      container: kind === 'hls' ? 'hls' : '',
      headers: hosterHeaders('https://vidmoly.biz/'),
      provider: 'vidmoly',
      playable: true,
    };
  }

  async function resolveVoe(target) {
    const res = await followGet(SITE + target, {
      accept: 'text/html,*/*',
      headers: { Referer: SITE + '/' },
    });
    const body = (res && res.body) || '';
    if (!body || /just a moment|attention required|cloudflare/i.test(body)) return null;
    const mirror =
      (body.match(/window\.location\.href\s*=\s*['"](https?:\/\/[^'"]+)['"]/i) || [])[1] || '';
    const embedUrl = mirror || (/^https?:\/\//i.test(res.url || '') ? res.url : '');
    if (!embedUrl) return null;
    const embed = await followGet(embedUrl, {
      accept: 'text/html,*/*',
      headers: { Referer: SITE + '/' },
    });
    const ebody = (embed && embed.body) || '';
    if (!ebody || /just a moment|attention required|cloudflare/i.test(ebody)) return null;
    const file =
      (ebody.match(/sources:\s*\[[\s\S]*?file:\s*['"]([^'"]+)['"]/i) || [])[1] ||
      (ebody.match(/https?:\/\/[^"'\s<>]+\.m3u8[^"'\s<>]*/i) || [])[0] ||
      '';
    if (!file || file.indexOf('http') !== 0) return null;
    const kind = /\.m3u8(\?|$)/i.test(file) ? 'hls' : 'mp4';
    return {
      url: file,
      kind: kind,
      container: kind === 'hls' ? 'hls' : '',
      headers: hosterHeaders(embedUrl),
      provider: 'voe',
      playable: true,
    };
  }

  async function sniffHeight(url, headers) {
    try {
      const res = await settleWithin(
        request(url, {
          accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,*/*',
          headers: headers,
        }),
        5000,
        null,
      );
      const body = (res && res.body) || '';
      const m = body.match(/RESOLUTION=(\d+)x(\d+)/i);
      if (m) return Number(m[2]) || 0;
    } catch (_) {}
    return 0;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const slug = slugFromHref(episodeHref);
    const sm = String(episodeHref || '').match(/staffel-(\d+)\/episode-(\d+)/i);
    if (!slug || !sm) {
      log('extractStreamUrl invalid href ' + episodeHref);
      return { streams: [], subtitles: [] };
    }
    const season = Number(sm[1]);
    const episode = Number(sm[2]);
    const wantDub = String(lang || 'sub').toLowerCase() === 'dub';
    const primaryKey = wantDub ? LANG_KEYS.dub : LANG_KEYS.sub;
    const backupKeys = [LANG_KEYS.sub, LANG_KEYS.deSub, LANG_KEYS.dub].filter(
      (k) => k !== primaryKey,
    );

    const cacheKey = slug + ':' + season + ':' + episode + ':' + (wantDub ? 'dub' : 'sub');
    if (streamCache[cacheKey]) return streamCache[cacheKey];

    const res = await request(
      SITE + '/anime/stream/' + slug + '/staffel-' + season + '/episode-' + episode,
      { accept: 'text/html,*/*' },
    );
    const byLang = parseHosterLinks((res && res.body) || '');
    if (!Object.keys(byLang).length) {
      log('no hoster links for ' + cacheKey);
      return { streams: [], subtitles: [] };
    }

    const resolved = [];
    const seenUrls = Object.create(null);
    const order = [primaryKey].concat(backupKeys);
    for (let oi = 0; oi < order.length && !resolved.length; oi++) {
      const key = order[oi];
      const links = byLang[key] || [];
      for (let li = 0; li < links.length && resolved.length < 2; li++) {
        const link = links[li];
        let stream = null;
        try {
          if (/vidmoly/i.test(link.hoster)) stream = await resolveVidmoly(link.target);
          else if (/voe/i.test(link.hoster)) stream = await resolveVoe(link.target);
        } catch (e) {
          log('hoster fail ' + link.hoster + ': ' + (e && e.message ? e.message : e));
          stream = null;
        }
        if (!stream || !stream.url || seenUrls[stream.url]) continue;
        seenUrls[stream.url] = true;
        stream.langLabel = LANG_LABELS[key] || 'Lang' + key;
        stream.langKey = key;
        resolved.push(stream);
      }
    }

    if (!resolved.length) {
      log('no resolvable streams for ' + cacheKey);
      return { streams: [], subtitles: [] };
    }

    const withHeights = await Promise.all(
      resolved.map(async (s) => {
        const h = await sniffHeight(s.url, s.headers);
        return { stream: s, height: h };
      }),
    );

    const entries = withHeights.map((item, idx) => {
      const s = item.stream;
      const h = item.height;
      const q = h >= 360 ? h + 'p' : 'HD';
      return {
        label: 'Aniworld ' + (s.langLabel ? s.langLabel + ' ' : '') + q + (s.kind === 'hls' ? ' HLS' : ''),
        url: s.url,
        height: h || undefined,
        quality: h >= 360 ? h + 'p' : undefined,
        streamType: s.kind === 'hls' || s.container === 'hls' ? 'hls' : 'mp4',
        headers: s.headers,
      };
    });

    const out = {
      streams: entries,
      subtitles: [],
      headers: entries[0] ? entries[0].headers : { 'User-Agent': USER_AGENT },
      streamType: entries[0] && entries[0].streamType ? entries[0].streamType : 'hls',
      quality: entries[0] && entries[0].quality ? entries[0].quality : 'auto',
      defaultQuality: entries[0] && entries[0].quality ? entries[0].quality : undefined,
      qualities: entries.map((e) => ({
        label: e.label,
        height: e.height || 0,
        url: e.url,
        headers: e.headers,
        streamType: e.streamType,
      })),
      lang: wantDub ? 'dub' : 'sub',
      source: 'aniworld-v1',
    };

    log(
      'extractStreamUrl ' +
        cacheKey +
        ' lang=' +
        (wantDub ? 'dub' : 'sub') +
        ' routes=' +
        entries.map((e) => e.label).join(', '),
    );
    streamCache[cacheKey] = out;
    return out;
  }

  /* -------------------- discovery -------------------- */

  const HOME_LABEL_MAP = {
    'Beliebt bei AniWorld': { id: 'home-popular', style: 'hero', feed: 'popular' },
    'Neue Animes': { id: 'home-new', style: 'poster', feed: 'new' },
    'Derzeit beliebt': { id: 'home-trending', style: 'top10', feed: 'popular' },
    'Das sehen andere AniWorld Nutzer': { id: 'home-social', style: 'poster', feed: 'popular' },
  };

  async function discoveryHome() {
    const [homeRes, popRes, kataRes, actionRes] = await Promise.all([
      request(SITE + '/', { accept: 'text/html,*/*' }).catch(() => ({ body: '' })),
      request(SITE + '/beliebte-animes', { accept: 'text/html,*/*' }).catch(() => ({ body: '' })),
      request(SITE + '/katalog/A', { accept: 'text/html,*/*' }).catch(() => ({ body: '' })),
      request(SITE + '/genre/action', { accept: 'text/html,*/*' }).catch(() => ({ body: '' })),
    ]);

    const sections = [];
    const homeSections = parseHomeSections((homeRes && homeRes.body) || '');
    for (let i = 0; i < homeSections.length; i++) {
      const s = homeSections[i];
      const cfg = HOME_LABEL_MAP[s.heading];
      if (!cfg) continue;
      const cap = cfg.style === 'hero' ? 8 : cfg.style === 'top10' ? 10 : 30;
      sections.push({
        id: cfg.id,
        title: s.heading,
        style: cfg.style,
        items: s.items.slice(0, cap),
        viewAll: { mode: 'feed', feedId: cfg.feed },
      });
    }

    const popular = parseSeriesCards((popRes && popRes.body) || '').slice(0, 45);
    if (popular.length) {
      sections.push({
        id: 'popular',
        title: 'Beliebte Animes',
        style: 'top10',
        items: popular.slice(0, 10),
        viewAll: { mode: 'feed', feedId: 'popular' },
      });
    }

    const catalog = parseSeriesCards((kataRes && kataRes.body) || '').slice(0, 30);
    if (catalog.length) {
      sections.push({
        id: 'catalog',
        title: 'Browse A-Z',
        style: 'poster',
        items: catalog,
        viewAll: { mode: 'feed', feedId: 'catalog' },
      });
    }

    const action = parseSeriesCards((actionRes && actionRes.body) || '').slice(0, 30);
    if (action.length) {
      sections.push({
        id: 'genre-action',
        title: 'Action Anime',
        style: 'poster',
        items: action,
        viewAll: { mode: 'feed', feedId: 'genre:action' },
      });
    }

    return { sections: sections.slice(0, 12) };
  }

  async function discoveryFeed(feedId, page) {
    const id = String(feedId || '');
    const pageNum = Math.max(1, Number(page) || 1);

    if (id === 'popular') {
      if (pageNum > 1) return { items: [], page: pageNum, hasMore: false };
      const res = await request(SITE + '/beliebte-animes', { accept: 'text/html,*/*' });
      return { items: parseSeriesCards((res && res.body) || '').slice(0, 45), page: 1, hasMore: false };
    }

    if (id === 'new') {
      if (pageNum > 1) return { items: [], page: pageNum, hasMore: false };
      const res = await request(SITE + '/', { accept: 'text/html,*/*' });
      const hs = parseHomeSections((res && res.body) || '');
      let items = [];
      for (let i = 0; i < hs.length; i++) {
        if (hs[i].heading === 'Neue Animes') {
          items = hs[i].items;
          break;
        }
      }
      return { items: items.slice(0, 30), page: 1, hasMore: false };
    }

    if (id === 'catalog') {
      const letter = LETTERS[(pageNum - 1) % 26];
      const inner = Math.floor((pageNum - 1) / 26) + 1;
      const url = SITE + '/katalog/' + letter + (inner > 1 ? '/' + inner : '');
      const res = await request(url, { accept: 'text/html,*/*' });
      return {
        items: parseSeriesCards((res && res.body) || '').slice(0, 30),
        page: pageNum,
        hasMore: true,
      };
    }

    if (id.indexOf('genre:') === 0) {
      const slug = id.slice(6);
      const url =
        SITE + '/genre/' + encodeURIComponent(slug) + (pageNum > 1 ? '/' + pageNum : '');
      const res = await request(url, { accept: 'text/html,*/*' });
      const items = parseSeriesCards((res && res.body) || '').slice(0, 30);
      return { items: items, page: pageNum, hasMore: items.length >= 30 };
    }

    return { items: [], page: pageNum, hasMore: false };
  }

  /* -------------------- exports -------------------- */

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
