(() => {
  'use strict';

  const MODULE_NAME = 'Anidap';
  const SITE = 'https://anidap.lol';
  const API = SITE + '/api/anime';
  const CHAD = 'https://chad.anidap.lol/rest/api';
  const MAX_EPISODES = 5000;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function apiHeaders(extra) {
    const h = {
      'User-Agent': USER_AGENT,
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      Referer: SITE + '/',
      Origin: SITE,
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Dest': 'empty',
      'sec-ch-ua': '"Chromium";v="138"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
    };
    if (extra) Object.assign(h, extra);
    return h;
  }

  function chadHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Referer: SITE + '/',
      Origin: SITE,
    };
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        const value = await res.json();
        return JSON.stringify(value);
      } catch (_) {}
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        let contentType = String((res && res.contentType) || '');
        if (!contentType && res && res.headers && typeof res.headers === 'object') {
          contentType = String(res.headers['content-type'] || res.headers['Content-Type'] || '');
        }
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          body: textBody,
          json: safeJsonParse(textBody),
          contentType,
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
          contentType: String((res.headers && res.headers.get) ? res.headers.get('content-type') || '' : ''),
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null, contentType: '' };
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  async function apiGet(path, headers) {
    const res = await settleWithin(
      request(API + path, { headers: headers || apiHeaders() }),
      12000,
      null,
    );
    if (!res || !res.ok) return null;
    return res.json || safeJsonParse(res.body);
  }

  async function chadGet(path) {
    const res = await settleWithin(
      request(CHAD + path, { headers: chadHeaders() }),
      15000,
      null,
    );
    if (!res || !res.ok) return null;
    return res.json || safeJsonParse(res.body);
  }

  function titleOf(result) {
    if (!result) return '';
    if (typeof result.title === 'string') return cleanText(result.title);
    const t = result.title || {};
    return cleanText(t.userPreferred || t.english || t.romaji || '');
  }

  function imageOf(result) {
    if (!result) return '';
    return cleanText(result.image || result.cover || result.poster || '');
  }

  // ── Search ────────────────────────────────────────────────────────────────

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      let data = null;
      if (q) {
        const res = await settleWithin(
          request(API + '/search?q=' + encodeURIComponent(q) + '&page=' + pageNumber, {
            headers: apiHeaders(),
          }),
          12000,
          null,
        );
        data = (res && res.json) || (res && res.body ? safeJsonParse(res.body) : null);
      }
      const results = (data && Array.isArray(data.results)) ? data.results : [];
      return results.map((item) => ({
        id: String(item.id || ''),
        title: titleOf(item),
        href: String(item.id || ''),
        image: imageOf(item),
        poster: imageOf(item),
        description: cleanText(item.description || ''),
        year: String(item.releaseDate || item.year || '').substring(0, 4),
        rating: item.rating != null ? String(item.rating) : '',
        type: String(item.type || item.format || '').toLowerCase(),
        mediaType: String(item.type || item.format || 'tv').toLowerCase(),
      }));
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  // ── Details ───────────────────────────────────────────────────────────────

  async function extractDetails(urlOrId) {
    const id = String(urlOrId || '').trim();
    if (!id) return { title: 'Unknown', description: '' };
    const data = await apiGet('/' + encodeURIComponent(id));
    if (!data || !data.data) {
      return { title: id, description: '', image: '', href: id };
    }
    const d = data.data;
    return {
      title: cleanText(d.englishTitle || d.titleRomaji || d.title || id),
      description: cleanText(d.description || ''),
      image: cleanText(d.coverImage || d.image || d.bannerImage || ''),
      href: String(d.id || id),
      year: d.seasonYear != null ? String(d.seasonYear) : (d.year ? String(d.year) : ''),
      rating: d.averageScore != null ? String(d.averageScore) : '',
      status: cleanText(d.status || ''),
    };
  }

  // ── Episodes ──────────────────────────────────────────────────────────────

  async function extractEpisodes(seriesId) {
    const id = String(seriesId || '').trim();
    if (!id) return [];

    // Resolve the anidap internal id from details if needed (search gives the
    // same id, but details confirms it and gives episodeCount).
    let animeId = id;
    let detailsData = null;
    if (!id.includes('-') || /^\d+$/.test(id)) {
      const details = await apiGet('/' + encodeURIComponent(id));
      if (details && details.data && details.data.id) {
        animeId = String(details.data.id);
        detailsData = details.data;
      }
    }

    const eps = await chadGet('/episodes?id=' + encodeURIComponent(animeId));
    if (!Array.isArray(eps)) {
      // Fallback: generate from details episodeCount
      const count = detailsData && detailsData.episodeCount
        ? Number(detailsData.episodeCount)
        : 0;
      const out = [];
      for (let n = 1; n <= Math.min(count || 0, MAX_EPISODES); n++) {
        out.push({
          number: n,
          href: animeId + ':' + n,
          title: 'Episode ' + n,
          subAvailable: true,
          dubAvailable: true,
        });
      }
      return out;
    }

    const out = [];
    const seen = new Set();
    for (const ep of eps) {
      const num = Number((ep && ep.number) || 0);
      if (!num || seen.has(num)) continue;
      seen.add(num);
      const en = ((ep && ep.titles && ep.titles.en) || '');
      const jp = ((ep && ep.titles && (ep.titles['x-jat'] || ep.titles.ja)) || '');
      out.push({
        number: num,
        href: animeId + ':' + num,
        title: cleanText(en || jp || ('Episode ' + num)),
        image: cleanText((ep && ep.img) || ''),
        subAvailable: true,
        dubAvailable: true,
      });
      if (out.length >= MAX_EPISODES) break;
    }
    out.sort((a, b) => a.number - b.number);
    return out;
  }

  // ── Streams ───────────────────────────────────────────────────────────────

  function streamHeadersFor(url, providerId) {
    const h = {
      'User-Agent': USER_AGENT,
      Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
    };
    if (url && /vivibebe\.site|shiora\.top|krussdomi\.com|anidb\.app|uwucdn\.top/.test(url)) {
      h.Referer = url.match(/^(https?:\/\/[^/]+)/i)[1] + '/';
    }
    return h;
  }

  function playlistVariantUrl(body, baseUrl) {
    const lines = String(body || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue;
      for (let j = i + 1; j < lines.length; j++) {
        if (lines[j].startsWith('#')) continue;
        return resolveUrl(lines[j], baseUrl);
      }
    }
    return '';
  }

  function resolveUrl(value, base) {
    const ref = String(value || '').trim();
    if (/^https?:\/\//i.test(ref)) return ref;
    const origin = (String(base || '').match(/^(https?:\/\/[^/]+)/i) || [])[1] || '';
    if (!origin) return '';
    if (ref.startsWith('/')) return origin + ref;
    const dir = String(base || '').replace(/[^/]*$/, '');
    return dir + ref.replace(/^\.\//, '');
  }

  function firstMediaSegmentUrl(body, baseUrl) {
    const lines = String(body || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (const line of lines) {
      if (!line || line.startsWith('#')) continue;
      if (/\.m3u8(?:[?#]|$)/i.test(line)) continue;
      return resolveUrl(line, baseUrl);
    }
    return '';
  }

  // Probe the first segment of an HLS playlist. A "valid" master playlist can
  // still be a fake: placeholder 1x1 PNG segments, CF challenge pages, or
  // HTML redirects. Reject those so the app never starts a dead stream.
  async function probeHlsPlaylist(url, headers) {
    const h = Object.assign({ Range: 'bytes=0-2047', Accept: 'application/vnd.apple.mpegurl,*/*' }, headers || {});
    const master = await settleWithin(request(url, { headers: h }), 6000, null);
    if (!master || !master.ok || !/#EXTM3U/i.test(master.body || '')) return false;
    let playlistBody = master.body;
    let playlistBase = url;
    const variantUrl = playlistVariantUrl(master.body, url);
    if (variantUrl) {
      const variant = await settleWithin(request(variantUrl, { headers: h }), 6000, null);
      if (!variant || !variant.ok || !/#EXTM3U/i.test(variant.body || '')) return false;
      playlistBody = variant.body;
      playlistBase = variantUrl;
    }
    const segUrl = firstMediaSegmentUrl(playlistBody, playlistBase);
    if (!segUrl) return false;
    const seg = await settleWithin(
      request(segUrl, {
        headers: Object.assign({}, headers || {}, {
          Range: 'bytes=0-2047',
          Accept: 'video/mp2t,video/mp4,video/*,application/octet-stream,*/*',
        }),
      }),
      6000,
      null,
    );
    if (!seg || !seg.ok) return false;
    const ct = String(seg.contentType || '').toLowerCase();
    const head = String(seg.body || '').substring(0, 16);
    // Reject HTML (CF challenge/redirect) and image placeholders.
    if (!ct || ct.includes('text/html') || ct.includes('image/')) return false;
    if (/^<!|^<html/i.test(head)) return false;
    return true;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw) return { streams: [] };
    const wantDub = String(lang || 'sub').toLowerCase() === 'dub';

    let animeId = raw;
    let epNum = 1;
    const colon = raw.indexOf(':');
    if (colon > 0) {
      animeId = raw.substring(0, colon);
      epNum = Number(raw.substring(colon + 1)) || 1;
    }

    const servers = await chadGet('/servers?id=' + encodeURIComponent(animeId) + '&epNum=' + epNum);
    if (!servers) return { streams: [] };
    const providers = wantDub
      ? (servers.dubProviders || [])
      : (servers.subProviders || []);
    if (!providers.length) return { streams: [] };

    const streams = [];
    const seen = new Set();
    const providerIds = [];
    const defaults = providers.filter((p) => p && p.default === true);
    const others = providers.filter((p) => p && p.default !== true);
    for (const p of [...defaults, ...others]) {
      if (p && p.id && !providerIds.includes(p.id)) providerIds.push(p.id);
      if (providerIds.length >= 6) break;
    }

    for (const providerId of providerIds) {
      const sources = await chadGet(
        '/sources?id=' + encodeURIComponent(animeId) +
        '&epNum=' + epNum +
        '&type=' + (wantDub ? 'dub' : 'sub') +
        '&providerId=' + encodeURIComponent(providerId),
      );
      if (!sources) continue;
      const list = Array.isArray(sources.sources) ? sources.sources : [];
      for (const s of list) {
        const url = String((s && s.url) || '');
        if (!url || !/^https?:\/\//i.test(url) || seen.has(url)) continue;
        seen.add(url);
        const stype = String((s && s.type) || '').toLowerCase();
        const isHls = stype.includes('mpegurl') || stype.includes('m3u8') || /\.m3u8/i.test(url);
        const isDash = stype.includes('dash') || /\.mpd(?:[?#]|$)/i.test(url);
        const hdrs = streamHeadersFor(url, providerId);
        if (isHls) {
          const playable = await probeHlsPlaylist(url, hdrs);
          if (!playable) {
            log('rejected provider=' + providerId + ' (unplayable playlist/segment) ' + url.substring(0, 60));
            continue;
          }
        } else if (isDash) {
          // The app's native players use HLS/MP4; DASH requires a compatible
          // player. Probe the manifest and keep it only when reachable, but
          // demote it below HLS candidates.
          const mpd = await settleWithin(request(url, { headers: hdrs }), 6000, null);
          if (!mpd || !mpd.ok || !/(<MPD|<mpd)/i.test(mpd.body || '')) continue;
        }
        streams.push({
          label: (wantDub ? 'DUB' : 'SUB') + ' • ' + providerId + ' • ' +
            cleanText((s && s.quality) || 'auto'),
          url: url,
          streamType: isDash ? 'dash' : (isHls ? 'hls' : 'mp4'),
          height: undefined,
          headers: hdrs,
          providerId: providerId,
        });
      }
      if (streams.length >= 12) break;
    }

    if (!streams.length) return { streams: [] };
    const ranked = [...streams].sort((a, b) => {
      const score = (s) => s.streamType === 'hls' ? 0 : s.streamType === 'dash' ? 1 : 2;
      return score(a) - score(b);
    });
    return {
      streams: ranked,
      subtitles: [],
      headers: ranked[0].headers,
      streamType: ranked[0].streamType,
      quality: 'auto',
      lang: wantDub ? 'dub' : 'sub',
    };
  }

  // Unwrap the varying response envelopes the API returns:
  //   search: { success, results }
  //   trending/popular: { success, data: { success, data: { results } } }
  // Returns the results array (or []).
  function unwrapResults(data) {
    if (!data) return [];
    let node = data;
    if (node.results && Array.isArray(node.results)) return node.results;
    if (node.data) {
      node = node.data;
      if (node.results && Array.isArray(node.results)) return node.results;
      if (node.data) {
        node = node.data;
        if (node.results && Array.isArray(node.results)) return node.results;
      }
    }
    return [];
  }

  // ── Discovery / Home ──────────────────────────────────────────────────────

  async function discoveryHome() {
    try {
      const sections = [];
      const trending = await apiGet('/trending?page=1');
      const trendingResults = unwrapResults(trending);
      if (trendingResults.length) {
        const items = trendingResults.slice(0, 20).map((item, i) => ({
          title: titleOf(item),
          href: String(item.id || ''),
          image: imageOf(item),
          rank: i + 1,
        }));
        sections.push({ id: 'trending', title: 'Trending', style: 'poster', items: items });
      }
      const popular = await apiGet('/popular?page=1');
      const popularResults = unwrapResults(popular);
      if (popularResults.length) {
        const items = popularResults.slice(0, 20).map((item) => ({
          title: titleOf(item),
          href: String(item.id || ''),
          image: imageOf(item),
        }));
        sections.push({ id: 'popular', title: 'Popular', style: 'poster', items: items });
      }
      return { sections };
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const key = String(feedId || 'trending').toLowerCase();
    const pageNumber = Math.max(1, Number(page) || 1);
    let endpoint = '/trending?page=' + pageNumber;
    if (key === 'popular') endpoint = '/popular?page=' + pageNumber;
    else if (key === 'recent') endpoint = '/recent?page=' + pageNumber;
    else if (key === 'top-airing') endpoint = '/top-airing?page=' + pageNumber;
    const data = await apiGet(endpoint);
    const results = unwrapResults(data);
    let hasNext = false;
    let node = data;
    if (node && node.data && node.data.data) node = node.data.data;
    hasNext = !!(node && node.hasNextPage);
    return {
      items: results.map((item) => ({
        title: titleOf(item),
        href: String(item.id || ''),
        image: imageOf(item),
      })),
      page: pageNumber,
      hasMore: hasNext,
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { searchResults, extractDetails, extractEpisodes, extractStreamUrl, discoveryHome, discoveryFeed };
  }
})();
