(() => {
  'use strict';

  const MODULE_NAME = 'HiAnimeV1';
  const MAX_EPISODES = 1300;
  const TIMEOUT_MS = 9000;
  const SEARCH_TIMEOUT_MS = 12000;
  const EMBED_TIMEOUT_MS = 8000;
  const STREAM_DEADLINE_MS = 16000;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  // ── profiles ────────────────────────────────────────────────────────────
  const PROFILE = {
    main: {
      id: 'main',
      name: 'HiAnime',
      base: 'https://hianimes.ru',
      poster: 'https://static.hianimes.ru/resources',
      kind: 'hianime',
    },
    city: {
      id: 'city',
      name: 'HiAnime City',
      base: 'https://hianime.city',
      kind: 'wordpress',
    },
  };
  const ACTIVE_PROFILE = PROFILE.main;

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, Math.max(1, Number(ms) || 0));
    });
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try {
      return JSON.parse(String(text == null ? '' : text).trim());
    } catch (_) {
      return null;
    }
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try {
        return JSON.stringify(res.json);
      } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        return typeof text === 'string' ? text : '';
      } catch (_) {
        return '';
      }
    }
    return '';
  }

  async function readResponseJson(res, textBody) {
    if (res && res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      return res.json;
    }
    let json = safeJsonParse(textBody);
    if (json != null) return json;
    if (res && typeof res.json === 'function') {
      try {
        json = await res.json();
        if (json != null) return json;
      } catch (_) {}
    }
    return null;
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = String(cfg.method || 'GET').toUpperCase();
    const headers = {
      'User-Agent': USER_AGENT,
      Accept: 'application/json,text/html,application/xhtml+xml,*/*',
      'Accept-Language': 'en-US,en;q=0.9',
      Referer: ACTIVE_PROFILE.base + '/',
    };
    if (cfg.headers) {
      for (const k of Object.keys(cfg.headers)) headers[k] = cfg.headers[k];
    }
    const body = cfg.body == null ? null : cfg.body;

    try {
      let res;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, method, body);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, {
          method,
          headers,
          body: method === 'GET' || method === 'HEAD' ? undefined : body,
        });
      } else {
        return { ok: false, status: 0, body: '', json: null, contentType: '' };
      }
      const status = Number((res && res.status) || 0);
      const textBody = await readResponseBody(res);
      let contentType = '';
      if (res && typeof res.contentType === 'string') contentType = res.contentType;
      else if (res && res.headers && typeof res.headers.get === 'function') {
        try {
          contentType = String(res.headers.get('content-type') || '');
        } catch (_) {}
      }
      return {
        ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
        status,
        body: textBody,
        json: await readResponseJson(res, textBody),
        contentType: String(contentType || '').toLowerCase(),
        finalUrl: String(
          (res &&
            (res.url || res.finalUrl || res.finalURL || res.responseUrl || res.redirectUrl)) ||
            url
        ).trim(),
      };
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
      return { ok: false, status: 0, body: '', json: null, contentType: '' };
    }
  }

  function decodeHtml(str) {
    return String(str || '')
      .replace(/\\u([0-9a-f]{4})/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#039;/g, "'")
      .replace(/&#39;/g, "'")
      .trim();
  }

  function cleanText(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function normForMatch(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .replace(/[’'`´:;.!?&,+()\[\]{}<>/\\|–—"]/g, ' ')
      .replace(/\bs\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function slugify(value) {
    return String(value || '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  /* ────────────────────────── PROFILE A: hianimes.ru ────────────────────────── */

  function mainDetailId(href) {
    const raw = String(href || '').split('?')[0].replace(/\/$/, '');
    const m = raw.match(/(?:^|\/)(?:info|watch)\/(?:[^/]+-)?(\d+)$/);
    return m ? m[1] : '';
  }

  async function mainSearch(query) {
    const term = String(query == null ? '' : query).trim();
    const isBrowse = !term;
    const res = await settleWithin(
      request(
        PROFILE.main.base +
          (isBrowse ? '/top-airing' : '/filter?keyword=' + encodeURIComponent(term))
      ),
      SEARCH_TIMEOUT_MS,
      null
    );
    if (!res || !res.ok || !res.body) return [];
    const qNorm = isBrowse ? '' : normForMatch(term);
    let items = parseCardsFromHtml(res.body, qNorm, PROFILE.main.base);
    if (!items.length) {
      const hrefs = [...new Set([...res.body.matchAll(/href="(\/info\/[^"]+)"/g)].map((x) => x[1]))];
      const seen = new Set();
      for (const h of hrefs.slice(0, 40)) {
        if (seen.has(h)) continue;
        seen.add(h);
        items.push({ href: 'https://hianimes.ru' + h, image: '', title: 'HiAnime Title', _score: 0 });
      }
    }
    items.sort((a, b) => b._score - a._score);
    const strong = isBrowse ? items : items.filter((r) => r._score >= 100);
    const picked = strong.length ? strong : items.slice(0, 20);
    return picked
      .slice(0, 30)
      .map((r) => ({ title: r.title, href: r.href, image: r.image }));
  }

  async function mainDetails(urlOrId) {
    const raw = String(urlOrId || '');
    // Prefer the full URL from search results (includes the slug).
    let href = raw;
    if (!/^https?:\/\//.test(raw)) {
      const id = mainDetailId(raw);
      href = id ? PROFILE.main.base + '/info/' + id : raw;
    }
    const res = await settleWithin(request(href), TIMEOUT_MS, null);
    const body = (res && res.body) || '';
    const ogTitle = (body.match(/property="og:title" content="([^"]+)"/) || [])[1] || '';
    const ogImage = (body.match(/property="og:image" content="([^"]+)"/) || [])[1] || '';
    const desc =
      (body.match(/property="og:description" content="([^"]+)"/) || [])[1] || '';
    const yearMatch = body.match(/(?:\(|\s)(\d{4})\)?\s*–\s*Watch/);
    return {
      title: decodeHtml(ogTitle.replace(/\s*–\s*Watch.*$/i, '').trim()) || 'HiAnime Title',
      description: decodeHtml(desc),
      image: ogImage,
      href: href,
    };
  }

  async function mainEpisodes(seriesId) {
    const id = mainDetailId(seriesId);
    if (!id) return [];
    const res = await settleWithin(
      request(PROFILE.main.base + '/ajax/v2/episode/list/' + id),
      TIMEOUT_MS,
      null
    );
    const data = (res && res.json) || null;
    if (!data || !Array.isArray(data.episodeData)) return [];
    const eps = [];
    for (const ep of data.episodeData) {
      const num = Number(ep.episode_number || 0);
      if (num < 1) continue;
      const malId = Number(ep.mal_id || 0);
      eps.push({
        number: num,
        id: String(malId || num),
        href: PROFILE.main.base + '/watch/' + id + '?ep=' + malId,
        title: String(ep.title || '').trim(),
        subAvailable: true,
        dubAvailable: (data.dubEpisodes && data.dubEpisodes.length > 0) || false,
      });
      if (eps.length >= MAX_EPISODES) break;
    }
    return eps;
  }

  async function mainServers(episodeHref, episodeId) {
    const id = mainDetailId(episodeHref);
    if (!id) return [];
    const res = await settleWithin(
      request(
        PROFILE.main.base +
          '/ajax/v2/episode/servers?episodeId=' +
          encodeURIComponent(episodeId) +
          '&mov_id=' +
          id
      ),
      TIMEOUT_MS,
      null
    );
    const data = (res && res.json) || null;
    if (!data) return [];
    const html = Array.isArray(data.html) ? data.html.join('') : String(data.html || '');
    const serverIds = [...html.matchAll(/data-id="([^"]+)"/g)].map((x) => x[1]);
    const serverTypes = [...html.matchAll(/data-type="(sub|dub)"/g)].map((x) => x[1]);
    return serverIds.map((sid, i) => ({ id: sid, type: serverTypes[i] || 'sub' }));
  }

  async function mainSources(serverId) {
    const res = await settleWithin(
      request(PROFILE.main.base + '/ajax/v2/episode/sources?id=' + encodeURIComponent(serverId)),
      TIMEOUT_MS,
      null
    );
    const data = (res && res.json) || null;
    if (!data || data.type !== 'iframe' || !data.link) return [];
    const link = String(data.link);
    // EchoVideo family: /embed-N/{token}
    const ev = link.match(/^https?:\/\/(play\.echovideo\.ru|.*echovideo.*)\/(embed-[^/]+)\/([^?#]+)/i);
    const host = ev ? 'https://play.echovideo.ru' : (link.match(/^(https?:\/\/[^/]+)/) || [])[1] || '';
    const path = ev ? '/' + ev[2] : (link.match(/^(https?:\/\/[^/]+)(\/[^?#]*)/) || [])[2] || '';
    const token = ev ? ev[3] : (link.match(/\/([^/?#]+)$/) || [])[1] || '';
    if (!host || !token) return [];
    // Probe the echovideo-style getSources endpoint relative to the embed path.
    const getUrl =
      host + (path ? path + '/' : '/') + 'getSources?id=' + encodeURIComponent(token);
    const g = await settleWithin(
      request(getUrl, {
        headers: {
          Referer: host + (path ? '/' + path + '/' + token : ''),
          'X-Requested-With': 'XMLHttpRequest',
          Accept: 'application/json',
        },
      }),
      EMBED_TIMEOUT_MS,
      null
    );
    const gd = (g && g.json) || null;
    if (!gd) return [];
    const out = [];
    const rawSources = gd.sources;
    const addEntry = (u, quality, height) => {
      if (typeof u === 'string' && u.indexOf('http') === 0) {
        out.push({
          url: u,
          quality,
          height,
          provider: 'EchoVideo',
          headers: { Referer: host + '/', Origin: host },
        });
      }
    };
    if (typeof rawSources === 'string') {
      // Single HLS (e.g. hlsxst5.echovideo.to ... .m3u8)
      addEntry(rawSources, 'auto', 0);
    } else if (rawSources && typeof rawSources === 'object') {
      const order = ['HQ', 'HD', 'SD'];
      for (const q of order) {
        const list = rawSources[q];
        if (!list) continue;
        const arr = Array.isArray(list) ? list : [list];
        for (const u of arr) {
          addEntry(u, q.toLowerCase(), q === 'HQ' ? 1080 : q === 'HD' ? 720 : 480);
        }
      }
    }
    return out;
  }

  async function mainStream(episodeHref, episodeId, lang) {
    const wantDub = String(lang || 'sub').toLowerCase() === 'dub';
    const servers = await mainServers(episodeHref, episodeId);
    if (!servers.length) return { streams: [], subtitles: [] };
    let preferred = servers.filter((s) => (wantDub ? s.type === 'dub' : s.type === 'sub'));
    if (!preferred.length) preferred = servers.filter((s) => s.type === (wantDub ? 'sub' : 'dub'));
    if (!preferred.length) preferred = servers;
    const started = Date.now();
    const results = [];
    for (const server of preferred.slice(0, 4)) {
      if (Date.now() - started > STREAM_DEADLINE_MS) break;
      const srcs = await mainSources(server.id);
      for (const s of srcs) results.push(s);
      if (results.length) break;
    }
    if (!results.length) return { streams: [], subtitles: [] };
    const streams = results.map((s, i) => ({
      label: (s.quality ? s.quality + ' • ' : '') + s.provider + (results.length > 1 ? ' ' + (i + 1) : ''),
      url: s.url,
      height: s.height,
      quality: s.quality,
      streamType: 'mp4',
      headers: s.headers,
    }));
    return { streams, subtitles: [] };
  }

  /* ────────────────────────── PROFILE B: hianime.city ───────────────────────── */

  async function citySearch(query) {
    const term = String(query == null ? '' : query).trim();
    const isBrowse = !term;
    const res = await settleWithin(
      request(
        PROFILE.city.base +
          (isBrowse
            ? '/series/?status=&type=&order=popular'
            : '/?s=' + encodeURIComponent(term))
      ),
      SEARCH_TIMEOUT_MS,
      null
    );
    if (!res || !res.ok || !res.body) return [];
    const links = [
      ...new Set([...res.body.matchAll(/href="(https:\/\/hianime\.city\/series\/[^"]+)"/g)].map((x) => x[1])),
    ];
    const qNorm = isBrowse ? '' : normForMatch(term);
    const out = [];
    for (const href of links.slice(0, 40)) {
      const slug = href.replace(/^https:\/\/hianime\.city\/series\//, '').replace(/\/$/, '');
      const title = slug
        .replace(/-dub$|-hdd$|-nhj$|-xza$/i, '')
        .replace(/-/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
      const tn = normForMatch(title);
      const score = isBrowse
        ? 1
        : tn === qNorm
          ? 1000
          : tn.indexOf(qNorm) === 0
            ? 600
            : tn.indexOf(qNorm) >= 0
              ? 300
              : 0;
      if (isBrowse || score > 0) out.push({ title, href, image: '', _score: score });
    }
    out.sort((a, b) => b._score - a._score);
    const strong = isBrowse ? out : out.filter((r) => r._score >= 100);
    const picked = strong.length ? strong : out.slice(0, 20);
    return picked.slice(0, 20).map((r) => ({ title: r.title, href: r.href, image: r.image }));
  }

  async function cityDetails(urlOrId) {
    const res = await settleWithin(request(String(urlOrId)), TIMEOUT_MS, null);
    const body = (res && res.body) || '';
    const ogTitle = (body.match(/property="og:title" content="([^"]+)"/) || [])[1] || '';
    const ogImage = (body.match(/property="og:image" content="([^"]+)"/) || [])[1] || '';
    const desc =
      (body.match(/property="og:description" content="([^"]+)"/) || [])[1] || '';
    return {
      title: decodeHtml(ogTitle || 'HiAnime City'),
      description: decodeHtml(desc),
      image: ogImage,
      href: String(urlOrId),
    };
  }

  async function cityEpisodes(seriesId) {
    const res = await settleWithin(request(String(seriesId)), TIMEOUT_MS, null);
    const body = (res && res.body) || '';
    const eps = [];
    const seen = new Set();
    const re = /href="(https:\/\/hianime\.city\/([a-z0-9-]+?)-episode-(\d+)-[^"]+)"/g;
    let m;
    while ((m = re.exec(body))) {
      const num = Number(m[3]);
      if (!num || seen.has(num)) continue;
      seen.add(num);
      eps.push({
        number: num,
        href: m[1],
        title: '',
        subAvailable: !/dub/i.test(m[2]),
        dubAvailable: /dub/i.test(m[2]),
      });
    }
    eps.sort((a, b) => a.number - b.number);
    return eps.slice(0, MAX_EPISODES);
  }

  async function cityStream(episodeHref, lang) {
    const wantDub = String(lang || 'sub').toLowerCase() === 'dub';
    const res = await settleWithin(request(String(episodeHref)), TIMEOUT_MS, null);
    const body = (res && res.body) || '';
    const embeds = [
      ...body.matchAll(
        /(?:data-litespeed-src|src)="(https:\/\/megaplay\.buzz\/stream\/[^"]+)"/g
      ),
    ].map((x) => x[1]);
    let pick = '';
    for (const e of embeds) {
      const isDub = /\/dub(\?|$)/.test(e);
      if ((wantDub && isDub) || (!wantDub && !isDub)) {
        pick = e;
        break;
      }
    }
    if (!pick) pick = embeds[0] || '';
    if (!pick) return { streams: [], subtitles: [] };
    const realId = (pick.match(/\/stream\/s-2\/(\d+)\//) || [])[1] || '';
    if (!realId) return { streams: [], subtitles: [] };
    const g = await settleWithin(
      request('https://megaplay.buzz/stream/getSources?id=' + encodeURIComponent(realId), {
        headers: {
          Referer: pick,
          'X-Requested-With': 'XMLHttpRequest',
          Accept: 'application/json',
        },
      }),
      EMBED_TIMEOUT_MS,
      null
    );
    const gd = (g && g.json) || null;
    const file = gd && gd.sources && gd.sources.file;
    if (!file) return { streams: [], subtitles: [] };
    const tracks = Array.isArray(gd.tracks) ? gd.tracks : [];
    const subtitles = [];
    for (const t of tracks) {
      const u = String(t.file || '');
      const label = String(t.label || '');
      if (!u.startsWith('http') || !label) continue;
      subtitles.push({
        label,
        language: t.lang || 'und',
        url: u,
        file: u,
        kind: 'captions',
        headers: { Referer: 'https://megaplay.buzz/', Origin: 'https://megaplay.buzz' },
      });
    }
    return {
      streams: [
        {
          label: 'Auto • MegaPlay',
          url: file,
          streamType: 'hls',
          headers: { Referer: 'https://megaplay.buzz/', Origin: 'https://megaplay.buzz' },
        },
      ],
      subtitles,
    };
  }

  /* ────────────────────────── combined entry points ────────────────────────── */

  async function searchResults(query, page) {
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      let results = [];
      if (ACTIVE_PROFILE.kind === 'hianime') {
        results = await mainSearch(query);
      } else {
        results = await citySearch(query);
      }
      const start = (pageNumber - 1) * 30;
      if (start <= 0) return results;
      return results.slice(start, start + 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    try {
      if (ACTIVE_PROFILE.kind === 'hianime') return await mainDetails(urlOrId);
      return await cityDetails(urlOrId);
    } catch (e) {
      log('details error: ' + (e && e.message ? e.message : String(e)));
      return { title: 'HiAnime', description: '' };
    }
  }

  async function extractEpisodes(seriesId) {
    try {
      if (ACTIVE_PROFILE.kind === 'hianime') return await mainEpisodes(seriesId);
      return await cityEpisodes(seriesId);
    } catch (e) {
      log('episodes error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractStreamUrl(episodeHref, lang) {
    try {
      if (ACTIVE_PROFILE.kind === 'hianime') {
        const episodeId = (String(episodeHref).match(/[?&]ep=(\d+)/) || [])[1] || '1';
        return await mainStream(episodeHref, episodeId, lang);
      }
      return await cityStream(episodeHref, lang);
    } catch (e) {
      log('stream error: ' + (e && e.message ? e.message : String(e)));
      return { streams: [] };
    }
  }

  // ── discovery / home ─────────────────────────────────────────────────────

  function parseCardsFromHtml(body, qNorm, baseUrl) {
    const items = [];
    const seen = new Set();
    const cardRe =
      /<div class="flw-item[^>]*>[\s\S]*?data-src="([^"]+)"[\s\S]*?href="(\/info\/[^"]+)"[\s\S]*?<div class="film-detail">[\s\S]*?<a[^>]*data-jname="([^"]*)"[^>]*>([^<]*)<\/a>/g;
    let cm;
    while ((cm = cardRe.exec(body))) {
      const href = baseUrl + cm[2];
      if (seen.has(href)) continue;
      seen.add(href);
      const image = cm[1].startsWith('http') ? cm[1] : baseUrl + cm[1];
      const visible = decodeHtml(cm[4].trim());
      const title = visible || decodeHtml(cm[3].trim()) || 'HiAnime Title';
      const tn = normForMatch(title);
      const score = qNorm
        ? tn === qNorm
          ? 1000
          : tn.indexOf(qNorm) === 0
            ? 600
            : tn.indexOf(qNorm) >= 0
              ? 300
              : 0
        : 1;
      items.push({ href, image, title, _score: score });
    }
    return items;
  }

  async function mainDiscover(pagePath, label) {
    const res = await settleWithin(
      request(PROFILE.main.base + pagePath),
      SEARCH_TIMEOUT_MS,
      null
    );
    if (!res || !res.ok || !res.body) return [];
    const cards = parseCardsFromHtml(res.body, '', PROFILE.main.base);
    cards.sort((a, b) => b._score - a._score);
    return cards.slice(0, 24).map((r) => ({ title: r.title, href: r.href, image: r.image }));
  }

  async function discoveryHome() {
    const sections = [];
    try {
      if (ACTIVE_PROFILE.kind === 'hianime') {
        const [trending, topAiring, movies] = await Promise.all([
          mainDiscover('/home', 'Trending'),
          mainDiscover('/top-airing', 'Top Airing'),
          mainDiscover('/show-type/movies', 'Movies'),
        ]);
        if (trending.length) {
          sections.push({ id: 'trending', title: 'Trending', style: 'poster', items: trending, viewAll: { mode: 'feed', feedId: 'trending' } });
        }
        if (topAiring.length) {
          sections.push({ id: 'top_airing', title: 'Top Airing', style: 'poster', items: topAiring, viewAll: { mode: 'feed', feedId: 'topAiring' } });
        }
        if (movies.length) {
          sections.push({ id: 'movies', title: 'Movies', style: 'poster', items: movies, viewAll: { mode: 'feed', feedId: 'movies' } });
        }
      } else {
        const res = await settleWithin(
          request(PROFILE.city.base + '/series/?status=&type=&order=popular'),
          SEARCH_TIMEOUT_MS,
          null
        );
        if (res && res.ok && res.body) {
          const links = [
            ...new Set(
              [...res.body.matchAll(/href="(https:\/\/hianime\.city\/series\/[^"]+)"/g)].map((x) => x[1])
            ),
          ];
          const items = links.slice(0, 24).map((href) => ({
            title: href
              .replace(/^https:\/\/hianime\.city\/series\//, '')
              .replace(/\/$/, '')
              .replace(/-dub$|-hdd$/i, '')
              .replace(/-/g, ' '),
            href,
            image: '',
          }));
          if (items.length) {
            sections.push({ id: 'popular', title: 'Popular', style: 'poster', items, viewAll: { mode: 'feed', feedId: 'popular' } });
          }
        }
      }
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const key = String(feedId || '').trim().toLowerCase();
    const pageNumber = Math.max(1, Number(page) || 1);
    let items = [];
    if (ACTIVE_PROFILE.kind === 'hianime') {
      const path =
        key === 'topAiring' || key === 'top_airing'
          ? '/top-airing?page=' + pageNumber
          : key === 'movies'
            ? '/show-type/movies?page=' + pageNumber
            : '/home?page=' + pageNumber;
      items = await mainDiscover(path, key);
    }
    return { items, page: pageNumber, hasMore: items.length >= 20 };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
