(() => {
  'use strict';

  const BASE = 'https://ama.dramafuntv.com';
  const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
  const DEFAULT_HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Referer': BASE + '/',
  };

  function log(msg) {
    try { if (typeof console !== 'undefined' && console.log) console.log('[DramaFun] ' + msg); } catch (_) {}
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/&ntilde;/g, 'ñ')
      .replace(/&Ntilde;/g, 'Ñ')
      .replace(/&iacute;/g, 'í')
      .replace(/&aacute;/g, 'á')
      .replace(/&eacute;/g, 'é')
      .replace(/&oacute;/g, 'ó')
      .replace(/&uacute;/g, 'ú')
      .replace(/&Aacute;/g, 'Á')
      .replace(/&Eacute;/g, 'É')
      .replace(/&Iacute;/g, 'Í')
      .replace(/&Oacute;/g, 'Ó')
      .replace(/&Uacute;/g, 'Ú')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function decodeEntities(value) { return cleanText(value); }

  function absUrl(url, base) {
    const v = String(url || '').trim().replace(/\\\//g, '/');
    if (!v) return '';
    if (/^https?:\/\//i.test(v)) return v;
    if (v.startsWith('//')) return 'https:' + v;
    const root = base || BASE;
    if (v.startsWith('/')) return root.replace(/\/$/, '') + v;
    return root.replace(/\/$/, '') + '/' + v.replace(/^\/+/, '');
  }

  function attr(fragment, name) {
    const re = new RegExp(name + "\\s*=\\s*['\"]([^'\"]+)['\"]", 'i');
    const m = String(fragment || '').match(re);
    return m ? decodeEntities(m[1]) : '';
  }

  function uniqueById(items) {
    const seen = Object.create(null);
    const out = [];
    for (const item of items) {
      const id = item && item.id ? item.id : item && item.href ? item.href : JSON.stringify(item);
      if (!id || seen[id]) continue;
      seen[id] = true;
      out.push(item);
    }
    return out;
  }

  async function requestText(url, headers) {
    const res = await fetchv2(url, Object.assign({}, DEFAULT_HEADERS, headers || {}), 'GET', null);
    let body = '';
    if (res && typeof res.text === 'function') body = await res.text();
    if (!body && res && typeof res.body === 'string') body = res.body;
    if (!body && res && typeof res.json === 'function') {
      try { body = JSON.stringify(await res.json()); } catch (_) {}
    }
    if (!res || (res.status && res.status >= 400)) throw new Error('Request failed ' + (res && res.status ? res.status : '') + ' for ' + url);
    return String(body || '');
  }

  function parseCards(html) {
    const out = [];
    const re = /<li[^>]*class=["'][^"']*col-[^"']*["'][\s\S]*?<\/li>/gi;
    let m;
    while ((m = re.exec(html))) {
      const block = m[0];
      if (!/watch\.php\?vid=/i.test(block)) continue;
      const link = block.match(/<a[^>]+href=["']([^"']*watch\.php\?vid=[^"']+)["'][^>]*(?:title=["']([^"']*)["'])?/i);
      if (!link) continue;
      const href = absUrl(link[1]);
      const title = cleanText(link[2] || attr(block, 'alt') || block.match(/<h3>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i)?.[1] || 'DramaFun Video');
      const image = absUrl(attr(block, 'data-echo') || attr(block, 'src'));
      out.push({ title, image, id: href, href, url: href });
    }
    if (out.length) return uniqueById(out);

    const re2 = /<a[^>]+href=["']([^"']*watch\.php\?vid=[^"']+)["'][^>]*title=["']([^"']+)["'][\s\S]*?<img[^>]+>/gi;
    while ((m = re2.exec(html))) {
      const chunk = m[0];
      out.push({ title: cleanText(m[2]), image: absUrl(attr(chunk, 'data-echo') || attr(chunk, 'src')), id: absUrl(m[1]), href: absUrl(m[1]), url: absUrl(m[1]) });
    }
    return uniqueById(out);
  }

  function seriesTitleFromEpisode(title) {
    return cleanText(String(title || '')
      .replace(/\s+Cap[íi]tulo\s+\d+.*$/i, '')
      .replace(/\s+Capitulo\s+\d+.*$/i, '')
      .replace(/\s+Episodio\s+\d+.*$/i, '')
      .replace(/\s+Episode\s+\d+.*$/i, '')
      .replace(/\s+Final\s*$/i, '')
    ) || cleanText(title);
  }

  function groupEpisodeCards(cards) {
    const grouped = Object.create(null);
    const out = [];
    for (const card of cards) {
      const title = seriesTitleFromEpisode(card.title);
      const key = title.toLowerCase();
      if (!title || grouped[key]) continue;
      grouped[key] = true;
      out.push({
        title,
        image: card.image,
        id: card.href,
        href: card.href,
        url: card.href,
      });
    }
    return out;
  }

  async function searchResults(query) {
    const q = String(query || '').trim();
    const url = q ? BASE + '/search.php?keywords=' + encodeURIComponent(q) : BASE + '/newvideos.php';
    const html = await requestText(url);
    const cards = parseCards(html).slice(0, 40);
    return groupEpisodeCards(cards).slice(0, 30);
  }

  async function extractDetails(urlOrId) {
    const url = absUrl(urlOrId);
    const html = await requestText(url);
    const pageTitle = cleanText(html.match(/<meta\s+property=["']og:title["']\s+content=["']([^"']+)/i)?.[1] || html.match(/<title>([\s\S]*?)<\/title>/i)?.[1] || 'DramaFun');
    const title = seriesTitleFromEpisode(pageTitle);
    const image = absUrl(html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)/i)?.[1] || html.match(/<link\s+rel=["']image_src["']\s+href=["']([^"']+)/i)?.[1] || '');
    const desc = cleanText(html.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)/i)?.[1] || html.match(/<div\s+class=["']description["'][^>]*>([\s\S]*?)<\/div>/i)?.[1] || 'DramaFun video source.');
    const episodes = parseEpisodesFromHtml(html, url);
    return {
      title,
      description: desc,
      image,
      url,
      id: url,
      status: episodes.length > 1 ? 'Ongoing' : 'Unknown',
      author: 'DramaFun',
      totalEpisodes: episodes.length || 1,
    };
  }

  function parseEpisodeNumber(title, fallback) {
    const t = cleanText(title);
    const m = t.match(/(?:Cap[íi]tulo|Capitulo|Episodio|Episode)\s*(\d+)/i) || t.match(/\bE(?:p)?\s*(\d+)\b/i);
    return m ? parseInt(m[1], 10) : fallback;
  }

  function parseEpisodesFromHtml(html, currentUrl) {
    const out = [];
    const re = /<a[^>]+(?:title=["']([^"']*)["'][^>]+)?href=["']([^"']*watch\.php\?vid=[^"']+)["'][^>]*(?:title=["']([^"']*)["'])?[\s\S]*?<li>[\s\S]*?<em>(\d+)<\/em>[\s\S]*?<span>([\s\S]*?)<\/span>[\s\S]*?<\/li>\s*<\/a>/gi;
    let m;
    while ((m = re.exec(html))) {
      const href = absUrl(m[2]);
      const rawTitle = cleanText(m[1] || m[3] || ('Capitulo ' + m[4]));
      const number = parseInt(m[4], 10) || parseEpisodeNumber(rawTitle, out.length + 1);
      out.push({ number, season: 1, title: rawTitle || ('Capitulo ' + number), href, id: href, subAvailable: true, dubAvailable: false });
    }
    if (!out.length) {
      const opt = /<option\s+value=['"]([^'"]*watch\.php\?vid=[^'"]+)['"][^>]*>([\s\S]*?)<\/option>/gi;
      while ((m = opt.exec(html))) {
        const title = cleanText(m[2]);
        if (/lista/i.test(title)) continue;
        const number = parseEpisodeNumber(title, out.length + 1);
        const href = absUrl(m[1]);
        out.push({ number, season: 1, title: title || ('Capitulo ' + number), href, id: href, subAvailable: true, dubAvailable: false });
      }
    }
    if (!out.length && currentUrl) {
      const title = cleanText(html.match(/<meta\s+property=["']og:title["']\s+content=["']([^"']+)/i)?.[1] || html.match(/<title>([\s\S]*?)<\/title>/i)?.[1] || 'Episode 1');
      out.push({ number: parseEpisodeNumber(title, 1), season: 1, title, href: currentUrl, id: currentUrl, subAvailable: true, dubAvailable: false });
    }
    out.sort((a, b) => (a.number || 0) - (b.number || 0));
    return uniqueById(out.map((e, i) => Object.assign({}, e, { number: e.number || i + 1 })));
  }

  async function extractEpisodes(seriesId) {
    const url = absUrl(seriesId);
    const html = await requestText(url);
    return parseEpisodesFromHtml(html, url);
  }

  function b64Decode(value) {
    const input = String(value || '').replace(/\s/g, '');
    try {
      if (typeof atob === 'function') return atob(input);
    } catch (_) {}
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let output = '', buffer = 0, bits = 0;
    for (let i = 0; i < input.length; i++) {
      const c = chars.indexOf(input.charAt(i));
      if (c < 0 || c === 64) continue;
      buffer = (buffer << 6) | c;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        output += String.fromCharCode((buffer >> bits) & 0xff);
      }
    }
    return output;
  }

  function decodeServerPayload(html) {
    const m = String(html || '').match(/enfun\.php\?post=([^"'&]+)/i);
    if (!m) return {};
    try {
      const decoded = decodeURIComponent(m[1]);
      return JSON.parse(b64Decode(decoded));
    } catch (e) {
      log('payload decode failed ' + e);
      return {};
    }
  }

  function baseNToInt(str, base) {
    const chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let n = 0;
    for (let i = 0; i < str.length; i++) {
      const v = chars.indexOf(str.charAt(i));
      if (v < 0 || v >= base) return NaN;
      n = n * base + v;
    }
    return n;
  }

  function unpackPacker(source) {
    const text = String(source || '');
    const m = text.match(/eval\(function\(p,a,c,k,e,d\)[\s\S]*?\}\('([\s\S]*?)',(\d+),(\d+),'([\s\S]*?)'\.split\('\|'\)/);
    if (!m) return text;
    const payload = m[1].replace(/\\'/g, "'").replace(/\\\\/g, '\\');
    const radix = parseInt(m[2], 10);
    const words = m[4].split('|');
    return payload.replace(/\b[0-9a-zA-Z]+\b/g, (key) => {
      const index = baseNToInt(key, radix);
      return Number.isFinite(index) && words[index] ? words[index] : key;
    });
  }

  function extractPackedStreams(page, hostUrl) {
    const unpacked = unpackPacker(page);
    const out = [];
    const host = String(hostUrl || '').match(/^https?:\/\/[^/]+/i)?.[0] || '';
    const vidspeed = extractVidspeedDirectStream(page, unpacked);
    if (vidspeed) out.push(vidspeed);
    const fileRe = /(?:file|src)\s*[:=]\s*["']([^"']+(?:\.m3u8|\.mp4)[^"']*)["']/gi;
    let m;
    while ((m = fileRe.exec(unpacked))) out.push(absUrl(m[1], host));
    const urlRe = /https?:\/\/[^"'\s\\]+(?:\.m3u8|\.mp4)[^"'\s\\]*/gi;
    while ((m = urlRe.exec(unpacked))) out.push(m[0]);
    return out.map((u) => u.replace(/\\\//g, '/')).filter(Boolean);
  }

  function firstWord(words, tester) {
    for (const word of words) {
      if (tester(word)) return word;
    }
    return '';
  }

  function extractVidspeedDirectStream(page, unpacked) {
    const text = String(page || '');
    const packed = text.match(/\}\('([\s\S]*?)',(\d+),(\d+),'([\s\S]*?)'\.split\('\|'\)/);
    if (!packed) return '';
    const words = packed[4].split('|');
    const m3u8Index = words.indexOf('m3u8');
    if (m3u8Index < 1) return '';
    const token = words[m3u8Index - 1] || '';
    const fileId = words[m3u8Index + 3] || '';
    if (!/^[A-Za-z0-9_-]{40,}$/.test(token) || !/^[A-Za-z0-9_-]+_$/.test(fileId)) return '';

    const imageMatch = text.match(/https?:\/\/([^"'\\\s]+)\/i\/(\d+)\/(\d+)\/[^"'\\\s]+\.jpg/i);
    const host = imageMatch ? imageMatch[1] : 'vsped-store4-lwa.cdnz.quest';
    const folderA = imageMatch ? imageMatch[2] : firstWord(words, (w) => /^\d{2}$/.test(w));
    const folderB = imageMatch ? imageMatch[3] : firstWord(words, (w) => /^\d{5}$/.test(w));
    const expires = words[m3u8Index - 2] && /^\d+$/.test(words[m3u8Index - 2]) ? words[m3u8Index - 2] : '43200';
    const stamp = firstWord(words, (w) => /^1\d{9}$/.test(w));
    const version = firstWord(words, (w) => /^\d{7,}$/.test(w));
    const ipFlag = String(unpacked || '').match(/[?&]i=([^&"']+)/i)?.[1] || '0.0';

    if (!folderA || !folderB || !stamp || !version) return '';
    return 'https://' + host + '/hls2/' + folderA + '/' + folderB + '/' + fileId +
      ',l,n,.urlset/master.m3u8?t=' + token +
      '&s=' + stamp +
      '&e=' + expires +
      '&v=' + version +
      '&i=' + ipFlag +
      '&sp=0';
  }

  async function probePlayable(url, referer) {
    try {
      const headers = {
        'User-Agent': UA,
        'Accept': 'application/vnd.apple.mpegurl,application/x-mpegURL,video/mp4,*/*',
        'Referer': referer || BASE + '/',
      };
      const body = await requestText(url, headers);
      if (/\.mp4(?:\?|$)/i.test(url)) return true;
      return /^#EXTM3U/i.test(body.trim()) || /#EXT-X-/i.test(body);
    } catch (_) {
      return false;
    }
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function extractFromHost(hostName, hostUrl) {
    const normalizedHostUrl = playbackReferer(hostUrl);
    const maxAttempts = /vidspeed/i.test(normalizedHostUrl) ? 3 : 1;
    const errors = [];
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const fetchUrl = /vidspeed/i.test(normalizedHostUrl)
        ? normalizedHostUrl + (normalizedHostUrl.indexOf('?') >= 0 ? '&' : '?') + '_=' + Date.now() + '_' + attempt
        : normalizedHostUrl;
      try {
        const page = await requestText(fetchUrl, {
          'Referer': BASE + '/',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
        });
        const candidates = extractPackedStreams(page, fetchUrl);
        if (/vidspeed/i.test(normalizedHostUrl)) {
          const hls = candidates.find((u) => /\.m3u8(?:\?|$)/i.test(u));
          if (hls) return { label: hostName, url: hls, referer: hostUrl };
        }
        for (const u of candidates) {
          if (await probePlayable(u, hostUrl)) {
            return { label: hostName, url: u, referer: hostUrl };
          }
        }
        if (!candidates.length) errors.push('no stream candidates');
        else errors.push('stream candidates were not playable');
      } catch (e) {
        errors.push(e && e.message ? e.message : String(e));
      }
      if (attempt + 1 < maxAttempts) await delay(180);
    }
    if (errors.length) log(hostName + ' failed: ' + errors.join(' | '));
    return null;
  }

  function playbackReferer(hostUrl) {
    return String(hostUrl || '').replace(/^https:\/\/(?:www\.)?vidspeeds\.com/i, 'https://vidspeed.org');
  }

  function hostLabel(hostUrl) {
    const url = String(hostUrl || '').toLowerCase();
    if (url.indexOf('vidspeed') >= 0) return 'Vidspeeds';
    if (url.indexOf('ok.ru') >= 0) return 'Ok.ru';
    if (url.indexOf('uqload') >= 0) return 'Uqload';
    if (url.indexOf('voe.') >= 0) return 'Voe';
    if (url.indexOf('dood.') >= 0) return 'Dood';
    return 'Host';
  }

  function extractVideoId(url) {
    return String(url || '').match(/[?&]vid=([^&#]+)/i)?.[1] || '';
  }

  function parseAjaxHosts(html) {
    const out = [];
    const seen = Object.create(null);
    const re = /https?:\/\/[^\s<>"']+/gi;
    let m;
    while ((m = re.exec(String(html || '')))) {
      const hostUrl = m[0].replace(/&amp;/g, '&').trim();
      if (!/vidspeed|ok\.ru|uqload|voe\.|dood\./i.test(hostUrl)) continue;
      if (seen[hostUrl]) continue;
      seen[hostUrl] = true;
      out.push({ name: hostLabel(hostUrl), url: hostUrl });
    }
    return out;
  }

  async function ajaxServers(videoId, episodeUrl) {
    if (!videoId) return [];
    const ajaxUrl = BASE + '/ajax.php?p=video&do=getplayer&vid=' + encodeURIComponent(videoId);
    const html = await requestText(ajaxUrl, {
      'Referer': episodeUrl || BASE + '/',
      'X-Requested-With': 'XMLHttpRequest',
    });
    const hosts = parseAjaxHosts(html);
    const rank = { 'Vidspeeds': 1, 'Ok.ru': 2, 'Uqload': 3, 'Voe': 4, 'Dood': 5 };
    hosts.sort((a, b) => (rank[a.name] || 99) - (rank[b.name] || 99));
    return hosts;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = absUrl(episodeHref);
    const html = await requestText(url);
    const payload = decodeServerPayload(html);
    const servers = payload && payload.servers ? payload.servers : {};
    const ajax = await ajaxServers(extractVideoId(url), url).catch((e) => {
      log('ajax player failed ' + e);
      return [];
    });
    const serverList = ajax.length
      ? ajax
      : Object.keys(servers).map((name) => ({ name, url: servers[name] })).filter((item) => item.url);
    const errors = [];
    for (const item of serverList) {
      const name = item.name || hostLabel(item.url);
      const serverUrl = item.url;
      try {
        const result = await extractFromHost(name, serverUrl);
        if (result && result.url) {
          return {
            streams: [result.label, result.url],
            streamType: /\.mp4(?:\?|$)/i.test(result.url) ? 'mp4' : 'hls',
            subtitles: [],
            headers: {
              'User-Agent': UA,
              'Referer': playbackReferer(result.referer),
              'Origin': String(playbackReferer(result.referer)).match(/^https?:\/\/[^/]+/i)?.[0] || BASE,
            },
          };
        }
      } catch (e) {
        errors.push(name + ': ' + (e && e.message ? e.message : e));
      }
    }
    throw new Error('No playable DramaFun stream found. Checked hosts: ' + serverList.map((item) => item.name || hostLabel(item.url)).join(', ') + (errors.length ? ' errors=' + errors.join(' | ') : ''));
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
})();
