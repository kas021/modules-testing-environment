(() => {
  'use strict';

  const MODULE_NAME = 'KickAssAnimeV4';
  const BASE_URL = 'https://kaa.lt';
  const IMG_BASE = BASE_URL + '/image/poster/';
  const MAX_EPISODES = 1300;
  const MAX_SEARCH_PAGES = 120;
  const SEARCH_PAGE_BATCH = 6;
  const PAGE_FETCH_TIMEOUT_MS = 9000;
  const EMBED_TIMEOUT_MS = 8000;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const watchUriCache = {};
  const catalogCache = {};
  let catalogMaxPage = 0;
  let catalogScanDone = false;

  const defaultHeaders = {
    'User-Agent': USER_AGENT,
    Accept: '*/*',
    Referer: BASE_URL + '/',
  };

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, Math.max(1, Number(ms) || 0));
    });
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(function () { return fallback; })]);
  }

  function decodeHtml(str) {
    return String(str || '')
      .replace(/\\u([0-9a-f]{4})/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#039;/g, "'")
      .replace(/&#39;/g, "'")
      .replace(/^"|"$/g, '')
      .trim();
  }

  function safeJsonParse(text) {
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  function isResponseOk(res, status) {
    if (res && (res.ok === true || res.ok === 1)) return true;
    if (res && (res.ok === false || res.ok === 0)) return false;
    return status >= 200 && status < 300;
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try {
        return JSON.stringify(res.json);
      } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        return typeof text === 'string' ? text : '';
      } catch (_) {
        return '';
      }
    }
    return '';
  }

  async function readResponseJson(res, textBody) {
    if (res && res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      return res.json;
    }
    let json = safeJsonParse(textBody);
    if (json != null) return json;
    if (res && typeof res.json === 'function') {
      try {
        json = await res.json();
        if (json != null) return json;
      } catch (_) {}
    }
    return null;
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign({}, defaultHeaders, cfg.headers || {});
    const body = cfg.body == null ? null : cfg.body;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        return {
          ok: isResponseOk(res, status),
          status,
          body: textBody,
          json: await readResponseJson(res, textBody),
        };
      }

      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
        };
      }

      return { ok: false, status: 0, body: '', json: null };
    } catch (error) {
      log('request error: ' + (error && error.message ? error.message : String(error)));
      return { ok: false, status: 0, body: '', json: null };
    }
  }

  function buildPosterUrl(poster) {
    if (!poster) return '';
    const key = poster.sm || poster.hq || '';
    if (!key) return '';
    return IMG_BASE + key + '.webp';
  }

  function normalizeSlug(href) {
    const raw = String(href || '').trim().replace(/^https?:\/\/[^/]+/i, '');
    return raw.replace(/^\//, '').split('/')[0];
  }

  function parseOrigin(url) {
    const match = String(url || '').match(/^(https?:\/\/[^/]+)/i);
    return match ? match[1] : BASE_URL;
  }

  function slugifyQuery(query) {
    return String(query || '')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  function normForMatch(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .replace(/[’'`´:;.!?&,+()\[\]{}<>/\\|–—"]/g, ' ')
      .replace(/[\u2010-\u2015\u00b7]/g, ' ')
      .replace(/\bs\b/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function compactForMatch(value) {
    return normForMatch(value).replace(/[^a-z0-9]/g, '');
  }

  function rankSearchItem(item, query) {
    const q = String(query || '').trim().toLowerCase();
    const slugQ = slugifyQuery(q);
    const normQ = normForMatch(q);
    const compactQ = compactForMatch(q);
    const title = decodeHtml(item.title || item.title_en || '').toLowerCase();
    const titleEn = decodeHtml(item.title_en || item.title || '').toLowerCase();
    const slug = String(item.slug || '').toLowerCase();
    const type = String(item.type || '').toLowerCase();
    if (!q) return 5;

    const titleNorm = normForMatch(title);
    const titleEnNorm = normForMatch(titleEn);
    const titleCompact = compactForMatch(title);
    const slugCompact = compactForMatch(slug);

    if (compactQ && compactQ.length >= 3) {
      if (titleEnNorm === normQ || titleNorm === normQ || titleCompact === compactQ) {
        if (type === 'tv' || type === 'ona' || type === 'ova') return 0;
        return 1;
      }
      if (titleCompact.includes(compactQ) && compactQ.length >= 4) return 2;
    }
    if (slug === slugQ) return 3;
    if (
      new RegExp('^' + slugQ.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-[a-z0-9]+$').test(slug)
    ) {
      return 4;
    }
    if (titleEnNorm.includes(normQ) || titleNorm.includes(normQ)) return 5;
    if (slugCompact.includes(compactQ) && compactQ.length >= 3) return 6;
    if (titleEn.includes(q) || title.includes(q)) return 7;
    if (slug.startsWith(slugQ + '-')) return 8;
    if (slug.includes(slugQ)) return 9;
    return 10;
  }

  async function fetchCatalogPage(page) {
    if (catalogCache[page] !== undefined) return catalogCache[page];
    const res = await settleWithin(
      request(BASE_URL + '/api/anime?page=' + page + '&perPage=30', {
        headers: { Accept: 'application/json' },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json || !Array.isArray(res.json.result)) {
      delete catalogCache[page];
      return null;
    }
    const items = res.json.result;
    catalogCache[page] = items;
    const maxPage = Number(res.json.maxPage || 0);
    if (maxPage > catalogMaxPage) catalogMaxPage = maxPage;
    for (const item of items) {
      const slug = String(item.slug || '').trim();
      if (slug && item.watch_uri) {
        watchUriCache[slug] = String(item.watch_uri).trim();
      }
    }
    return items;
  }

  async function scanCatalogFor(query) {
    const q = String(query == null ? '' : query).trim().toLowerCase();
    const slugQ = slugifyQuery(q);
    const normQ = normForMatch(q);
    const compactQ = compactForMatch(q);
    const results = [];
    const seen = new Set();

    if (!q) {
      const pageItems = await fetchCatalogPage(1);
      for (const item of pageItems || []) {
        const slug = String(item.slug || '').trim();
        if (!slug || seen.has(slug)) continue;
        seen.add(slug);
        results.push({
          title: decodeHtml(item.title_en || item.title || slug),
          href: slug,
          image: buildPosterUrl(item.poster),
        });
        if (results.length >= 30) break;
      }
      return results;
    }

    let maxPage = catalogMaxPage;
    if (!maxPage) {
      const first = await fetchCatalogPage(1);
      if (first === null) {
        const res = await request(BASE_URL + '/api/anime?page=1&perPage=30', {
          headers: { Accept: 'application/json' },
        });
        if (res.ok && res.json && Array.isArray(res.json.result)) {
          catalogCache[1] = res.json.result;
          maxPage = Number(res.json.maxPage || 0);
        }
      }
      maxPage = maxPage || catalogMaxPage || 1;
    }

    let exactMatch = false;
    for (let start = 1; start <= maxPage; start += SEARCH_PAGE_BATCH) {
      const pages = [];
      for (let page = start; page < start + SEARCH_PAGE_BATCH && page <= maxPage; page += 1) {
        pages.push(page);
      }
      const batches = await Promise.all(pages.map((page) => fetchCatalogPage(page)));
      let fetchFailures = 0;
      for (let bi = 0; bi < batches.length; bi += 1) {
        if (!batches[bi]) {
          const retry = await fetchCatalogPage(pages[bi]);
          if (!retry) {
            fetchFailures += 1;
            continue;
          }
          batches[bi] = retry;
        }
      }
      for (const pageItems of batches) {
        if (!pageItems) {
          fetchFailures += 1;
          continue;
        }
        for (const item of pageItems) {
          const title = decodeHtml(item.title_en || item.title || '');
          const slug = String(item.slug || '').trim();
          if (!slug || seen.has(slug)) continue;
          const titleLower = title.toLowerCase();
          const slugLower = slug.toLowerCase();
          const titleNorm = normForMatch(title);
          const titleCompact = compactForMatch(title);
          const slugCompact = compactForMatch(slug);
          const matches =
            titleLower.includes(q) ||
            slugLower.includes(slugQ) ||
            slugLower.startsWith(slugQ + '-') ||
            (compactQ && compactQ.length >= 3 && titleCompact.includes(compactQ)) ||
            (compactQ && compactQ.length >= 3 && slugCompact.includes(compactQ)) ||
            (normQ && normQ.length >= 3 && titleNorm.includes(normQ));
          if (!matches) continue;
          seen.add(slug);
          const rank = rankSearchItem(item, q);
          results.push({
            title,
            href: slug,
            image: buildPosterUrl(item.poster),
            _rank: rank,
          });
          if (rank === 0) exactMatch = true;
        }
      }
      if (exactMatch) break;
      if (fetchFailures && fetchFailures < pages.length) await sleep(250);
    }

    const hasStrongMatch = results.some((r) => r._rank <= 1);
    if (!hasStrongMatch && compactQ && compactQ.length >= 5) {
      for (let start = 1; start <= maxPage; start += SEARCH_PAGE_BATCH) {
        const pages = [];
        for (let page = start; page < start + SEARCH_PAGE_BATCH && page <= maxPage; page += 1) {
          pages.push(page);
        }
        const batches = await Promise.all(pages.map((page) => fetchCatalogPage(page)));
        for (const pageItems of batches) {
          if (!pageItems) continue;
          for (const item of pageItems) {
            const title = decodeHtml(item.title_en || item.title || '');
            const slug = String(item.slug || '').trim();
            if (!slug || seen.has(slug)) continue;
            const titleCompact = compactForMatch(title);
            const prefixTrim =
              (titleCompact.startsWith(compactQ) || compactQ.startsWith(titleCompact)) &&
              titleCompact.length >= 5;
            if (prefixTrim) {
              seen.add(slug);
              const exactish =
                compactQ.startsWith(titleCompact) && compactQ.length - titleCompact.length <= 3;
              results.push({
                title,
                href: slug,
                image: buildPosterUrl(item.poster),
                _rank: exactish ? 1 : 6,
              });
            }
          }
        }
      }
    }

    if (!results.length && slugQ) {
      const direct = await settleWithin(
        request(BASE_URL + '/api/show/' + encodeURIComponent(slugQ), {
          headers: { Accept: 'application/json' },
        }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      if (direct && direct.ok && direct.json && direct.json.slug) {
        results.push({
          title: decodeHtml(direct.json.title_en || direct.json.title || slugQ),
          href: String(direct.json.slug),
          image: buildPosterUrl(direct.json.poster),
          _rank: 0,
        });
      }
    }

    results.sort((a, b) => {
      if (a._rank !== b._rank) return a._rank - b._rank;
      return a.href.length - b.href.length;
    });
    return results.slice(0, 30).map((item) => ({
      title: item.title,
      href: item.href,
      image: item.image,
    }));
  }

  function extractKaaServers(html) {
    const source = decodeHtml(String(html || ''));
    const match = source.match(/servers:\[(\{.+?\}(?:,\{.+?\})*)\]/s);
    if (!match) return [];
    const raw = match[1];
    const nameMatches = [...raw.matchAll(/name:"([^"]+)"/g)];
    const srcMatches = [...raw.matchAll(/src:"([^"]+)"/g)];
    const servers = [];
    for (let i = 0; i < srcMatches.length; i += 1) {
      const src = decodeHtml(srcMatches[i][1]);
      if (!src || !src.startsWith('http')) continue;
      const name = nameMatches[i] ? decodeHtml(nameMatches[i][1]) : 'Server ' + (i + 1);
      servers.push({ name, src });
    }
    return servers;
  }

  function extractNextEpSlug(html) {
    const m = String(html || '').match(/next_ep_slug:"([^"]+)"/);
    return m ? decodeHtml(m[1]) : null;
  }

  function normalizeStreamUrl(url) {
    const raw = String(url || '').trim();
    if (!raw) return '';
    if (raw.startsWith('//')) return 'https:' + raw;
    return raw;
  }

  function unescapeManifest(text) {
    let t = String(text || '');
    t = t.replace(/\\u0026/g, '&').replace(/\\u002F/g, '/').replace(/\\\//g, '/');
    t = t.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
    return t;
  }

  function pickStreamFromHtml(html) {
    const text = unescapeManifest(decodeHtml(String(html || '')));

    const manifestMatch =
      text.match(/"manifest"\s*:\s*\[[^\]]*"(https?:\/\/[^"]+?\.m3u8[^"]*)"/i) ||
      text.match(/"manifest"\s*:\s*\[[^\]]*"(https?:\/\/[^"]+?\.m3u8[^"]*)"/i) ||
      text.match(/manifest\s*:\s*\[[^\]]*"(https?:\/\/[^"]+?\.m3u8[^"]*)"/i);
    if (manifestMatch && manifestMatch[1]) {
      return { url: normalizeStreamUrl(manifestMatch[1]), streamType: 'hls' };
    }

    const m3u8 =
      text.match(/https?:\/\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i) ||
      text.match(/\/\/[a-z0-9.-]+\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i);
    if (m3u8 && m3u8[0]) return { url: normalizeStreamUrl(m3u8[0]), streamType: 'hls' };

    const mp4 =
      text.match(/https?:\/\/[^"'\s<>]+?\.mp4(?:\?[^"'\s<>]*)?/i) ||
      text.match(/\/\/[a-z0-9.-]+\/[^"'\s<>]+?\.mp4(?:\?[^"'\s<>]*)?/i);
    if (mp4 && mp4[0]) return { url: normalizeStreamUrl(mp4[0]), streamType: 'mp4' };

    return null;
  }

  async function resolveEmbedStream(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, {
        headers: {
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*',
          Referer: BASE_URL + '/',
        },
      }),
      EMBED_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.body) return null;
    const picked = pickStreamFromHtml(res.body);
    if (!picked) return null;
    return {
      url: picked.url,
      streamType: picked.streamType,
      headers: {
        Referer: embedUrl,
        Origin: parseOrigin(embedUrl),
        'User-Agent': USER_AGENT,
        Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/mp4,*/*',
      },
    };
  }

  async function findCatalogItem(slug) {
    const target = String(slug || '').trim();
    if (!target) return null;
    let maxPage = catalogMaxPage;
    if (!maxPage) {
      const first = await fetchCatalogPage(1);
      if (first === null) return null;
      maxPage = catalogMaxPage;
    }
    for (let start = 1; start <= maxPage; start += SEARCH_PAGE_BATCH) {
      const pages = [];
      for (let page = start; page < start + SEARCH_PAGE_BATCH && page <= maxPage; page += 1) {
        pages.push(page);
      }
      const batches = await Promise.all(pages.map((page) => fetchCatalogPage(page)));
      for (const pageItems of batches) {
        if (!pageItems) continue;
        const hit = pageItems.find((item) => String(item.slug || '').trim() === target);
        if (hit) return hit;
      }
    }
    return null;
  }

  function normalizeWatchUri(path) {
    const value = String(path || '').trim();
    if (!value) return '';
    return value.startsWith('/') ? value : '/' + value;
  }

  async function fetchShowDetails(slug) {
    const res = await settleWithin(
      request(BASE_URL + '/api/show/' + encodeURIComponent(slug), {
        headers: { Accept: 'application/json' },
      }),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json) return null;
    return res.json;
  }

  async function resolveActiveWatchUri(slug) {
    const candidates = [];
    if (watchUriCache[slug]) {
      candidates.push(normalizeWatchUri(watchUriCache[slug]));
    }

    const show = await fetchShowDetails(slug);
    if (show && show.watch_uri) {
      candidates.push(normalizeWatchUri(show.watch_uri));
    }

    if (!candidates.length) {
      const catalogItem = await findCatalogItem(slug);
      if (catalogItem && catalogItem.watch_uri) {
        candidates.push(normalizeWatchUri(catalogItem.watch_uri));
      }
    }

    const unique = [];
    const seen = new Set();
    for (const candidate of candidates) {
      if (!candidate || seen.has(candidate)) continue;
      seen.add(candidate);
      unique.push(candidate);
    }

    for (const candidate of unique) {
      const resolved = await resolveEpisodeServers(candidate);
      if (resolved.servers.length) return candidate;
    }
    return unique[0] || '';
  }

  const searchResultCache = {};

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    const cacheKey = 'q:' + q;
    try {
      let all = searchResultCache[cacheKey];
      if (!all) {
        all = await scanCatalogFor(q);
        searchResultCache[cacheKey] = all;
      }
      const start = (pageNumber - 1) * 30;
      if (start <= 0) return all;
      return all.slice(start, start + 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    const slug = normalizeSlug(urlOrId);
    if (!slug) {
      return { title: 'Unknown', description: 'No description available.' };
    }

    const data = await fetchShowDetails(slug);
    if (data) {
      return {
        title: decodeHtml(data.title_en || data.title || slug),
        description: decodeHtml(data.synopsis || ''),
        airdate: data.year ? String(data.year) : '',
        image: buildPosterUrl(data.poster),
      };
    }

    return { title: slug, description: 'No description available.' };
  }

  async function fetchEpisodesPage(slug, page) {
    const res = await settleWithin(
      request(
        BASE_URL + '/api/show/' + encodeURIComponent(slug) + '/episodes?page=' + page + '&lang=ja-JP',
        { headers: { Accept: 'application/json' } },
      ),
      PAGE_FETCH_TIMEOUT_MS,
      null,
    );
    if (!res || !res.ok || !res.json) return null;
    return res.json;
  }

  async function extractEpisodes(seriesId) {
    const slug = normalizeSlug(seriesId);
    if (!slug) return [];

    const episodes = [];
    const seenNumbers = new Set();
    let pagesField = 0;

    for (let page = 1; page <= 40; page += 1) {
      const data = await fetchEpisodesPage(slug, page);
      if (!data) break;
      if (!Array.isArray(data.result) || !data.result.length) break;
      if (!pagesField && Array.isArray(data.pages)) pagesField = data.pages.length;

      for (const ep of data.result) {
        const epNum = Number(ep.episode_number || 0);
        if (epNum < 1 || seenNumbers.has(epNum)) continue;
        seenNumbers.add(epNum);
        const epSlug = String(ep.slug || '').trim();
        const epString = String(ep.episode_string || String(epNum));
        const href = '/' + slug + '/ep-' + epString + (epSlug ? '-' + epSlug : '');
        episodes.push({
          number: epNum,
          href: href,
          subAvailable: true,
          dubAvailable: false,
          title: String(ep.title || '').trim(),
        });
        if (episodes.length >= MAX_EPISODES) break;
      }

      if (episodes.length >= MAX_EPISODES) break;
      if (pagesField && page >= pagesField) break;
      if (data.result.length < 100) break;
    }

    if (episodes.length) return episodes;

    let watchUri = watchUriCache[slug] || (await resolveActiveWatchUri(slug));
    watchUri = String(watchUri || '').replace(/\\u([0-9a-f]{4})/gi, (_, h) =>
      String.fromCharCode(parseInt(h, 16)),
    );
    if (!watchUri) return [];

    const walkEpisodes = [];
    const seenPaths = new Set();
    let currentEpPath = watchUri.startsWith('/') ? watchUri : '/' + watchUri;
    let guard = 0;

    while (currentEpPath && walkEpisodes.length < MAX_EPISODES && guard < 400) {
      guard += 1;
      if (seenPaths.has(currentEpPath)) break;
      seenPaths.add(currentEpPath);

      const epRes = await settleWithin(
        request(BASE_URL + currentEpPath, {
          headers: { Accept: 'text/html,application/xhtml+xml' },
        }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      if (!epRes || !epRes.ok || !epRes.body) break;

      const epNumMatch = currentEpPath.match(/\/ep-(\d+)-/);
      const epNum = epNumMatch ? parseInt(epNumMatch[1], 10) : walkEpisodes.length + 1;

      walkEpisodes.push({
        number: epNum,
        href: currentEpPath,
        subAvailable: true,
        dubAvailable: false,
      });

      const nextSlug = extractNextEpSlug(epRes.body);
      if (!nextSlug) break;
      currentEpPath = '/' + slug + '/' + nextSlug.replace(/^\//, '');
    }

    return walkEpisodes;
  }

  async function resolveEpisodeServers(episodePath) {
    let currentPath = String(episodePath || '').trim();
    if (!currentPath) return { servers: [], epPath: '' };

    for (let attempt = 0; attempt < 4; attempt += 1) {
      const epUrl = currentPath.startsWith('http')
        ? currentPath
        : BASE_URL + (currentPath.startsWith('/') ? currentPath : '/' + currentPath);
      const epRes = await settleWithin(
        request(epUrl, {
          headers: { Accept: 'text/html,application/xhtml+xml' },
        }),
        6000,
        null,
      );
      if (!epRes || !epRes.ok || !epRes.body) break;

      const servers = extractKaaServers(epRes.body);
      if (servers.length) {
        return { servers, epPath: currentPath, epUrl };
      }

      const nextSlug = extractNextEpSlug(epRes.body);
      if (!nextSlug) break;
      const slug = normalizeSlug(currentPath);
      currentPath = '/' + slug + '/' + String(nextSlug).replace(/^\//, '');
    }

    return { servers: [], epPath: episodePath, epUrl: '' };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const path = String(episodeHref || '').trim();
    if (!path) return { streams: [] };

    const deadline = settleWithin(
      (async () => {
        let resolved = await resolveEpisodeServers(path);
        if (!resolved.servers.length) {
          const slug = normalizeSlug(path);
          const activeWatch = await resolveActiveWatchUri(slug);
          if (activeWatch) {
            resolved = await resolveEpisodeServers(activeWatch);
          }
        }
        const servers = resolved.servers;
        if (!servers.length) return { streams: [] };

        const epUrl =
          resolved.epUrl ||
          (path.startsWith('http')
            ? path
            : BASE_URL + (path.startsWith('/') ? path : '/' + path));

        const label = String(lang || '').toLowerCase() === 'dub' ? 'dub' : 'sub';
        const streams = [];
        let headers = {
          Referer: BASE_URL + '/',
          Origin: BASE_URL,
          'User-Agent': USER_AGENT,
        };
        let streamType = 'hls';

        for (const server of servers) {
          const embed = await resolveEmbedStream(server.src);
          if (!embed || !embed.url) continue;
          streams.push(server.name || 'Stream', embed.url);
          headers = Object.assign({}, headers, embed.headers || {});
          streamType = embed.streamType || 'hls';
          break;
        }

        if (!streams.length) {
          return { streams: [] };
        }

        return {
          streams,
          headers,
          quality: 'auto',
          lang: label,
          streamType,
        };
      })(),
      16000,
      { streams: [] }
    );
    return deadline;
  }

  async function discoveryHome() {
    const sections = [];
    try {
      const trendingRes = await settleWithin(
        request(BASE_URL + '/api/anime_trending', { headers: { Accept: 'application/json' } }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      if (trendingRes && trendingRes.ok && Array.isArray(trendingRes.json)) {
        const items = [];
        const seen = new Set();
        for (const item of trendingRes.json) {
          const slug = String(item.slug || '').trim();
          if (!slug || seen.has(slug)) continue;
          seen.add(slug);
          items.push({
            title: decodeHtml(item.title_en || item.title || slug),
            href: slug,
            image: buildPosterUrl(item.poster),
          });
          if (items.length >= 20) break;
        }
        if (items.length) {
          sections.push({
            id: 'trending',
            title: 'Trending',
            style: 'poster',
            items: items,
            viewAll: { mode: 'feed', feedId: 'trending' },
          });
        }
      }

      const pageItems = await fetchCatalogPage(1);
      if (Array.isArray(pageItems) && pageItems.length) {
        const items = [];
        for (const item of pageItems) {
          const slug = String(item.slug || '').trim();
          if (!slug) continue;
          items.push({
            title: decodeHtml(item.title_en || item.title || slug),
            href: slug,
            image: buildPosterUrl(item.poster),
          });
          if (items.length >= 30) break;
        }
        if (items.length) {
          sections.push({
            id: 'browse',
            title: 'Browse',
            style: 'poster',
            items: items,
            viewAll: { mode: 'feed', feedId: 'browse' },
          });
        }
      }
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const key = String(feedId || '').trim().toLowerCase();
    const pageNumber = Math.max(1, Number(page) || 1);
    const items = [];
    if (key === 'trending' || key === 'trend') {
      const trendingRes = await settleWithin(
        request(BASE_URL + '/api/anime_trending', { headers: { Accept: 'application/json' } }),
        PAGE_FETCH_TIMEOUT_MS,
        null,
      );
      if (trendingRes && trendingRes.ok && Array.isArray(trendingRes.json)) {
        for (const item of trendingRes.json) {
          const slug = String(item.slug || '').trim();
          if (!slug) continue;
          items.push({
            title: decodeHtml(item.title_en || item.title || slug),
            href: slug,
            image: buildPosterUrl(item.poster),
          });
        }
      }
      return { items, page: 1, hasMore: false };
    }

    const pageItems = await fetchCatalogPage(pageNumber);
    if (Array.isArray(pageItems)) {
      for (const item of pageItems) {
        const slug = String(item.slug || '').trim();
        if (!slug) continue;
        items.push({
          title: decodeHtml(item.title_en || item.title || slug),
          href: slug,
          image: buildPosterUrl(item.poster),
        });
      }
    }
    const maxPage = catalogMaxPage || pageNumber;
    return { items, page: pageNumber, hasMore: pageNumber < maxPage };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
