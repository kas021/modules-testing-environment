(() => {
  'use strict';

  const MODULE_NAME = 'Shahiid';
  const SITE = 'https://shahiid-anime.net';
  const MEGAMAX = 'https://megamax.me';
  const MAX_EPISODES = 5000;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        const value = await res.json();
        return JSON.stringify(value);
      } catch (_) {}
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        let contentType = String((res && res.contentType) || '');
        if (!contentType && res && res.headers && typeof res.headers === 'object') {
          contentType = String(res.headers['content-type'] || res.headers['Content-Type'] || '');
        }
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          body: textBody,
          json: safeJsonParse(textBody),
          contentType,
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: safeJsonParse(textBody),
          contentType: String((res.headers && res.headers.get) ? res.headers.get('content-type') || '' : ''),
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null, contentType: '' };
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  // ── Shahiid page fetch ────────────────────────────────────────────────────
  // shahiid-anime.net is Cloudflare-JS-challenged for plain HTTP clients. On
  // device, pagev2 (headless WKWebView) resolves the challenge and returns the
  // rendered HTML. In environments without pagev2, return null.
  async function fetchShahiidPage(url, waitForSelector) {
    if (typeof pagev2 === 'function') {
      try {
        const result = await pagev2({
          url: url,
          timeoutMs: 30000,
          settleMs: 2500,
          includeHtml: true,
          userAgent: USER_AGENT,
          waitForSelector: waitForSelector || '',
        });
        const html = String((result && result.html) || '');
        if (html && !/Just a moment/i.test(html) && !/security verification/i.test(html)) {
          return html;
        }
      } catch (e) {
        log('pagev2 fetch failed: ' + (e && e.message ? e.message : String(e)));
      }
      return null;
    }
    // Fallback: plain fetch (usually CF-blocked, but try).
    const res = await settleWithin(
      request(url, { headers: { Accept: 'text/html,*/*' } }),
      15000,
      null,
    );
    if (!res || !res.ok || !res.body || /Just a moment/i.test(res.body)) return null;
    return res.body;
  }

  // ── Megamax stream chain (fully verified) ─────────────────────────────────

  // Fetch a megamax iframe page to obtain the Inertia version + set cookies,
  // then request the deferred "streams" prop for the mirror list.
  async function megamaxStreams(hashId) {
    const iframeUrl = MEGAMAX + '/iframe/' + encodeURIComponent(hashId);
    const page = await settleWithin(
      request(iframeUrl, { headers: { Accept: 'text/html,*/*' } }),
      15000,
      null,
    );
    if (!page || !page.ok || !page.body) return [];
    const versionMatch = page.body.match(/"version":"([^"]+)"/);
    const componentMatch = page.body.match(/"component":"([^"]+)"/);
    if (!versionMatch || !componentMatch) return [];
    const version = versionMatch[1];
    const component = String(componentMatch[1]).replace(/\\\//g, '/');

    const streamsRes = await settleWithin(
      request(iframeUrl + '?prop=streams', {
        headers: {
          Accept: 'text/html, application/xhtml+xml',
          'X-Inertia': 'true',
          'X-Inertia-Version': version,
          'X-Inertia-Partial-Component': component,
          'X-Inertia-Partial-Data': 'streams,subtitles',
          Referer: iframeUrl,
        },
      }),
      15000,
      null,
    );
    if (!streamsRes || !streamsRes.ok) {
      log('streams call failed: status=' + (streamsRes && streamsRes.status) + ' ok=' + (streamsRes && streamsRes.ok));
      return [];
    }
    const envelope = streamsRes.json || safeJsonParse(streamsRes.body);
    if (!envelope || !envelope.props || !envelope.props.streams) {
      log('streams envelope missing: body=' + String(streamsRes.body || '').substring(0, 120));
      return [];
    }
    const streams = envelope.props.streams;
    if (!streams || streams.status !== 'success' || !Array.isArray(streams.data)) return [];
    const mirrors = [];
    for (const item of streams.data) {
      const itemMirrors = Array.isArray(item.mirrors) ? item.mirrors : [];
      for (const mir of itemMirrors) {
        mirrors.push({
          driver: String(mir.driver || ''),
          link: String(mir.link || ''),
          hashId: String(item.hashId || ''),
          resolution: String(item.resolution || item.label || ''),
        });
      }
    }
    return mirrors;
  }

  // Decode a PackedJS (p,a,c,k,e,d) string and return the decoded script.
  function unpackPacked(script) {
    const m = script.match(/function\(p,a,c,k,e,d\)\{.*?\}\('(.*?)',(\d+),(\d+),'(.*?)',(.*?)\)\)/s);
    if (!m) return null;
    const p = m[1];
    const a = Number(m[2]);
    const c = Number(m[3]);
    const k = (m[4] || '').split('|');
    const digits = '0123456789abcdefghijklmnopqrstuvwxyz';
    function radix(n) {
      if (n === 0) return '0';
      let out = '';
      while (n) { out = digits[n % a] + out; n = Math.floor(n / a); }
      return out;
    }
    let decoded = p;
    for (let i = c - 1; i >= 0; i--) {
      const token = radix(i);
      const word = k[i];
      if (word !== undefined && word !== '') {
        const re = new RegExp('\\b' + token + '\\b', 'g');
        decoded = decoded.replace(re, word);
      }
    }
    return decoded;
  }

  // lulustream: embed page → PackedJS → real HLS master.m3u8 URL.
  async function resolveLulustream(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000,
      null,
    );
    if (!res || !res.ok || !res.body) return '';
    const decoded = unpackPacked(res.body);
    const haystack = decoded || res.body;
    const m3u8 = haystack.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)["']/i);
    if (m3u8 && m3u8[1]) return m3u8[1];
    return '';
  }

  // VOE: canvas-token flow — best effort only.
  async function resolveVoe(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000,
      null,
    );
    if (!res || !res.ok || !res.body) return '';
    const m3u8 = res.body.match(/["'](https?:\/\/[^"']*\.m3u8[^"']*)["']/i);
    if (m3u8 && m3u8[1]) return m3u8[1];
    return '';
  }

  // Streamtape: direct mp4 in page.
  async function resolveStreamtape(embedUrl) {
    const res = await settleWithin(
      request(embedUrl, { headers: { Accept: 'text/html,*/*', Referer: MEGAMAX + '/' } }),
      15000,
      null,
    );
    if (!res || !res.ok || !res.body) return '';
    const mp4 = res.body.match(/https?:\/\/[^"'\s]*\.mp4[^"'\s]*/i);
    if (mp4 && mp4[0]) return mp4[0];
    return '';
  }

  // Given a mirror list from megamax, resolve each mirror to a playable URL.
  async function resolveMirrors(mirrors) {
    const streams = [];
    const seen = new Set();
    // Priority: lulustream (direct HLS), voe, streamtape; skip doodstream (CF wall).
    const ordered = [...mirrors].sort((a, b) => {
      const score = (m) => {
        const d = String(m.driver || '').toLowerCase();
        if (d === 'lulustream') return 0;
        if (d === 'voe') return 1;
        if (d === 'streamtape') return 2;
        return 9;
      };
      return score(a) - score(b);
    });
    for (const mir of ordered) {
      const driver = String(mir.driver || '').toLowerCase();
      let link = String(mir.link || '');
      if (!link) continue;
      // Mirror links are often protocol-relative (//host/...).
      if (link.startsWith('//')) link = 'https:' + link;
      if (!/^https?:/i.test(link)) continue;
      let url = '';
      if (driver === 'lulustream') {
        url = await resolveLulustream(link);
      } else if (driver === 'voe') {
        url = await resolveVoe(link);
      } else if (driver === 'streamtape') {
        url = await resolveStreamtape(link);
      } else {
        continue; // doodstream + others: skip (CF wall / JS SPA)
      }
      if (!url || seen.has(url)) continue;
      seen.add(url);
      const isHls = /\.m3u8/i.test(url);
      streams.push({
        label: 'Shahiid • ' + driver + (mir.resolution ? ' • ' + mir.resolution : ''),
        url: url,
        streamType: isHls ? 'hls' : 'mp4',
        kind: isHls ? 'hls' : 'mp4',
        provider: 'shahiid-' + driver,
        headers: {
          'User-Agent': USER_AGENT,
          Referer: link,
          Origin: (link.match(/^(https?:\/\/[^/]+)/i) || [])[1] || '',
        },
      });
      if (streams.length >= 4) break;
    }
    return streams;
  }

  // ── Catalog ───────────────────────────────────────────────────────────────

  // Parse anime cards from a shahiid page HTML (homepage or /anime/ catalog).
  function parseAnimeCards(html) {
    const items = [];
    const seen = new Set();
    // <a href=".../anime/{slug}/">...<img ... src="...">
    const re = /<a\b[^>]*href="(https?:\/\/shahiid-anime\.net\/anime\/[^"]+)"[^>]*>[\s\S]*?<img\b[^>]*src="([^"]+)"[^>]*>/g;
    let m;
    while ((m = re.exec(html))) {
      const href = m[1];
      if (seen.has(href)) continue;
      seen.add(href);
      const slug = href.replace(/^https?:\/\/shahiid-anime\.net\/anime\//, '').replace(/\/$/, '');
      items.push({
        href: slug,
        title: slugToTitle(slug),
        image: m[2],
      });
    }
    return items;
  }

  function slugToTitle(slug) {
    const decoded = decodeURIComponent(slug).replace(/-/g, ' ').replace(/ مترجم| بلوراي| مدبلج/g, '').trim();
    return decoded || slug;
  }

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    try {
      const searchUrl = SITE + '/?s=' + encodeURIComponent(q);
      const html = await fetchShahiidPage(searchUrl, '');
      if (!html) return [];
      // Search results may be the same card layout on the homepage.
      return parseAnimeCards(html).slice((pageNumber - 1) * 30, pageNumber * 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    const id = String(urlOrId || '').trim();
    if (!id) return { title: 'Unknown', description: '' };
    const slug = id.replace(/^https?:\/\/shahiid-anime\.net\/anime\//, '').replace(/\/$/, '');
    const html = await fetchShahiidPage(SITE + '/anime/' + slug + '/', '');
    if (!html) return { title: slugToTitle(slug), description: '', image: '', href: slug };
    const ogTitle = (html.match(/property="og:title" content="([^"]+)"/) || [])[1] || '';
    const ogDesc = (html.match(/property="og:description" content="([^"]+)"/) || [])[1] || '';
    const ogImage = (html.match(/property="og:image" content="([^"]+)"/) || [])[1] || '';
    return {
      title: cleanText(ogTitle || slugToTitle(slug)),
      description: cleanText(ogDesc || ''),
      image: cleanText(ogImage || ''),
      href: slug,
    };
  }

  async function extractEpisodes(seriesId) {
    const id = String(seriesId || '').trim();
    if (!id) return [];
    const slug = id.replace(/^https?:\/\/shahiid-anime\.net\/anime\//, '').replace(/\/$/, '');
    const html = await fetchShahiidPage(SITE + '/anime/' + slug + '/', '');
    if (!html) return [];

    // Extract server iframes (megamax codes) — the site lists multiple
    // servers per post. For a movie there is one; for series there may be
    // multiple episode entries. Collect each megamax iframe found.
    const codes = [];
    const seen = new Set();
    const frameRe = /data-frameserver="([^"]+)"/g;
    let fm;
    while ((fm = frameRe.exec(html))) {
      const codeMatch = fm[1].match(/megamax\.me\/iframe\/([A-Za-z0-9]+)/);
      if (codeMatch && !seen.has(codeMatch[1])) {
        seen.add(codeMatch[1]);
        codes.push(codeMatch[1]);
      }
    }
    if (!codes.length) {
      // Fallback: any megamax iframe in the page.
      const altRe = /megamax\.me\/iframe\/([A-Za-z0-9]+)/g;
      let am;
      while ((am = altRe.exec(html))) {
        if (!seen.has(am[1])) { seen.add(am[1]); codes.push(am[1]); }
      }
    }
    if (!codes.length) return [];

    const eps = [];
    for (let i = 0; i < codes.length && i < MAX_EPISODES; i++) {
      eps.push({
        number: i + 1,
        href: 'megamax:' + codes[i],
        title: 'Episode ' + (i + 1),
        subAvailable: true,
        dubAvailable: false,
      });
    }
    return eps;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const raw = String(episodeHref || '').trim();
    if (!raw) return { streams: [] };
    let hashId = '';
    if (raw.startsWith('megamax:')) {
      hashId = raw.substring('megamax:'.length);
    } else {
      const m = raw.match(/megamax\.me\/iframe\/([A-Za-z0-9]+)/);
      if (m) hashId = m[1];
    }
    log('extractStreamUrl hash=' + hashId);
    if (!hashId) return { streams: [] };

    const mirrors = await megamaxStreams(hashId);
    log('mirrors count=' + mirrors.length + ' list=' + JSON.stringify(mirrors.map(m => m.driver + ':' + String(m.link || '').substring(0, 50))));
    if (!mirrors.length) return { streams: [] };
    const streams = await resolveMirrors(mirrors);
    log('resolved streams=' + streams.length);
    if (!streams.length) return { streams: [] };
    return {
      streams: streams,
      subtitles: [],
      headers: streams[0].headers,
      streamType: streams[0].streamType,
      quality: 'auto',
      lang: String(lang || 'sub').toLowerCase() === 'dub' ? 'dub' : 'sub',
    };
  }

  // ── Discovery ─────────────────────────────────────────────────────────────

  async function discoveryHome() {
    try {
      const html = await fetchShahiidPage(SITE + '/', '');
      if (!html) return { sections: [] };
      const cards = parseAnimeCards(html);
      const sections = [];
      if (cards.length) {
        sections.push({
          id: 'latest',
          title: 'أحدث الأنمي',
          style: 'poster',
          items: cards.slice(0, 30).map((c, i) => ({ ...c, rank: i + 1 })),
        });
      }
      return { sections };
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const pageNumber = Math.max(1, Number(page) || 1);
    try {
      const html = await fetchShahiidPage(SITE + '/anime/page/' + pageNumber + '/', '');
      if (!html) return { items: [], page: pageNumber, hasMore: false };
      const cards = parseAnimeCards(html);
      return { items: cards, page: pageNumber, hasMore: cards.length >= 24 };
    } catch (e) {
      log('feed error: ' + (e && e.message ? e.message : String(e)));
      return { items: [], page: pageNumber, hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { searchResults, extractDetails, extractEpisodes, extractStreamUrl, discoveryHome, discoveryFeed };
  }
})();
