(() => {
  'use strict';

  const MODULE_NAME = 'AnimeSama';
  const SITE = 'https://anime-sama.to';
  const IMG_CDN = 'https://cdn.jsdelivr.net/gh/Anime-Sama/IMG@img/contenu/thumb/';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const FALLBACK_ART = 'https://cdn.jsdelivr.net/gh/Anime-Sama/IMG@img/autres/logo_icon.png';

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    if (raw.startsWith('//')) return 'https:' + raw;
    const root = base || SITE;
    if (raw.startsWith('/')) return root + raw;
    return root + '/' + raw;
  }

  async function requestText(url, extraHeaders, timeoutMs) {
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers });
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw new Error('Request failed ' + (status || '') + ' for ' + url);
      }
      let text = '';
      if (res && typeof res.text === 'function') text = await res.text();
      if (!text && res && typeof res.body === 'string') text = res.body;
      return { status, text };
    };
    if (timeoutMs) {
      return settleWithin(doFetch(), timeoutMs, { status: 0, text: '' });
    }
    return doFetch();
  }

  function looksBlockedPage(html) {
    return /domain has been seized|attention required|just a moment|parked domain|domain is for sale|acc[èe]s introuvable/i.test(
      String(html || ''),
    );
  }

  /* ------------------------------ catalogue ------------------------------ */

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const cardRe =
      /<a href="(https:\/\/anime-sama\.to\/catalogue\/[^"]+|\/catalogue\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = cardRe.exec(String(html || '')))) {
      // Home slides link season pages (/catalogue/<slug>/saison1/vostfr/);
      // cards must point at the series page so details/episodes resolve.
      const href = toAbsoluteUrl(match[1]).replace(
        /(\/catalogue\/[^/?#]+)\/(?:saison\d+|film|films|ova|specials?|scan)\/.*$/i,
        '$1/',
      );
      const block = match[2] || '';
      // Prefer the real poster over language flag icons inside the link.
      const imgMatch =
        block.match(/src="([^"]*contenu[^"]*)"/i) || block.match(/src="([^"]+)"/i);
      let image = (imgMatch && imgMatch[1] && String(imgMatch[1]).trim()) || '';
      if (/flag_[a-z]+\.png/i.test(image)) image = '';
      let title = cleanText((block.match(/alt="([^"]*)"/i) || [])[1] || '');
      if (!href || seen[href]) continue;
      // Home slides put language labels (VOSTFR, VF, ...) in the first img
      // alt; fall back to the slug when the alt is a label, not a title.
      if (!title || /^(vostfr|vf|va|var|vkr|vcn|vqc|vf1|vf2)$/i.test(title)) {
        title = slugFromAnimeUrl(href)
          .replace(/-/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase());
      }
      if (!title) continue;
      seen[href] = true;
      out.push({ title, href, image: image || FALLBACK_ART });
    }
    return out;
  }

  function slugFromAnimeUrl(url) {
    const match = String(url || '').match(/\/catalogue\/([^/?#]+)\/?/i);
    return match ? match[1] : '';
  }

  function parseSeasonPanels(html) {
    const panels = [];
    const seen = Object.create(null);
    const re = /panneauAnime\(\s*"([^"]+)"\s*,\s*"([^"]+)"\s*\)/gi;
    let match;
    while ((match = re.exec(String(html || '')))) {
      const label = cleanText(match[1]);
      const path = String(match[2] || '').replace(/^\/+|\/+$/g, '');
      if (!path || seen[path]) continue;
      seen[path] = true;
      panels.push({ label, path });
    }
    return panels;
  }

  function parseEpsArrays(jsText) {
    const out = {};
    const re = /var\s+(eps[0-9])\s*=\s*\[([\s\S]*?)\];/gi;
    let match;
    while ((match = re.exec(String(jsText || '')))) {
      const name = match[1].toLowerCase();
      const urls = [];
      const urlRe = /'(https?:\/\/[^']+)'/g;
      let urlMatch;
      while ((urlMatch = urlRe.exec(match[2]))) {
        urls.push(urlMatch[1]);
      }
      if (urls.length) out[name] = urls;
    }
    return out;
  }

  function episodeCountFromPanels(arrays) {
    let max = 0;
    for (const key of Object.keys(arrays)) {
      max = Math.max(max, arrays[key].length);
    }
    return max;
  }

  function parseEpisodeRef(input) {
    const raw = String(input || '').trim();
    const match = raw.match(/^as:([^:]+):saison(\d+):([^:]+):(\d+)$/i);
    if (!match) return null;
    return {
      slug: match[1],
      season: Number(match[2]),
      lang: match[3],
      episode: Number(match[4]),
    };
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    const url = term ? SITE + '/catalogue/?search=' + encodeURIComponent(term) : SITE + '/';
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('catalogue page blocked');
      return [];
    }
    return parseCards(res.text).map((card) => ({
      title: card.title,
      href: card.href,
      image: card.image,
    }));
  }

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId);
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('Anime-Sama page is blocked.');
    const html = res.text;
    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText((titleMatch && titleMatch[1]) || slugFromAnimeUrl(url).replace(/-/g, ' '));
    const synopsisMatch =
      html.match(/id="synopsisText"[^>]*>([\s\S]*?)<\/(?:p|div)>/i) ||
      html.match(/class="synopsis-text"[^>]*>([\s\S]*?)<\/(?:p|div)>/i);
    let description = cleanText((synopsisMatch && synopsisMatch[1]) || '');
    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }
    const imgMatch = html.match(
      /https:\/\/cdn\.jsdelivr\.net\/gh\/Anime-Sama\/IMG@img\/contenu\/thumb\/[^"' )]+/i,
    );
    return {
      title,
      description: description || 'Anime on Anime-Sama.',
      image: (imgMatch && imgMatch[0]) || FALLBACK_ART,
    };
  }

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId);
    const slug = slugFromAnimeUrl(url);
    if (!slug) return [];

    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) return [];
    const panels = parseSeasonPanels(res.text);
    const episodes = [];

    for (const panel of panels) {
      const parts = panel.path.split('/').filter(Boolean);
      const seasonMatch = parts[0].match(/saison(\d+)/i);
      if (!seasonMatch) continue;
      const season = Number(seasonMatch[1]);
      const lang = parts[1] || 'vostfr';
      const episodesJsUrl =
        url.replace(/\/+$/, '') + '/' + panel.path + '/episodes.js';
      let arrays = {};
      try {
        const epsRes = await requestText(episodesJsUrl, { Referer: url }, 15000);
        arrays = parseEpsArrays(epsRes.text);
      } catch (error) {
        log('episodes.js failed for ' + panel.path + ': ' + (error && error.message ? error.message : error));
        continue;
      }
      const count = episodeCountFromPanels(arrays);
      for (let ep = 1; ep <= count; ep += 1) {
        episodes.push({
          number: ep,
          season,
          href: 'as:' + slug + ':saison' + season + ':' + lang + ':' + ep,
          title: (panel.label ? panel.label + ' · ' : '') + 'Episode ' + ep,
          subAvailable: lang !== 'vf',
          dubAvailable: lang === 'vf',
        });
      }
    }

    episodes.sort((a, b) => a.season - b.season || a.number - b.number);
    return episodes;
  }

  /* ------------------------------ streams ------------------------------ */

  const SIBNET_HOST = 'https://video.sibnet.ru';

  function pickLecteur(arrays, episode) {
    // Lecteur preference: sibnet (direct mp4, proven) first, then vidmoly,
    // then sendvid. A lecteur simply may not carry this episode.
    const order = [];
    for (const key of Object.keys(arrays)) {
      const urls = arrays[key];
      const url = urls[episode - 1];
      if (!url) continue;
      const host = String(url).match(/^https?:\/\/([^/]+)/i);
      order.push({ key, url, host: host ? host[1].toLowerCase() : '' });
    }
    order.sort((a, b) => {
      const rank = (entry) =>
        entry.host.includes('sibnet.ru') ? 0 : entry.host.includes('vidmoly') ? 1 : 2;
      return rank(a) - rank(b);
    });
    return order;
  }

  function parseSibnetSource(html) {
    const raw = String(html || '');
    const match = raw.match(/player\.src\(\[\{src:\s*"([^"]+\.mp4[^"]*)"/i);
    if (match) return { url: toAbsoluteUrl(match[1], SIBNET_HOST), type: 'video/mp4' };
    const alt = raw.match(/"file"\s*:\s*"([^"]+\.mp4[^"]*)"/i);
    if (alt) return { url: toAbsoluteUrl(alt[1], SIBNET_HOST), type: 'video/mp4' };
    return null;
  }

  async function resolveFinalUrl(url, headers) {
    // Resolve Sibnet's signed mirror without following the redirect or reading
    // the MP4 body. Following the request here can consume the runtime timeout
    // before playback receives the final URL.
    try {
      let res = null;
      if (typeof fetchv2 === 'function') {
        res = await fetchv2(url, headers, 'GET', null, { followRedirects: false });
      } else if (typeof fetch === 'function') {
        res = await fetch(url, { headers, redirect: 'manual' });
      }
      const responseHeaders = (res && res.headers) || {};
      const location =
        responseHeaders.location ||
        responseHeaders.Location ||
        (typeof responseHeaders.get === 'function' ? responseHeaders.get('location') : '');
      const redirected = toAbsoluteUrl(location, SIBNET_HOST);
      if (/^https?:\/\//i.test(redirected)) return redirected;
      const finalUrl = String((res && (res.finalUrl || res.url)) || '');
      return /^https?:\/\//i.test(finalUrl) ? finalUrl : url;
    } catch (_) {
      return url;
    }
  }

  async function resolveSibnet(embedUrl) {
    const res = await requestText(
      embedUrl,
      { Referer: SITE + '/' },
      15000,
    );
    const source = parseSibnetSource(res.text);
    if (!source) throw new Error('sibnet source not found');
    const headers = {
      'User-Agent': USER_AGENT,
      Referer: embedUrl,
      Accept: 'video/mp4,video/*,*/*',
    };
    const finalUrl = await resolveFinalUrl(source.url, headers);
    return {
      url: finalUrl,
      headers,
    };
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseEpisodeRef(episodeHref);
    if (!ref) return { streams: [] };
    const animeUrl = SITE + '/catalogue/' + ref.slug + '/';
    const seasonPath = 'saison' + ref.season + '/' + ref.lang;
    const episodesJsUrl = animeUrl + seasonPath + '/episodes.js';

    const epsRes = await requestText(episodesJsUrl, { Referer: animeUrl }, 15000);
    const arrays = parseEpsArrays(epsRes.text);
    const lecteurs = pickLecteur(arrays, ref.episode);
    if (!lecteurs.length) {
      log('no lecteur for ' + episodeHref);
      return { streams: [] };
    }

    const errors = [];
    for (const lecteur of lecteurs) {
      if (lecteur.host.includes('sibnet.ru')) {
        try {
          const resolved = await resolveSibnet(lecteur.url);
          return {
            streams: [{ label: 'Sibnet ' + (ref.lang === 'vf' ? 'VF' : 'VOSTFR'), url: resolved.url, headers: resolved.headers }],
            headers: resolved.headers,
            quality: 'auto',
            lang: ref.lang === 'vf' ? 'dub' : 'sub',
            streamType: 'mp4',
          };
        } catch (error) {
          errors.push('sibnet: ' + (error && error.message ? error.message : error));
        }
      }
      // vidmoly (ad-gate chain) and sendvid (unreachable) are documented but
      // not resolved in this revision; they remain manual browser fallbacks.
    }

    log('all lecteurs failed: ' + errors.join(' | '));
    return { streams: [] };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
})();
