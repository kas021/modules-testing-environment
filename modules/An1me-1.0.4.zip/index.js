(() => {
  'use strict';

  const MODULE_NAME = 'An1me';
  const BASE_URL = 'https://an1me.to';
  const API_BASE = BASE_URL + '/wp-json/kiranime/v1';
  const KR_VIDEO = BASE_URL + '/kr-video/';
  const MAX_EPISODES = 1300;

  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';
  const STREAM_HEADERS = {
    'User-Agent': USER_AGENT,
    Accept: '*/*',
    'Accept-Language': 'en-US,en;q=0.9',
    'sec-ch-ua': '"Chromium";v="138"',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    Origin: BASE_URL,
    Referer: BASE_URL + '/',
  };

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, Math.max(1, Number(ms) || 0))); }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function decodeHtml(str) {
    return String(str || '')
      .replace(/\\u([0-9a-f]{4})/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
      .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&#39;/g, "'")
      .replace(/\\\//g, '/').replace(/\\"/g, '"').replace(/\\n/g, '\n').replace(/\\t/g, '\t')
      .trim();
  }

  function safeJsonParse(text) {
    if (text !== null && typeof text === 'object') return text;
    try { return JSON.parse(String(text == null ? '' : text).trim()); } catch (_) { return null; }
  }

  function cleanText(value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try { return JSON.stringify(res.json); } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        const value = await res.json();
        return JSON.stringify(value);
      } catch (_) {}
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = { 'User-Agent': USER_AGENT, Accept: 'text/html,application/json,*/*', 'Accept-Language': 'en-US,en;q=0.9' };
    if (cfg.headers) Object.assign(headers, cfg.headers);
    const body = cfg.body == null ? null : cfg.body;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        return { ok: !!(res && (res.ok === true || (status >= 200 && status < 300))), status, body: textBody, json: safeJsonParse(textBody) };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, { method, headers, body });
        const textBody = await res.text();
        return { ok: !!res.ok, status: Number(res.status || 0), body: textBody, json: safeJsonParse(textBody) };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null };
  }

  async function apiGet(path) {
    const res = await request(BASE_URL + path, { headers: { Accept: 'application/json' } });
    if (!res.ok || !res.body) return null;
    try { return JSON.parse(res.body); } catch (_) { return null; }
  }

  // ── Search ─────────────────────────────────────────────────────────────────

  function parseSearchHtml(html) {
    const items = [];
    const seen = new Set();
    const re = /<a\b[^>]*href="(https:\/\/an1me\.to\/anime\/[^"]*)"[^>]*>[\s\S]*?<img\b[^>]*src='?([^'">\s]+)'?[^>]*>[\s\S]*?<\/a>/g;
    let m;
    while ((m = re.exec(html))) {
      const href = m[1];
      const img = cleanText(m[2]);
      if (seen.has(href)) continue;
      seen.add(href);
      items.push({ href, image: img, title: '' });
    }
    if (!items.length) {
      const links = [...new Set([...html.matchAll(/href="(https:\/\/an1me\.to\/anime\/[^"]+)"/g)].map(x => x[1]))];
      for (const href of links) {
        if (seen.has(href)) continue;
        seen.add(href);
        items.push({ href, image: '', title: '' });
      }
    }
    // Extract English titles from <span> elements
    const titleMap = new Map();
    const titleRe = /<a\b[^>]*href="(https:\/\/an1me\.to\/anime\/[^"]*)"[^>]*>[\s\S]*?group-data-\[language=en\]\/body:hidden[^>]*>([^<]*)<\/span>/g;
    let tm;
    while ((tm = titleRe.exec(html))) {
      titleMap.set(tm[1], cleanText(tm[2]));
    }
    // Fallback: look for any English title span
    const fallRe = /href="(https:\/\/an1me\.to\/anime\/[^"]*)"[\s\S]*?(?:"([^"]*)"|[\s\S])*?<span[^>]*style="-webkit-line-clamp:\s*1[^>]*>([^<]*)<\/span>/g;
    // Assign titles
    for (const it of items) {
      it.title = titleMap.get(it.href) || '';
    }
    return items.map(it => ({
      title: it.title || it.href.replace(/^https:\/\/an1me\.to\/anime\//, '').replace(/\/$/, '').replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      href: it.href.replace(/^https:\/\/an1me\.to\/anime\//, '').replace(/\/$/, ''),
      image: it.image,
    }));
  }

  async function searchResults(query, page) {
    const q = String(query == null ? '' : query).trim();
    const pageNumber = Math.max(1, Number(page) + 1 || 1);
    if (!q) return [];
    try {
      const res = await request(API_BASE + '/anime/search?query=' + encodeURIComponent(q));
      if (!res.ok || !res.json) return [];
      const html = decodeHtml(res.json.result || res.body || '');
      const raw = parseSearchHtml(html);
      const slugQ = q.toLowerCase().replace(/[^a-z0-9]+/g, '');
      raw.sort((a, b) => {
        const sa = (a.title || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
        const sb = (b.title || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
        const ea = sa === slugQ ? 1000 : sa.indexOf(slugQ) === 0 ? 600 : sa.indexOf(slugQ) >= 0 ? 300 : 0;
        const eb = sb === slugQ ? 1000 : sb.indexOf(slugQ) === 0 ? 600 : sb.indexOf(slugQ) >= 0 ? 300 : 0;
        return eb - ea;
      });
      const start = (pageNumber - 1) * 30;
      return start <= 0 ? raw : raw.slice(start, start + 30);
    } catch (e) {
      log('search error: ' + (e && e.message ? e.message : String(e)));
      return [];
    }
  }

  // ── Details ────────────────────────────────────────────────────────────────

  async function extractDetails(urlOrId) {
    const slug = String(urlOrId || '')
      .replace(/^https?:\/\/an1me\.to\/(?:anime\/)?/i, '')
      .replace(/^\/?(?:anime\/)?/i, '')
      .replace(/\/$/, '');
    if (!slug) return { title: 'Unknown', description: '' };
    const res = await settleWithin(request(BASE_URL + '/anime/' + slug + '/'), 7000, null);
    const body = (res && res.ok && res.body) || '';
    const ogTitle = (body.match(/property="og:title" content="([^"]+)"/) || [])[1] || '';
    const ogDesc = (body.match(/property="og:description" content="([^"]+)"/) || [])[1] || '';
    const ogImage = (body.match(/property="og:image" content="([^"]+)"/) || [])[1] || '';
    const malImg = (body.match(/https:\/\/cdn\.myanimelist\.net\/images\/anime\/[^"'\s]+/g) || [])[0] || '';
    const h1 = (body.match(/<h1[^>]*>([^<]+)<\/h1>/) || [])[1] || '';
    const notFound = !body || res.status === 404 || res.status === 410 || /<title>\s*Page not found/i.test(body);
    const title = notFound
      ? slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
      : (cleanText(ogTitle || h1 || slug.replace(/-/g, ' ')).replace(/.*Watch\s+/, '').replace(/.*Παρακολουθήστε\s+/, '').replace(/\s*-?\s*(?:online Free on An1me\.to).*/i, '').trim() || slug.replace(/-/g, ' '));
    return {
      title: title || 'An1me',
      description: notFound ? '' : cleanText(ogDesc || ''),
      image: ogImage || malImg || '',
      href: slug,
    };
  }

  // ── Episodes ───────────────────────────────────────────────────────────────

  async function extractEpisodes(seriesId) {
    const slug = String(seriesId || '').replace(/^https?:\/\/an1me\.to\/anime\//, '').replace(/\/$/, '');
    if (!slug) return [];
    const watchUrl = BASE_URL + '/watch/' + slug + '-episode-1/';
    const res = await settleWithin(request(watchUrl), 10000, null);
    const body = (res && res.ok && res.body) || '';
    const pageNotFound = !body || res.status === 404 || res.status === 410 || /<title>\s*Page not found/i.test(body);
    const eps = [];
    const seen = new Set();
    if (!pageNotFound) {
      const re = /href="(https:\/\/an1me\.to\/watch\/[^"]+)"[^>]*data-episode-search-query="(\d+)"/g;
      let m;
      while ((m = re.exec(body))) {
        const num = Number(m[2]);
        if (!num || seen.has(num)) continue;
        seen.add(num);
        eps.push({
          number: num,
          href: m[1],
          title: 'Episode ' + num,
          subAvailable: true,
          dubAvailable: true,
        });
        if (eps.length >= MAX_EPISODES) break;
      }
    }
    if (!eps.length && !pageNotFound) {
      // Fallback: build list from data attributes
      const maxEp = Math.max(1, ...([...body.matchAll(/data-episode-search-query="(\d+)"/g)].map(x => Number(x[1]))));
      for (let n = 1; n <= Math.min(maxEp || 1, MAX_EPISODES); n++) {
        eps.push({
          number: n,
          href: BASE_URL + '/watch/' + slug + '-episode-' + n + '/',
          title: 'Episode ' + n,
          subAvailable: true,
          dubAvailable: true,
        });
      }
    }
    if (!eps.length && pageNotFound) return [];
    if (!eps.length) {
      // Last resort: try 1 episode
      eps.push({
        number: 1,
        href: BASE_URL + '/watch/' + slug + '-episode-1/',
        title: 'Episode 1',
        subAvailable: true,
        dubAvailable: true,
      });
    }
    eps.sort((a, b) => a.number - b.number);
    return eps.slice(0, MAX_EPISODES);
  }

  // ── Stream ─────────────────────────────────────────────────────────────────

  function streamHeadersForUrl(url) {
    return {
      'User-Agent': USER_AGENT,
      Accept: '*/*',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-ch-ua': '"Chromium";v="138"',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'cross-site',
      Origin: BASE_URL,
      Referer: /cdn\.an1me\.io/.test(url) ? BASE_URL + '/kr-video/' : BASE_URL + '/',
    };
  }

  async function resolveStreamUrl(krVideoPageUrl) {
    const res = await settleWithin(
      request(krVideoPageUrl, {
        headers: { Referer: BASE_URL + '/', Accept: 'text/html,application/xhtml+xml,*/*' },
      }),
      10000,
      null,
    );
    if (!res || !res.ok || !res.body) return [];
    const match = res.body.match(/const\s+params\s*=\s*(\{[^;]+)/);
    if (!match) return [];
    try {
      const params = JSON.parse(match[1].replace(/\\\//g, '/').replace(/\\\\/g, '\\'));
      const sources = Array.isArray(params.sources) ? params.sources : [];
      const out = [];
      for (let i = 0; i < sources.length; i++) {
        const s = sources[i];
        const url = String((s && s.url) || '');
        if (!url.startsWith('http')) continue;
        const stype = (s && s.type) && String(s.type).includes('mpegURL') ? 'hls' : 'mp4';
        const quality = String((s && s.html) || 'Auto').replace('HLS Stream', 'Auto').trim();
        out.push({
          label: quality + (sources.length > 1 ? ' ' + (i + 1) : ''),
          url: url,
          streamType: stype,
          height: undefined,
          headers: streamHeadersForUrl(url),
        });
      }
      return out;
    } catch (_) {
      return [];
    }
  }

  function absoluteUrl(value, base) {
    const ref = String(value || '').trim();
    const baseText = String(base || '').trim();
    if (!ref || !baseText) return '';
    if (/^https?:\/\//i.test(ref)) return encodeURI(ref);
    const origin = (baseText.match(/^(https?:\/\/[^/]+)/i) || [])[1] || '';
    if (!origin) return '';
    if (ref.startsWith('/')) return encodeURI(origin + ref);
    const directory = baseText.replace(/[^/]*$/, '');
    return encodeURI(directory + ref.replace(/^\.\//, ''));
  }

  function playlistVariantUrl(body, baseUrl) {
    const lines = String(body || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue;
      for (let j = i + 1; j < lines.length; j++) {
        if (lines[j].startsWith('#')) continue;
        return absoluteUrl(lines[j], baseUrl);
      }
    }
    return '';
  }

  function firstMediaReference(body, baseUrl) {
    const lines = String(body || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (const line of lines) {
      if (!line || line.startsWith('#')) continue;
      if (/\.m3u8(?:[?#]|$)/i.test(line)) continue;
      return absoluteUrl(line, baseUrl);
    }
    return '';
  }

  // Some server entries advertise an HLS URL but actually contain a slideshow
  // of JPG segments. Downloads can save that response, while a video player
  // never receives decodable video. Drop only that false-HLS shape and keep
  // genuine HLS or MP4 fallbacks available.
  //
  // Some hosts (An1me) disguise REAL MPEG-TS video segments behind .jpg/.png
  // filenames. A genuine stream still advertises real video codecs
  // (avc1/hev1/av01) or a real RESOLUTION in the master #EXT-X-STREAM-INF
  // lines, so a master carrying either is treated as a real stream regardless
  // of the segment extension. A slideshow master never lists video codecs or
  // resolutions.
  async function isImageSequenceHls(url) {
    const headers = streamHeadersForUrl(url);
    const master = await settleWithin(request(url, { headers }), 5000, null);
    if (!master || !master.ok || !master.body || !/#EXTM3U/i.test(master.body)) return false;
    const masterIsVideo = /CODECS="[^"]*(?:avc1|av01|hev1|vp09|vp9)[^"]*"/i.test(master.body) ||
      /#EXT-X-STREAM-INF:[^\n]*RESOLUTION=/i.test(master.body);
    if (masterIsVideo) return false;
    let playlistBody = master.body;
    let playlistUrl = url;
    const variantUrl = playlistVariantUrl(master.body, url);
    if (variantUrl) {
      const variant = await settleWithin(request(variantUrl, { headers: streamHeadersForUrl(variantUrl) }), 5000, null);
      if (!variant || !variant.ok || !variant.body || !/#EXTM3U/i.test(variant.body)) return false;
      playlistBody = variant.body;
      playlistUrl = variantUrl;
    }
    const mediaUrl = firstMediaReference(playlistBody, playlistUrl);
    return /\.(?:jpg|jpeg|png|webp)(?:[?#]|$)/i.test(mediaUrl);
  }

  function decodeB64(str) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let s = String(str || '').replace(/[^A-Za-z0-9+/=]/g, '');
    while (s.length % 4) s += '=';
    const result = [];
    for (let i = 0; i < s.length; i += 4) {
      const a = chars.indexOf(s[i] || 'A');
      const b = chars.indexOf(s[i + 1] || 'A');
      const c = chars.indexOf(s[i + 2] || 'A');
      const d = chars.indexOf(s[i + 3] || 'A');
      result.push((a << 2) | (b >> 4));
      if (s[i + 2] !== '=') result.push(((b & 15) << 4) | (c >> 2));
      if (s[i + 3] !== '=') result.push(((c & 3) << 6) | d);
    }
    const out = [];
    for (const byte of result) {
      if (byte < 128) out.push(byte);
      else if (byte < 2048) { out.push(192 | (byte >> 6)); out.push(128 | (byte & 63)); }
      else { out.push(224 | (byte >> 12)); out.push(128 | ((byte >> 6) & 63)); out.push(128 | (byte & 63)); }
    }
    let text = '';
    for (let i = 0; i < out.length; i++) text += String.fromCharCode(out[i] & 0xFF);
    return text;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const res = await settleWithin(
      request(String(episodeHref), { headers: { Accept: 'text/html,application/xhtml+xml,*/*' } }),
      12000,
      null,
    );
    if (!res || !res.ok || !res.body) return { streams: [] };
    const body = res.body;
    const wantDub = String(lang || 'sub').toLowerCase() === 'dub';
    const embedIds = [...body.matchAll(/data-embed-id="([^"]+)"/g)].map(x => x[1]);
    if (!embedIds.length) return { streams: [] };

    // Classify servers: sub vs dub
    const subServers = [];
    const dubServers = [];
    for (const eid of embedIds) {
      const colonIdx = eid.indexOf(':');
      if (colonIdx < 0) continue;
      const nameB64 = eid.slice(0, colonIdx);
      let name = '';
      try { name = decodeB64(nameB64).toLowerCase(); } catch (_) {}
      const iframeB64 = eid.slice(colonIdx + 1);
      const iframe = decodeB64(iframeB64);
      const srcMatch = iframe.match(/src="([^"]+)"/);
      if (!srcMatch) continue;
      const krUrl = srcMatch[1];
      // Check for dub/sub in server name
      const isDub = /dub|μεταγλ/i.test(name);
      if (isDub) {
        dubServers.push({ name, krUrl });
      } else {
        subServers.push({ name, krUrl });
      }
    }

    const preferred = wantDub ? [...dubServers, ...subServers] : [...subServers, ...dubServers];
    const routeResults = await Promise.all(preferred.slice(0, 6).map(async server => {
      try {
        return await resolveStreamUrl(server.krUrl);
      } catch (_) {
        return [];
      }
    }));
    const results = routeResults.flat().map(s => ({
      ...s,
      label: (wantDub ? 'DUB' : 'SUB') + ' • ' + s.label,
    }));
    const hlsChecks = await Promise.all(results.map(async stream => ({
      stream,
      imageSequence: stream.streamType === 'hls' ? await isImageSequenceHls(stream.url) : false,
    })));
    const playableResults = hlsChecks
      .filter(entry => !entry.imageSequence)
      .map(entry => entry.stream);
    // Prefer a real file when the advertised HLS route is an image sequence.
    // The app can play the MP4 even when the host reports application/octet-stream.
    playableResults.sort((a, b) => {
      const aHls = a.streamType === 'hls' ? 1 : 0;
      const bHls = b.streamType === 'hls' ? 1 : 0;
      return aHls - bHls;
    });

    if (!playableResults.length) return { streams: [] };
    return {
      streams: playableResults,
      subtitles: [],
      headers: playableResults[0].headers,
      streamType: playableResults[0].streamType,
      quality: playableResults[0].quality || 'auto',
      lang: wantDub ? 'dub' : 'sub',
    };
  }

  // ── Discovery / Home ──────────────────────────────────────────────────────

  async function scrapeHomepageCards() {
    const res = await settleWithin(request(BASE_URL + '/'), 12000, null);
    if (!res || !res.ok || !res.body) return [];
    const body = res.body;
    const items = [];
    const seen = new Set();

    // Normalise a title so that "Naruto: Shippuuden", "naruto-shippuuden" and
    // "Naruto Shippuuden" all compare equal, while "Bleach" and
    // "Bleach: Sennen Kessen-hen - Kashin-tan" remain distinct.
    const norm = t => String(t == null ? '' : t)
      .replace(/&amp;/g, '&')
      .toLowerCase()
      .replace(/[:;.!?,–—'"«»]/g, '')
      .replace(/[()]/g, ' ')
      .replace(/[^a-z0-9 ]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    // 1) List cards: the <a> wraps its own local poster image and carries the
    //    exact display title in the title="" attribute. Pair them directly.
    const listCardRe =
      /<a\b[^>]*href="(https:\/\/an1me\.to\/anime\/[^"]+)"[^>]*title="([^"]*)"[^>]*>\s*<img\b[^>]*src='([^']+)'/g;
    const localImageByTitle = {};
    let lc;
    while ((lc = listCardRe.exec(body))) {
      const href = lc[1];
      if (href.includes('#') || href.includes('?')) continue;
      const title = cleanText(lc[2]);
      const img = lc[3].replace(/-\d+x\d+(?=\.\w+$)/, '');
      if (!title || !img.startsWith('http')) continue;
      const key = norm(title);
      if (!key) continue;
      if (!localImageByTitle[key]) {
        localImageByTitle[key] = { href, title, image: img };
      }
    }

    // 2) Spotlight/hero cards: the MAL poster <img> (with alt=title) appears
    //    right before the <a> that carries the display title.
    const malByTitle = {};
    const malRe =
      /<img\b[^>]*src='(https:\/\/(?:cdn\.)?myanimelist\.net\/images\/anime\/[^']+)'[^>]*?\salt='([^']*)'/g;
    let im;
    while ((im = malRe.exec(body))) {
      const key = norm(im[2]);
      if (!key) continue;
      if (!malByTitle[key]) malByTitle[key] = im[1];
    }

    // 3) Every /anime/ link with its display title attribute.
    const linkRe =
      /<a\b[^>]*href="(https:\/\/an1me\.to\/anime\/[^"]+)"[^>]*title="([^"]*)"[^>]*>/g;
    const links = [];
    const seenHrefs = new Set();
    let lm;
    while ((lm = linkRe.exec(body))) {
      const href = lm[1];
      if (href.includes('#') || href.includes('?')) continue;
      if (seenHrefs.has(href)) continue;
      seenHrefs.add(href);
      links.push({ href, title: cleanText(lm[2]) });
    }
    // 3b) Spotlight/hero anchors carry no title="" attribute; the English
    //     display name lives in the second <span> (language=en).
    const heroRe =
      /<a\b[^>]*href="(https:\/\/an1me\.to\/anime\/[^"]+)"[^>]*>\s*<h2[\s\S]*?group-data-\[language=en\]\/body:hidden[^>]*>([^<]*)<\/span>/g;
    let hm;
    while ((hm = heroRe.exec(body))) {
      const href = hm[1];
      if (href.includes('#') || href.includes('?')) continue;
      if (seenHrefs.has(href)) continue;
      seenHrefs.add(href);
      links.push({ href, title: cleanText(hm[2]) });
    }

    for (let i = 0; i < links.length && items.length < 40; i++) {
      const { href, title } = links[i];
      const slug = href.replace(/^https:\/\/an1me\.to\/anime\//, '').replace(/\/$/, '');
      if (seen.has(slug)) continue;
      seen.add(slug);
      const key = norm(title);
      const slugKey = norm(slug.replace(/-/g, ' '));
      const paired = localImageByTitle[key];
      const image =
        (paired && paired.image) ||
        malByTitle[key] ||
        malByTitle[slugKey] ||
        '';
      items.push({
        title: title || slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        href: slug,
        image,
      });
    }
    if (!items.length) {
      for (const { href } of links) {
        const slug = href.replace(/^https:\/\/an1me\.to\/anime\//, '').replace(/\/$/, '');
        items.push({ title: slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()), href: slug, image: '' });
        if (items.length >= 40) break;
      }
    }
    return items;
  }

  async function discoveryHome() {
    try {
      const cards = await scrapeHomepageCards();
      const sections = [];
      if (cards.length) {
        const hero = cards.slice(0, 6).map((c, i) => ({ ...c, rank: i + 1 }));
        sections.push({ id: 'featured', title: 'Featured', style: 'hero', items: hero });
        sections.push({
          id: 'browse',
          title: 'Browse',
          style: 'poster',
          items: cards.slice(0, 30),
          viewAll: { mode: 'feed', feedId: 'browse' },
        });
      }
      return { sections };
    } catch (e) {
      log('discovery error: ' + (e && e.message ? e.message : String(e)));
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    const key = String(feedId || 'browse').toLowerCase();
    const pageNumber = Math.max(1, Number(page) || 1);
    const all = await scrapeHomepageCards();
    const start = (pageNumber - 1) * 30;
    return { items: all.slice(start, start + 30), page: pageNumber, hasMore: start + 30 < all.length };
  }

  // Support empty search = browse popular
  const _origSearchResults = searchResults;
  searchResults = async function (query, pg) {
    const q = String(query == null ? '' : query).trim();
    if (!q) {
      const cards = await scrapeHomepageCards();
      const pageNumber = Math.max(1, Number(pg) + 1 || 1);
      const start = (pageNumber - 1) * 30;
      return start <= 0 ? cards : cards.slice(start, start + 30);
    }
    return _origSearchResults(q, pg);
  };

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { searchResults, extractDetails, extractEpisodes, extractStreamUrl, discoveryHome, discoveryFeed };
  }
})();
