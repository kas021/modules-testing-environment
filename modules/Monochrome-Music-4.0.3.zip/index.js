(function () {
  // Official Monochrome UI mirrors (referer only)
  const MONOCHROME_MIRRORS = [
    'https://monochrome.tf',
    'https://monochrome.samidy.com',
    'https://lossless.wtf',
  ];

  // Live HiFi catalog APIs (2026 INSTANCES.md). Old qdl-api.monochrome.tf is dead.
  const HIFI_APIS = [
    'https://api.monochrome.tf',
    'https://monochrome-api.samidy.com',
  ];

  const FALLBACK_ART =
    'https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=800&auto=format&fit=crop';

  function ok(data) {
    return { ok: true, data: JSON.stringify(data) };
  }

  function fail(message) {
    return { ok: false, error: { message: String(message || 'Music module error') } };
  }

  async function fetchJson(url, headers) {
    const res = await fetchv2(
      url,
      Object.assign(
        {
          Accept: 'application/json',
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36',
        },
        headers || {},
      ),
      'GET',
    );
    const status = Number(res.status || res.statusCode || 0);
    let parsed = null;
    if (typeof res.json === 'function') {
      try {
        parsed = await res.json();
      } catch (_) {
        parsed = null;
      }
    }
    let text = String(res.body || '');
    if (!text && typeof res.text === 'function') {
      try {
        text = await res.text();
      } catch (_) {
        text = '';
      }
    }
    if (status < 200 || status >= 300) throw new Error('HTTP ' + status);
    if (parsed !== null && typeof parsed === 'object') return parsed;
    if (/^\s*</.test(text)) throw new Error('HTML instead of JSON');
    if (!text) throw new Error('Empty body');
    return JSON.parse(text);
  }

  function withTimeout(promise, ms, label) {
    return Promise.race([
      promise,
      new Promise(function (_, reject) {
        setTimeout(function () {
          reject(new Error((label || 'request') + ' timed out'));
        }, ms);
      }),
    ]);
  }

  function tidalCover(cover, size) {
    const raw = String(cover || '').trim();
    if (!raw) return FALLBACK_ART;
    if (/^https?:\/\//i.test(raw)) return raw;
    const dim = size || '640x640';
    return (
      'https://resources.tidal.com/images/' +
      raw.replace(/-/g, '/') +
      '/' +
      dim +
      '.jpg'
    );
  }

  function artistName(item) {
    if (!item) return 'Unknown Artist';
    if (item.artist && item.artist.name) return item.artist.name;
    if (Array.isArray(item.artists) && item.artists[0] && item.artists[0].name) {
      return item.artists[0].name;
    }
    return 'Unknown Artist';
  }

  function encodedJsonId(prefix, payload) {
    return prefix + ':' + encodeURIComponent(JSON.stringify(payload || {}));
  }

  function parseEncodedJsonId(raw, prefix) {
    const value = String(raw || '');
    if (!value.startsWith(prefix + ':')) return null;
    try {
      return JSON.parse(decodeURIComponent(value.slice(prefix.length + 1)));
    } catch (_) {
      return null;
    }
  }

  function containerId(kind, query, title, artist, image) {
    return [
      kind + ':' + encodeURIComponent(query || ''),
      encodeURIComponent(title || ''),
      encodeURIComponent(artist || ''),
      encodeURIComponent(image || ''),
    ].join('|');
  }

  function parseContainerId(id) {
    const raw = String(id || '');
    const parts = raw.split('|');
    const head = parts[0] || '';
    const kindAndQuery = head.split(':');
    return {
      kind: kindAndQuery[0] || '',
      query: decodeURIComponent(kindAndQuery.slice(1).join(':') || ''),
      title: decodeURIComponent(parts[1] || ''),
      artist: decodeURIComponent(parts[2] || ''),
      image: decodeURIComponent(parts[3] || ''),
    };
  }

  function mapHifiTrack(track) {
    const title = track.title || 'Unknown Track';
    const artist = artistName(track);
    const album = (track.album && track.album.title) || '';
    const image = tidalCover(track.album && track.album.cover);
    const durationSeconds = Number(track.duration || 0) || undefined;
    return {
      type: 'track',
      id: encodedJsonId('hifi', {
        id: String(track.id || ''),
        title: title,
        artist: artist,
        album: album,
        image: image,
        durationSeconds: durationSeconds,
      }),
      title: title,
      artist: artist,
      album: album,
      image: image,
      durationSeconds: durationSeconds,
    };
  }

  function mapItunesTrack(track) {
    const artwork = String(track.artworkUrl100 || track.artworkUrl60 || '')
      .replace('100x100bb', '600x600bb')
      .replace('60x60bb', '600x600bb');
    const preview = String(track.previewUrl || '');
    const title = track.trackName || 'Unknown Track';
    const artist = track.artistName || 'Unknown Artist';
    const album = track.collectionName || '';
    return {
      type: 'track',
      id: encodedJsonId('itunesjson', {
        id: String(track.trackId || ''),
        previewUrl: preview,
        title: title,
        artist: artist,
        album: album,
        image: artwork || FALLBACK_ART,
        durationSeconds: 30,
      }),
      title: title,
      artist: artist,
      album: album,
      image: artwork || FALLBACK_ART,
      durationSeconds: 30,
      previewUrl: preview,
    };
  }

  function makeAlbumFromTracks(query, title, tracks) {
    const first = tracks[0] || {};
    const albumTitle = title || first.album || query || 'Album';
    const artist = first.artist || 'Various Artists';
    const image = first.image || FALLBACK_ART;
    return {
      type: 'album',
      id: containerId('album', query, albumTitle, artist, image),
      title: albumTitle,
      artist: artist,
      image: image,
      year: '2026',
      genre: 'Music',
      trackCount: tracks.length,
      description: 'Catalog from Monochrome/HiFi APIs. Playback uses progressive previews.',
      tracks: tracks.map(function (track) {
        return Object.assign({}, track, {
          album: albumTitle,
          image: track.image || image,
        });
      }),
    };
  }

  async function hifiSearch(query, offset) {
    const failures = [];
    const path =
      '/search/?s=' +
      encodeURIComponent(query || 'instrumental') +
      '&type=tracks&offset=' +
      encodeURIComponent(offset || 0);
    for (let i = 0; i < HIFI_APIS.length; i++) {
      const base = HIFI_APIS[i];
      const mirror = MONOCHROME_MIRRORS[i % MONOCHROME_MIRRORS.length];
      try {
        const data = await fetchJson(base + path, {
          Referer: mirror + '/',
          Origin: mirror,
        });
        const items =
          (data && data.data && Array.isArray(data.data.items) && data.data.items) ||
          (data && Array.isArray(data.items) && data.items) ||
          [];
        return items.map(mapHifiTrack).filter(function (t) {
          return t.title;
        });
      } catch (e) {
        failures.push(base + ': ' + (e && e.message ? e.message : e));
      }
    }
    throw new Error(failures.join(' | ') || 'HiFi search failed');
  }

  async function itunesSearch(query) {
    const url =
      'https://itunes.apple.com/search?media=music&entity=song&limit=20&term=' +
      encodeURIComponent(query || 'instrumental');
    const data = await fetchJson(url);
    const results = data && Array.isArray(data.results) ? data.results : [];
    return results.map(mapItunesTrack).filter(function (t) {
      return t.previewUrl && t.title;
    });
  }

  async function deezerPreview(title, artist) {
    const q = (String(title || '') + ' ' + String(artist || '')).trim();
    if (!q) return '';
    const url =
      'https://api.deezer.com/search?limit=5&q=' + encodeURIComponent(q);
    const data = await fetchJson(url);
    const rows = data && Array.isArray(data.data) ? data.data : [];
    for (let i = 0; i < rows.length; i++) {
      const preview = String((rows[i] && rows[i].preview) || '');
      if (/^https?:\/\//i.test(preview)) return preview;
    }
    return '';
  }

  async function itunesPreview(title, artist) {
    const q = (String(title || '') + ' ' + String(artist || '')).trim();
    if (!q) return '';
    const tracks = await itunesSearch(q);
    if (tracks[0] && tracks[0].previewUrl) return tracks[0].previewUrl;
    return '';
  }

  async function musicSearch(query, offset) {
    try {
      const full = await withTimeout(hifiSearch(query, offset), 6000, 'HiFi search');
      if (full.length) return full;
    } catch (_) {}
    try {
      return await withTimeout(itunesSearch(query), 4500, 'iTunes search');
    } catch (_) {
      return [];
    }
  }

  async function searchResults(query, page) {
    try {
      const q = String(query || '').trim() || 'instrumental';
      const offset = Math.max(0, Number(page || 0)) * 25;
      const tracks = await musicSearch(q, offset);
      if (offset > 0 || tracks.length === 0) return ok(tracks);
      return ok([makeAlbumFromTracks(q, q, tracks.slice(0, 12)), ...tracks]);
    } catch (e) {
      return fail('Monochrome music search failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function homeSections(page) {
    const pages = [
      {
        albums: [
          ['Featured Albums', 'instrumental'],
          ['Soundtrack Albums', 'cinematic soundtrack'],
        ],
        tracks: [
          ['Recently Added', 'new music'],
          ['Soundtrack Picks', 'soundtrack themes'],
        ],
        playlists: [
          [
            'playlist:soundtracks',
            'Soundtrack Picks',
            'Instrumental and soundtrack selections',
            'soundtrack themes',
          ],
          [
            'playlist:relaxed',
            'Relaxed Listening',
            'Soft background music',
            'ambient chill',
          ],
        ],
      },
      {
        albums: [
          ['More Albums', 'after hours'],
          ['More Albums', 'random access memories'],
        ],
        tracks: [
          ['Global Rotation', 'pop hits'],
          ['Electronic Focus', 'electronic focus'],
        ],
        playlists: [
          [
            'playlist:focus',
            'Focus Mix',
            'Electronic and low-distraction tracks',
            'electronic focus',
          ],
        ],
      },
    ];
    const batch = pages[Math.max(0, Number(page || 0))];
    if (!batch) return ok([]);
    const sections = [];

    async function safeTracks(query, limit) {
      try {
        const tracks = await withTimeout(musicSearch(query, 0), 5000, 'Home search');
        return tracks.slice(0, limit || 8);
      } catch (_) {}
      return [];
    }

    const albumResults = await Promise.all(
      batch.albums.slice(0, 2).map(async function (seed) {
        const tracks = await safeTracks(seed[1], 10);
        if (!tracks.length) return null;
        return { section: seed[0], album: makeAlbumFromTracks(seed[1], seed[1], tracks) };
      }),
    );
    const albumSections = {};
    albumResults.filter(Boolean).forEach(function (entry) {
      if (!albumSections[entry.section]) albumSections[entry.section] = [];
      albumSections[entry.section].push(entry.album);
    });
    Object.keys(albumSections).forEach(function (title) {
      if (albumSections[title].length) {
        sections.push({ title: title, type: 'album', items: albumSections[title] });
      }
    });

    const trackSections = await Promise.all(
      batch.tracks.slice(0, 2).map(async function (seed) {
        const tracks = await safeTracks(seed[1], 8);
        return { title: seed[0], tracks: tracks };
      }),
    );
    trackSections.forEach(function (seed) {
      if (seed.tracks.length) {
        sections.push({ title: seed.title, type: 'track', items: seed.tracks.slice(0, 10) });
      }
    });

    sections.push({
      title: 'Playlists For You',
      type: 'playlist',
      items: batch.playlists.map(function (item) {
        return {
          id: containerId('playlist', item[3], item[1], 'Various Artists', ''),
          title: item[1],
          subtitle: item[2],
        };
      }),
    });
    return ok(sections);
  }

  async function extractDetails(id) {
    try {
      const parsed = parseContainerId(id);
      const query = parsed.query || parsed.title || 'instrumental';
      const tracks = await musicSearch(query, 0);
      return ok(makeAlbumFromTracks(query, parsed.title || query, tracks.slice(0, 20)));
    } catch (e) {
      return fail('Monochrome album details failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function extractTracks(containerIdValue) {
    try {
      const parsed = parseContainerId(containerIdValue);
      const query = parsed.query || parsed.title || 'instrumental';
      const tracks = await musicSearch(query, 0);
      return ok(
        tracks.slice(0, 30).map(function (track) {
          return Object.assign({}, track, {
            album: parsed.title || track.album || query,
            image: track.image || parsed.image || FALLBACK_ART,
          });
        }),
      );
    } catch (e) {
      return fail('Monochrome track list failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function resolvePreviewUrl(meta) {
    if (meta.previewUrl && /^https?:\/\//i.test(meta.previewUrl)) {
      return { url: meta.previewUrl, quality: 'preview', mimeType: 'audio/mp4', extension: 'm4a' };
    }
    // Progressive previews only — Tidal HiFi full tracks need subscription (403/DASH).
    try {
      const itunes = await withTimeout(
        itunesPreview(meta.title, meta.artist),
        4000,
        'iTunes preview',
      );
      if (itunes) {
        return { url: itunes, quality: 'preview', mimeType: 'audio/mp4', extension: 'm4a' };
      }
    } catch (_) {}
    try {
      const deezer = await withTimeout(
        deezerPreview(meta.title, meta.artist),
        4000,
        'Deezer preview',
      );
      if (deezer) {
        return { url: deezer, quality: 'preview', mimeType: 'audio/mpeg', extension: 'mp3' };
      }
    } catch (_) {}
    return null;
  }

  async function extractAudioUrl(trackId, quality) {
    try {
      let meta = null;
      const hifi = parseEncodedJsonId(trackId, 'hifi');
      if (hifi) {
        meta = {
          id: 'hifi:' + String(hifi.id || ''),
          title: hifi.title || 'Track',
          artist: hifi.artist || 'Unknown Artist',
          album: hifi.album || '',
          image: hifi.image || FALLBACK_ART,
          durationSeconds: hifi.durationSeconds,
        };
      }
      const itunes = parseEncodedJsonId(trackId, 'itunesjson');
      if (itunes) {
        meta = {
          id: 'itunes:' + String(itunes.id || ''),
          previewUrl: itunes.previewUrl || '',
          title: itunes.title || 'Preview Track',
          artist: itunes.artist || 'Unknown Artist',
          album: itunes.album || '',
          image: itunes.image || FALLBACK_ART,
          durationSeconds: 30,
        };
      }
      if (!meta) {
        meta = { id: String(trackId || ''), title: String(trackId || ''), artist: '' };
      }

      const resolved = await resolvePreviewUrl(meta);
      if (!resolved || !resolved.url) {
        throw new Error(
          'No progressive preview available. Full lossless needs a subscribed Monochrome/Tidal backend.',
        );
      }
      return ok({
        url: resolved.url,
        headers: {},
        mimeType: resolved.mimeType,
        extension: resolved.extension,
        title: meta.title || 'Preview Track',
        artist: meta.artist || 'Unknown Artist',
        album: meta.album || '',
        artwork: meta.image || FALLBACK_ART,
        durationSeconds: meta.durationSeconds || 30,
        quality: resolved.quality || 'preview',
      });
    } catch (e) {
      return fail('Monochrome audio resolution failed: ' + (e && e.message ? e.message : e));
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.homeSections = homeSections;
  globalThis.extractDetails = extractDetails;
  globalThis.extractTracks = extractTracks;
  globalThis.extractAudioUrl = extractAudioUrl;
})();
