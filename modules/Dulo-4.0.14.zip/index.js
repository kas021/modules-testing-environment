(() => {
  'use strict';

  const MODULE_NAME = 'DuloV1';
  const BASE_URL = 'https://dulo.tv';
  const API_URL = BASE_URL + '/api';
  // Embedded in dulo.tv player bundle (required by API)
  const API_KEY = 'WDNUNBUB3HR983Y9ISBADK4O82';
  const TMDB_API = 'https://api.themoviedb.org/3';
  const TMDB_KEY = '0fd8ade0f772180c8f8d651787c35e14';
  const IMG_BASE = 'https://image.tmdb.org/t/p/w342';
  const IMG_BACKDROP = 'https://image.tmdb.org/t/p/w780';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  /** Discovery feed ids → TMDB list endpoints (page query supported). */
  const DISCOVERY_FEEDS = {
    trending_movie: { path: '/trending/movie/week', mediaType: 'movie', title: 'Trending Movies' },
    trending_tv: { path: '/trending/tv/week', mediaType: 'tv', title: 'Trending TV' },
    popular_movie: { path: '/movie/popular', mediaType: 'movie', title: 'Popular Movies' },
    popular_tv: { path: '/tv/popular', mediaType: 'tv', title: 'Popular TV' },
    now_playing: { path: '/movie/now_playing', mediaType: 'movie', title: 'In Theaters' },
    on_the_air: { path: '/tv/on_the_air', mediaType: 'tv', title: 'On The Air' },
    top_rated_movie: { path: '/movie/top_rated', mediaType: 'movie', title: 'Top Rated Movies' },
    top_rated_tv: { path: '/tv/top_rated', mediaType: 'tv', title: 'Top Rated TV' },
    upcoming: { path: '/movie/upcoming', mediaType: 'movie', title: 'Upcoming Movies' },
  };

  // Order matters — try diverse hosts early (vidrock HLS often more reliable than jay MP4)
  const MOVIE_PROVIDERS = [
    'vidrock',
    'vidlink',
    'streamflix',
    'vixsrc',
    'videasy',
    'vidnest',
    'vidzee',
    'xpass',
    'uniquestream',
    'yflix',
  ];
  const TV_PROVIDERS = [
    'vidrock',
    'vidlink',
    'streamflix',
    'vixsrc',
    'videasy',
    'vidnest',
    'vidzee',
  ];
  // Keep a failed upstream resolver from holding the player on a loading state
  // for 30–40 seconds. A later playback attempt gets a fresh Dulo session.
  // The current session-backed `/source` endpoint can take 7-9 seconds before
  // it emits its first source event. The old 9s whole-operation deadline
  // routinely expired just before we could validate and return that route,
  // leaving otherwise valid TV and movie requests with an empty stream list.
  // This remains bounded: discovery never uses this path, and playback gets a
  // single 16s resolution window before the normal retry path takes over.
  const RESOLVER_DEADLINE_MS = 16000;
  const PROVIDER_WAVE_TIMEOUT_MS = 3500;
  const VERIFY_TIMEOUT_MS = 3500;
  // Recovery verification gets more headroom: jay's encrypted-HLS chain
  // (large media playlist + a ~3.6MB first segment) needs ~4s on a good day,
  // so the fast-wave cap routinely dropped the only working route for a title.
  // Still bounded by the overall 16s resolver deadline.
  const VERIFY_RECOVERY_TIMEOUT_MS = 6500;

  const defaultHeaders = {
    'User-Agent': USER_AGENT,
    Accept: 'application/json,text/plain,*/*',
    Origin: BASE_URL,
    Referer: BASE_URL + '/',
    'X-API-Key': API_KEY,
    Authorization: 'Bearer ' + API_KEY,
  };

  let sessionReady = false;
  const cookieJar = {};

  function encodeQuery(params) {
    const parts = [];
    const entries = params && typeof params === 'object' ? Object.entries(params) : [];
    for (const [key, value] of entries) {
      if (value == null || value === '') continue;
      parts.push(encodeURIComponent(String(key)) + '=' + encodeURIComponent(String(value)));
    }
    return parts.join('&');
  }

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  async function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([
      promise,
      sleep(waitMs).then(() => fallback),
    ]);
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function storeCookies(res) {
    if (!res || !res.headers || typeof res.headers !== 'object') return;
    const raw =
      res.headers['set-cookie'] ||
      res.headers['Set-Cookie'] ||
      res.headers['set-cookie'.toLowerCase()];
    if (!raw) return;
    const lines = Array.isArray(raw) ? raw : [raw];
    for (const line of lines) {
      const part = String(line || '').split(';')[0];
      const idx = part.indexOf('=');
      if (idx <= 0) continue;
      const key = part.slice(0, idx).trim();
      const value = part.slice(idx + 1).trim();
      if (key && value) cookieJar[key] = value;
    }
  }

  function cookieHeader() {
    return Object.keys(cookieJar)
      .map((key) => key + '=' + cookieJar[key])
      .join('; ');
  }

  function isResponseOk(res, status) {
    if (res && (res.ok === true || res.ok === 1)) return true;
    if (res && (res.ok === false || res.ok === 0)) return false;
    return status >= 200 && status < 300;
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        return typeof text === 'string' ? text : '';
      } catch (_) {
        return '';
      }
    }
    return '';
  }

  async function readResponseJson(res, textBody) {
    if (textBody) {
      try {
        return JSON.parse(textBody);
      } catch (_) {}
    }
    if (res && typeof res.json === 'function') {
      try {
        return await res.json();
      } catch (_) {}
    }
    return null;
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    // Dulo API credentials, session cookies, and the dulo Referer/Origin are
    // scoped to dulo-owned hosts. Upstream CDNs hard-403 the dulo referer,
    // and the API key must never leak to third-party hosts.
    const duloOwned = isDuloOwnedHost(url);
    const baseHeaders = duloOwned
      ? defaultHeaders
      : {
          'User-Agent': USER_AGENT,
          Accept: 'video/mp4,video/*;q=0.9,application/vnd.apple.mpegurl,*/*;q=0.8',
        };
    const headers = { ...baseHeaders, ...(cfg.headers || {}) };
    if (duloOwned) {
      const cookie = cookieHeader();
      if (cookie) headers.Cookie = cookie;
    }
    const body = cfg.body == null ? null : cfg.body;

    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body, cfg.fetchOptions || undefined);
        storeCookies(res);
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        return {
          ok: isResponseOk(res, status),
          status,
          body: textBody,
          json: await readResponseJson(res, textBody),
          headers: (res && res.headers) || {},
          bodyDropped: !!(res && (res.bodyDropped === true || res.bodyDropped === 1)),
          bodyBytes: Number((res && res.bodyBytes) || 0),
        };
      }

      if (typeof fetch === 'function') {
        const res = await fetch(url, {
          method,
          headers,
          body,
          credentials: 'include',
        });
        const textBody = await res.text();
        let json = null;
        try {
          json = JSON.parse(textBody);
        } catch (_) {}
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json,
          headers: {},
          bodyDropped: false,
          bodyBytes: textBody.length,
        };
      }

      return { ok: false, status: 0, body: '', json: null };
    } catch (error) {
      log('request error: ' + (error && error.message ? error.message : String(error)));
      return { ok: false, status: 0, body: '', json: null };
    }
  }

  async function tmdbRequest(path, params) {
    const query = encodeQuery({ api_key: TMDB_KEY, ...(params || {}) });
    const url = TMDB_API + path + '?' + query;
    // Direct fetch path so we do not attach dulo API key / cookies to TMDB
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(
          url,
          { 'User-Agent': USER_AGENT, Accept: 'application/json' },
          'GET',
          null,
        );
        const status = Number((res && res.status) || 0);
        const textBody = await readResponseBody(res);
        if (status >= 200 && status < 300) {
          return (await readResponseJson(res, textBody)) || null;
        }
        return null;
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, {
          headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
        });
        if (!res.ok) return null;
        return await res.json();
      }
    } catch (error) {
      log('tmdb error: ' + (error && error.message ? error.message : String(error)));
    }
    return null;
  }

  function posterUrl(path) {
    if (!path) return '';
    return IMG_BASE + String(path);
  }

  function hrefForItem(item) {
    const type = String(item.media_type || item.type || '').toLowerCase();
    const id = Number(item.id);
    if (!id || (type !== 'movie' && type !== 'tv')) return '';
    return type + '/' + id;
  }

  function titleForItem(item) {
    return cleanText(item.title || item.name || '');
  }

  function mapSearchItem(item) {
    const href = hrefForItem(item);
    const title = titleForItem(item);
    if (!href || !title) return null;
    const poster = posterUrl(item.poster_path);
    const backdrop = item.backdrop_path
      ? IMG_BACKDROP + String(item.backdrop_path)
      : '';
    return {
      title,
      href,
      image: poster || backdrop,
      poster: poster || backdrop,
      backdrop: backdrop || poster,
      backdropUrl: backdrop || poster,
    };
  }

  function mapListResults(data, forcedMediaType, limit) {
    const max = Math.max(1, Number(limit) || 30);
    const results = Array.isArray(data && data.results) ? data.results : [];
    const out = [];
    const seen = {};
    for (let i = 0; i < results.length && out.length < max; i += 1) {
      const raw = results[i];
      if (!raw) continue;
      const mediaType =
        forcedMediaType ||
        String(raw.media_type || '').toLowerCase() ||
        (raw.title ? 'movie' : raw.name ? 'tv' : '');
      if (mediaType !== 'movie' && mediaType !== 'tv') continue;
      const item = mapSearchItem({ ...raw, media_type: mediaType });
      if (!item || !item.href || seen[item.href]) continue;
      seen[item.href] = true;
      out.push(item);
    }
    return out;
  }

  async function tmdbList(path, page) {
    const pageNum = Math.max(1, Number(page) || 1);
    return tmdbRequest(path, {
      include_adult: 'false',
      language: 'en-US',
      page: String(pageNum),
    });
  }

  async function loadFeedPage(feedId, page) {
    const feed = DISCOVERY_FEEDS[String(feedId || '').toLowerCase()];
    if (!feed) {
      return { items: [], page: Math.max(1, Number(page) || 1), hasMore: false };
    }
    const pageNum = Math.max(1, Number(page) || 1);
    const data = await tmdbList(feed.path, pageNum);
    const items = mapListResults(data, feed.mediaType, 50);
    const totalPages = Math.max(1, Number((data && data.total_pages) || 1));
    const hasMore = pageNum < totalPages && items.length > 0;
    return { items: items, page: pageNum, hasMore: hasMore };
  }

  function parseRef(input) {
    const raw = String(input || '').trim();
    if (!raw) return null;

    let value = raw
      .replace(/^https?:\/\/[^/]+\//i, '')
      .replace(/^#?\/?/, '')
      .replace(/^dulo:/i, '');

    const match = value.match(/^(movie|tv)\/(\d+)(?:\/(\d+)\/(\d+))?$/i);
    if (!match) return null;

    return {
      type: match[1].toLowerCase(),
      id: Number(match[2]),
      season: match[3] ? Number(match[3]) : null,
      episode: match[4] ? Number(match[4]) : null,
    };
  }

  function episodeHref(ref, season, episode) {
    if (ref.type === 'movie') return 'movie/' + ref.id;
    return 'tv/' + ref.id + '/' + season + '/' + episode;
  }

  async function ensureSession() {
    if (sessionReady && cookieJar.amri_session) return true;
    const res = await request(API_URL + '/session');
    if (res.ok && (cookieJar.amri_session || res.status === 200)) {
      sessionReady = true;
      return true;
    }
    // Some runtimes swallow Set-Cookie — still try sources
    if (res.ok) {
      sessionReady = true;
      return true;
    }
    log('session failed status=' + String(res.status) + ' body=' + String(res.body || '').slice(0, 120));
    return false;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeSourceUrl(url) {
    const raw = String(url || '').trim();
    if (!raw) return '';
    if (raw.startsWith('http')) return raw;
    if (raw.startsWith('/')) return BASE_URL + raw;
    return BASE_URL + '/' + raw;
  }

  function isBlockedSource(source) {
    const url = String((source && source.url) || '').toLowerCase();
    // Known dead placeholder returned by legacy node for every title
    if (url.includes('storrrrrrm.site/stream/f147603a510b345a')) return true;
    if (url.includes('tmstr1.cloudnestra.com')) return true;
    // workers.dev relays are NO LONGER blanket-filtered. Two junk classes
    // exist (302 -> placeholder YouTube; BOUND_IP_ORB block pages/art), but
    // deep verification already detects both at playlist and segment level,
    // and vidrock's sabrina proxies (a primary provider) live on workers.dev
    // and verify clean. Filter by proof, not by host.
    return false;
  }

  /** Cloudflare worker org/IP blocks show as scary image frames in the player. */
  function bodyLooksBlocked(body) {
    const text = String(body || '');
    if (!text) return false;
    const lower = text.toLowerCase();
    if (text.indexOf('BOUND_IP_ORB') >= 0) return true;
    if (lower.indexOf('not allowed to use this worker') >= 0) return true;
    if (lower.indexOf('organization is not allowed') >= 0) return true;
    if (lower.indexOf('bound_ip_orb_failed') >= 0) return true;
    // Error HTML shell often returned instead of media
    if (
      lower.indexOf('<!doctype html') >= 0 ||
      (lower.indexOf('<html') >= 0 && lower.indexOf('worker') >= 0)
    ) {
      return true;
    }
    return false;
  }

  function bodyLooksLikeMedia(body) {
    const raw = String(body || '');
    if (!raw) return false;
    if (raw.indexOf('#EXTM3U') >= 0) return true;
    // MPEG-TS sync byte 0x47 often appears as 'G' at start of TS segments
    if (raw.charCodeAt(0) === 0x47) return true;
    // ftyp box for mp4 / fragmented mp4
    if (raw.length >= 8 && raw.indexOf('ftyp') >= 4 && raw.indexOf('ftyp') < 12) {
      return true;
    }
    return false;
  }

  function bodyLooksLikeImageError(body) {
    // JPEG / PNG / GIF / WEBP magic — worker error pages ship as images.
    // Do NOT treat bare 0x47 as GIF (MPEG-TS segments also start with 0x47).
    const raw = String(body || '');
    if (!raw) return false;
    const b0 = raw.charCodeAt(0);
    const b1 = raw.length > 1 ? raw.charCodeAt(1) : 0;
    const b2 = raw.length > 2 ? raw.charCodeAt(2) : 0;
    if (b0 === 0xff && b1 === 0xd8 && b2 === 0xff) return true; // jpeg
    if (b0 === 0x89 && b1 === 0x50 && b2 === 0x4e) return true; // png
    if (raw.indexOf('GIF8') === 0) return true; // GIF87a/89a
    if (raw.slice(0, 4) === 'RIFF' && raw.indexOf('WEBP') > 0) return true;
    return false;
  }

  function firstPlaylistUri(m3u8Body, baseUrl) {
    const lines = String(m3u8Body || '').split(/\r?\n/);
    for (let i = 0; i < lines.length; i += 1) {
      const line = String(lines[i] || '').trim();
      if (!line || line.charAt(0) === '#') continue;
      if (line.indexOf('http://') === 0 || line.indexOf('https://') === 0) return line;
      try {
        // relative resolve against playlist URL
        const base = String(baseUrl || '');
        if (line.charAt(0) === '/') {
          const originMatch = base.match(/^(https?:\/\/[^/]+)/i);
          return originMatch ? originMatch[1] + line : line;
        }
        const cut = base.lastIndexOf('/');
        return cut >= 0 ? base.slice(0, cut + 1) + line : line;
      } catch (_) {
        return line;
      }
    }
    return '';
  }

  function sourceHost(url) {
    const match = String(url || '').match(/^https?:\/\/([^/]+)/i);
    return match ? String(match[1]).toLowerCase() : '';
  }

  function isDuloOwnedHost(url) {
    const host = sourceHost(url);
    return (
      host === 'dulo.tv' ||
      host.endsWith('.dulo.tv') ||
      host === 'dulo.cc' ||
      host.endsWith('.dulo.cc')
    );
  }

  function mergeSourceHeaders(source) {
    const fromSource =
      source && source.headers && typeof source.headers === 'object' ? source.headers : {};
    // Upstream CDNs (nakastream, finepulfe, senpai-stream, ...) hard-403 any
    // request carrying the dulo.tv Referer/Origin — hotlink protection aimed
    // at the aggregator — while plain API clients get 200. Only dulo-owned
    // hosts receive the dulo referer; a source's own declared headers always
    // win (relay payloads such as moviebox carry their required set).
    const headers = {
      'User-Agent': USER_AGENT,
      Accept: 'video/mp4,video/*;q=0.9,application/vnd.apple.mpegurl,*/*;q=0.8',
      Connection: 'keep-alive',
    };
    const sourceDeclaresHeaders = !!(
      fromSource.Referer ||
      fromSource.referer ||
      fromSource.Origin ||
      fromSource.origin
    );
    if (sourceDeclaresHeaders || isDuloOwnedHost(source && source.url)) {
      headers.Referer = fromSource.Referer || fromSource.referer || BASE_URL + '/';
      headers.Origin = fromSource.Origin || fromSource.origin || BASE_URL;
    }
    return { ...headers, ...fromSource };
  }

  function qualityHeight(label, source) {
    const q = String((source && source.quality) || label || '');
    const m = q.match(/(\d{3,4})\s*p/i);
    if (m) return Number(m[1]);
    return 0;
  }

  function isJayHost(url) {
    return String(url || '')
      .toLowerCase()
      .includes('jay.dulo.tv');
  }

  /**
   * savefiles-style one-shot signed URLs: every playlist/segment URL carries
   * t=<token>&s=<epoch>&e=<window> and dies (nginx 403) after a fetch or two,
   * regardless of the stated window. Verified against a live session:
   * segments that played at 02:08 403'd on the next fetch minutes later with
   * ~10h of window remaining.
   */
  function isOneShotSignedUrl(url) {
    const value = String(url || '').toLowerCase();
    return (
      /[?&]t=[^&]{8,}/.test(value) &&
      /[?&]s=\d{9,}/.test(value) &&
      /[?&]e=\d{3,}/.test(value)
    );
  }

  function isHlsSource(source) {
    const type = String((source && source.type) || '').toLowerCase();
    const url = String((source && source.url) || '').toLowerCase();
    return type === 'hls' || url.includes('.m3u8') || url.includes('mpegurl');
  }

  function scoreSource(source) {
    const url = String(source.url || '').toLowerCase();
    const type = String(source.type || '').toLowerCase();
    const title = String(source.title || '').toLowerCase();
    const provider = String(source.provider || source.providerId || '').toLowerCase();
    const height = qualityHeight(title, source);
    let score = height;

    // Deep-verified non-jay HLS is best; shallow workers.dev alone is risky (BOUND_IP_ORB)
    if (isHlsSource(source) && !isJayHost(url) && source.playableVerified) score += 320;
    else if (isHlsSource(source) && !isJayHost(url)) score += 140;
    if (url.includes('workers.dev') || url.includes('proxy.dulo')) {
      // Only boost after deep verify — bare workers often return #EXTM3U then error images
      score += source.playableVerified ? 30 : -20;
    }
    if (isJayHost(url) && (type === 'video' || url.includes('.mp4') || url.includes('/stream/'))) {
      score += source.playableVerified ? 160 : 100;
    }
    if (type === 'video' || url.includes('asset.mp4') || url.includes('.mp4')) score += 50;
    if (isHlsSource(source)) score += 40;
    if (provider === 'vidrock' || title.includes('vidapi') || title.includes('vidrock')) {
      score += source.playableVerified ? 40 : 10;
    }
    if (provider === 'vidlink' || title.includes('vidlink')) score += 25;
    if (provider === 'streamflix' || title.includes('streamflix')) score += 25;
    if (provider === 'vixsrc' || title.includes('vixsrc')) score += 15;
    if (url.includes('storrrrrrm.site')) score -= 200;
    if (url.includes('dulomomo.octadns.com')) score += 15;
    if (source.playableVerified) score += 120;
    if (source.direct || source.providerDirect) score += 15;
    return score;
  }

  /**
   * Soft-check streams. HLS must pass deep probe (variant + first segment) so we
   * never hand the app a workers.dev playlist that later paints BOUND_IP_ORB.
   * Jay MP4: light range GET when possible; never fail-closed on probe errors.
   */
  async function softVerifySource(source) {
    const url = normalizeSourceUrl(source && source.url);
    if (!url) return { ok: false, source: source };
    const headers = mergeSourceHeaders(source);

    if (isHlsSource(source)) {
      let playlistUrl = url;
      // Big VOD playlists (jay serves ~700KB single media playlists) exceed the
      // app runtime's default binary body cap, so playlist fetches raise it.
      let res = await request(playlistUrl, {
        headers: {
          ...headers,
          Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,*/*',
        },
        fetchOptions: { maxBytesHint: 4 * 1024 * 1024 },
      });
      // Do not hand the player a master or quality wrapper. Some providers
      // answer with an apparently valid #EXTM3U that contains only another
      // playlist. Follow the short chain until a real media playlist and its
      // first segment both validate, then return that media playlist.
      for (let depth = 0; depth < 4; depth += 1) {
        const playlistBody = String(res.body || '');
        if (!res.ok || bodyLooksBlocked(playlistBody) || bodyLooksLikeImageError(playlistBody)) {
          return { ok: false, source: source, reason: 'hls_blocked_or_error' };
        }
        if (playlistBody.indexOf('#EXTM3U') < 0) {
          return { ok: false, source: source, reason: 'hls_probe_fail' };
        }

        const nextUrl = firstPlaylistUri(playlistBody, playlistUrl);
        if (!nextUrl) {
          return { ok: false, source: source, reason: 'hls_empty_playlist' };
        }

        if (playlistBody.indexOf('#EXTINF') >= 0) {
          if (isOneShotSignedUrl(nextUrl)) {
            // savefiles-style one-shot segment tokens (t= token + s= epoch +
            // e= window): every URL allows only a fetch or two before nginx
            // 403s it. A probe here would burn the player's/downloader's one
            // fetch of that segment, guaranteeing a playback failure we
            // caused ourselves. Playlist structure is verified; segments are
            // trusted to the freshly signed chain.
            source.resolvedPlaylistUrl = playlistUrl;
            source.playableVerified = true;
            source.oneShotSigned = true;
            return { ok: true, source: source, soft: true };
          }
          const segment = await request(nextUrl, {
            headers: {
              ...headers,
              Range: 'bytes=0-4096',
              Accept: 'video/mp2t,video/*,application/octet-stream,*/*',
            },
            fetchOptions: { maxBytesHint: 1024 * 1024 },
          });
          const segmentBody = String(segment.body || '');
          if (!segment.ok || bodyLooksBlocked(segmentBody) || bodyLooksLikeImageError(segmentBody)) {
            return { ok: false, source: source, reason: 'hls_segment_blocked' };
          }
          if (segment.bodyDropped) {
            // Host ignored Range and flooded past the runtime body cap. The
            // 2xx status plus a large transfer still prove a live segment.
            const flooded = Number(segment.bodyBytes || 0);
            if (flooded < 64 * 1024) {
              return { ok: false, source: source, reason: 'hls_segment_unusable' };
            }
          } else if (!bodyLooksLikeMedia(segmentBody) && segmentBody.length <= 32) {
            return { ok: false, source: source, reason: 'hls_segment_unusable' };
          }
          source.resolvedPlaylistUrl = playlistUrl;
          source.playableVerified = true;
          source.deepVerified = true;
          return { ok: true, source: source };
        }

        playlistUrl = nextUrl;
        res = await request(playlistUrl, {
          headers: {
            ...headers,
            Accept: 'application/vnd.apple.mpegurl,video/*,*/*',
          },
          fetchOptions: { maxBytesHint: 4 * 1024 * 1024 },
        });
      }

      return { ok: false, source: source, reason: 'worker playlist never reached media' };
    }

    // MP4/jay: optional light probe; do not hard-fail (race validator may still drop)
    if (isOneShotSignedUrl(url)) {
      // Same one-shot token protection as the HLS branch: no probe burn.
      source.playableVerified = true;
      source.oneShotSigned = true;
      return { ok: true, source: source, soft: true };
    }
    try {
      const res = await request(url, {
        headers: {
          ...headers,
          Range: 'bytes=0-1023',
          Accept: 'video/mp4,video/*,*/*',
        },
      });
      const body = String(res.body || '');
      if (bodyLooksBlocked(body) || bodyLooksLikeImageError(body)) {
        return { ok: false, source: source, reason: 'mp4_blocked' };
      }
      if (res.ok && (bodyLooksLikeMedia(body) || body.length > 0 || res.status === 206 || res.status === 200)) {
        source.playableVerified = bodyLooksLikeMedia(body);
        return { ok: true, source: source, soft: !source.playableVerified };
      }
    } catch (_) {}
    return { ok: true, source: source, soft: true };
  }

  function rankSources(sources) {
    const list = Array.isArray(sources)
      ? sources.filter((item) => item && item.url && !isBlockedSource(item))
      : [];
    return list
      .map((source) => ({ source, score: scoreSource(source) }))
      .sort((a, b) => b.score - a.score)
      .map((row) => row.source);
  }

  function mergeUniqueSources(lists) {
    const seen = {};
    const out = [];
    for (let i = 0; i < lists.length; i += 1) {
      const list = lists[i];
      if (!Array.isArray(list)) continue;
      for (let j = 0; j < list.length; j += 1) {
        const source = list[j];
        const key = String((source && source.url) || '');
        if (!key || seen[key]) continue;
        seen[key] = true;
        out.push(source);
      }
    }
    return out;
  }

  function mapSubtitles(source) {
    const rows = Array.isArray(source && source.subtitles) ? source.subtitles : [];
    return rows
      .map((row) => {
        const url = String((row && row.url) || '').trim();
        if (!url) return null;
        return {
          url,
          language: cleanText(row.language || row.lang || 'und'),
          label: cleanText(row.language || row.lang || 'Sub'),
          format: cleanText(row.format || 'vtt'),
        };
      })
      .filter(Boolean);
  }

  function streamTypeForSource(source) {
    const type = String(source.type || '').toLowerCase();
    const url = String(source.url || '').toLowerCase();
    if (type === 'hls' || url.includes('.m3u8')) return 'hls';
    return 'mp4';
  }

  function labelForSource(source) {
    const height = qualityHeight(source.title, source);
    let base = cleanText(source.title || source.providerName || source.provider || 'Stream');
    const provider = cleanText(source.providerName || source.provider || '');
    if (provider && base.toLowerCase().indexOf(provider.toLowerCase()) < 0) {
      base = provider + ' - ' + base;
    }
    if (height && base.indexOf(String(height)) < 0) base = base + ' ' + height + 'p';
    return base || 'Stream';
  }

  async function fetchProviderSources(ref, provider) {
    const params = {
      type: ref.type,
      provider: provider,
      tmdb: String(ref.id),
    };
    if (ref.type === 'tv') {
      params.season = String(ref.season || 1);
      params.episode = String(ref.episode || 1);
    }
    const url = API_URL + '/sources/call?' + encodeQuery(params);
    const res = await request(url);
    if (!res.ok || !res.json) {
      return { sources: [], provider: provider, reason: 'request_failed', status: res.status };
    }
    const sources = Array.isArray(res.json.sources) ? res.json.sources : [];
    // tag provider for ranking
    for (let i = 0; i < sources.length; i += 1) {
      if (sources[i] && !sources[i].provider) sources[i].provider = provider;
    }
    return {
      sources,
      provider: res.json.provider || provider,
      node: res.json.node || '',
      reason: res.json.reason || res.json.error || '',
      status: res.status,
    };
  }

  function parseSourceEvents(body) {
    const sources = [];
    const seen = {};
    const blocks = String(body || '').replace(/\r\n/g, '\n').split(/\n\n+/);
    for (let i = 0; i < blocks.length; i += 1) {
      const block = blocks[i];
      const eventMatch = block.match(/^event:\s*([^\n]+)/m);
      if (!eventMatch || String(eventMatch[1]).trim() !== 'sources') continue;
      const dataMatch = block.match(/^data:\s*(.+)$/m);
      if (!dataMatch) continue;
      let payload = null;
      try {
        payload = JSON.parse(dataMatch[1]);
      } catch (_) {
        continue;
      }
      const rows = Array.isArray(payload && payload.sources) ? payload.sources : [];
      for (let j = 0; j < rows.length; j += 1) {
        const source = rows[j];
        const url = String(source && source.url || '').trim();
        if (!url || seen[url]) continue;
        seen[url] = true;
        sources.push(source);
      }
    }
    return sources;
  }

  async function fetchLiveSources(ref) {
    const payload = ref.type === 'tv'
      ? { type: 'tv', tmdbId: ref.id, season: ref.season || 1, episode: ref.episode || 1 }
      : { type: 'movie', tmdbId: ref.id };
    const res = await request(API_URL + '/source', {
      method: 'POST',
      headers: {
        Accept: 'text/event-stream',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok || !res.body) {
      log('live source request failed status=' + String(res.status));
      return { sources: [], reason: 'live_source_request_failed', status: res.status };
    }
    const parsed = parseSourceEvents(res.body);
    log(
      'live source emit sources=' +
        String(parsed.length) +
        ' bytes=' +
        String(String(res.body || '').length) +
        (parsed.length ? '' : ' head=' + String(res.body || '').slice(0, 120)),
    );
    return { sources: parsed, reason: '', status: res.status };
  }

  async function fetchLegacySources(ref) {
    let url = API_URL + '/sources?tmdb=' + encodeURIComponent(String(ref.id)) + '&smart=1';
    if (ref.type === 'tv') {
      url +=
        '&season=' +
        encodeURIComponent(String(ref.season || 1)) +
        '&episode=' +
        encodeURIComponent(String(ref.episode || 1));
    }
    const res = await request(url);
    if (!res.ok || !res.json) return [];
    return Array.isArray(res.json.sources) ? res.json.sources : [];
  }

  async function fetchAnimeSources(anilistId, episode) {
    const url =
      API_URL +
      '/sources/anime?anilist=' +
      encodeURIComponent(String(anilistId)) +
      '&episode=' +
      encodeURIComponent(String(episode || 1));
    const res = await request(url);
    if (!res.ok || !res.json) return [];
    return Array.isArray(res.json.sources) ? res.json.sources : [];
  }

  function hasReliableCandidate(sources) {
    const list = Array.isArray(sources) ? sources : [];
    // Deep-verified non-jay HLS, or any mix of several diverse hosts
    return list.some((s) => s && s.url && s.deepVerified && isHlsSource(s) && !isJayHost(s.url));
  }

  async function findFastVerifiedHls(sources, timeoutMs) {
    // Dulo's worker HLS routes can look healthy until their first segment is
    // requested. Verify a small, high-priority wave before asking every
    // provider. A verified result is safe to hand straight to the player and
    // avoids spending 15–25 seconds validating lower-ranked fallbacks.
    const candidates = rankSources(sources)
      .filter((source) => isHlsSource(source) && !isJayHost(source.url))
      .slice(0, 2);
    if (!candidates.length) return [];

    const checks = await Promise.all(
      candidates.map((source) =>
        settleWithin(softVerifySource(source), timeoutMs || VERIFY_TIMEOUT_MS, {
          ok: false,
          source,
          reason: 'verify_timeout',
        }),
      ),
    );
    const verified = checks
      .filter((check) => check && check.ok && check.source && check.source.deepVerified)
      .map((check) => check.source);
    if (verified.length) {
      log('fast verified HLS wave found ' + String(verified.length) + ' playable route(s)');
    }
    return rankSources(verified);
  }

  async function collectSources(ref, liveWaitMs) {
    await ensureSession();
    const startedAt = Date.now();
    const remainingMs = () => Math.max(0, RESOLVER_DEADLINE_MS - (Date.now() - startedAt));

    // Dulo's browser now resolves sources through one session-backed SSE call.
    // Keep the legacy per-provider API only as a bounded compatibility fallback.
    // Observed emit latency ranges 0.2s (cached) to ~12s under load, so the
    // first attempt gets a wider window than the old flat 11s cap.
    const live = await settleWithin(
      fetchLiveSources(ref),
      Math.min(liveWaitMs || 11000, remainingMs()),
      { sources: [], reason: 'live_source_timeout', status: 0 },
    );
    const liveSources = Array.isArray(live && live.sources) ? live.sources : [];
    if (liveSources.length) {
      const verified = await findFastVerifiedHls(
        rankSources(liveSources),
        Math.min(VERIFY_TIMEOUT_MS, remainingMs()),
      );
      if (verified.length) return verified;
    }

    const providers = ref.type === 'tv' ? TV_PROVIDERS : MOVIE_PROVIDERS;
    const collected = liveSources.length ? [liveSources] : [];
    // Start with the highest-value providers. If one produces a fully
    // verified non-worker HLS route, return it immediately. The expanded
    // provider sweep below remains the recovery path for titles where this
    // first wave is unavailable or blocked.
    // Two provider waves are enough to find a normal direct route. Further
    // sources are a later retry, not work that should block this playback.
    const maxProviders = Math.min(providers.length, 4);

    for (let i = 0; i < maxProviders; i += 2) {
      if (remainingMs() < 500) break;
      const batch = providers.slice(i, i + 2);
      const results = await settleWithin(
        Promise.all(batch.map((provider) => fetchProviderSources(ref, provider))),
        Math.min(PROVIDER_WAVE_TIMEOUT_MS, remainingMs()),
        [],
      );
      for (let r = 0; r < results.length; r += 1) {
        if (results[r].sources && results[r].sources.length) {
          collected.push(results[r].sources);
        }
      }
      const ranked = rankSources(mergeUniqueSources(collected));
      const fastVerified = await findFastVerifiedHls(
        ranked,
        Math.min(VERIFY_TIMEOUT_MS, remainingMs()),
      );
      if (fastVerified.length) return fastVerified;
      if (hasReliableCandidate(ranked)) break;
      // Also stop if we already have several candidates and scanned enough providers
      if (ranked.length >= 4 && i >= 3) break;
    }

    // Legacy smart endpoint last (often placeholder — filtered by isBlockedSource)
    const legacy = remainingMs() > 500
      ? await settleWithin(fetchLegacySources(ref), Math.min(PROVIDER_WAVE_TIMEOUT_MS, remainingMs()), [])
      : [];
    if (legacy.length) collected.push(legacy);

    if (ref.type === 'tv' && remainingMs() > 500 && rankSources(mergeUniqueSources(collected)).length < 1) {
      try {
        const ext = await settleWithin(
          tmdbRequest('/tv/' + ref.id + '/external_ids'),
          Math.min(PROVIDER_WAVE_TIMEOUT_MS, remainingMs()),
          null,
        );
        const anilist = ext && (ext.anilist_id || ext.anilist);
        if (anilist) {
          const animeSources = await settleWithin(
            fetchAnimeSources(anilist, ref.episode || 1),
            Math.min(PROVIDER_WAVE_TIMEOUT_MS, remainingMs()),
            [],
          );
          if (animeSources.length) collected.push(animeSources);
        }
      } catch (_) {}
    }

    let ranked = rankSources(mergeUniqueSources(collected));

    // Recovery path: deep-check HLS until the first verified safe route. The
    // old loop always checked four HLS routes and two MP4s, even after a
    // playable route had already been found.
    const verified = [];
    const softOk = [];
    const rest = [];
    let hlsChecked = 0;
    let mp4Checked = 0;
    for (let i = 0; i < ranked.length && i < 10; i += 1) {
      if (remainingMs() < 500) break;
      const src = ranked[i];
      if (isHlsSource(src) && hlsChecked < 4) {
        hlsChecked += 1;
        const check = await settleWithin(
          softVerifySource(src),
          Math.min(VERIFY_RECOVERY_TIMEOUT_MS, remainingMs()),
          { ok: false, source: src, reason: 'verify_timeout' },
        );
        if (check.ok && check.source.deepVerified) {
          verified.push(check.source);
          log('recovery verified HLS after ' + String(hlsChecked) + ' HLS check(s)');
          break;
        } else if (check.ok) {
          softOk.push(check.source);
        } else if (
          check.reason === 'hls_blocked_or_error' ||
          check.reason === 'hls_segment_blocked' ||
          check.reason === 'worker playlist never reached media'
        ) {
          // Drop proven worker org/IP blocks (BOUND_IP_ORB scary frame)
          log('drop blocked HLS: ' + String(check.reason));
        } else {
          // Network/probe flake — keep as untrusted backup
          log('recovery soft-fail HLS: ' + String(check.reason || 'unknown'));
          softOk.push(src);
        }
        continue;
      }
      if (!isHlsSource(src) && mp4Checked < 2) {
        mp4Checked += 1;
        const check = await settleWithin(
          softVerifySource(src),
          Math.min(VERIFY_RECOVERY_TIMEOUT_MS, remainingMs()),
          { ok: false, source: src, reason: 'verify_timeout' },
        );
        if (check.ok && check.source.playableVerified) verified.push(check.source);
        else if (check.ok) softOk.push(check.source);
        else rest.push(src);
        continue;
      }
      rest.push(src);
    }
    for (let i = 10; i < ranked.length; i += 1) rest.push(ranked[i]);

    // A bare jay URL is not a usable fallback on iOS. Returning no stream is
    // preferable to making the player wait on a source the app cannot open.
    ranked = rankSources(verified.concat(softOk).concat(rest)).filter(
      (source) => source.deepVerified || (source.playableVerified && !isJayHost(source.url)),
    );
    log(
      'collectSources finished in ' +
        String(Date.now() - startedAt) +
        'ms routes=' +
        String(ranked.length),
    );
    return ranked;
  }

  function interleaveLists(primary, secondary, limit) {
    const out = [];
    const max = Math.max(primary.length, secondary.length);
    for (let i = 0; i < max && out.length < limit; i++) {
      if (i < primary.length) out.push(primary[i]);
      if (out.length < limit && i < secondary.length) out.push(secondary[i]);
    }
    return out;
  }

  async function searchResults(query) {
    const term = String(query == null ? '' : query).trim();
    await ensureSession();

    if (!term) {
      const [tvTrend, movieTrend] = await Promise.all([
        tmdbRequest('/trending/tv/week', { include_adult: 'false' }),
        tmdbRequest('/trending/movie/week', { include_adult: 'false' }),
      ]);
      const tv = (Array.isArray(tvTrend && tvTrend.results) ? tvTrend.results : [])
        .map((item) => mapSearchItem({ ...item, media_type: item.media_type || 'tv' }))
        .filter(Boolean);
      const movies = (Array.isArray(movieTrend && movieTrend.results) ? movieTrend.results : [])
        .map((item) => mapSearchItem({ ...item, media_type: item.media_type || 'movie' }))
        .filter(Boolean);
      return interleaveLists(tv, movies, 30);
    }

    const data = await tmdbRequest('/search/multi', {
      query: term,
      include_adult: 'false',
      page: '1',
    });
    const results = Array.isArray(data && data.results) ? data.results : [];
    return results
      .filter((item) => item && (item.media_type === 'movie' || item.media_type === 'tv'))
      .map(mapSearchItem)
      .filter(Boolean)
      .slice(0, 30);
  }

  async function extractDetails(urlOrId) {
    const ref = parseRef(urlOrId);
    if (!ref) {
      return { title: 'Unknown', description: 'No description available.' };
    }

    await ensureSession();
    const path = ref.type === 'movie' ? '/movie/' + ref.id : '/tv/' + ref.id;
    const data = await tmdbRequest(path);
    if (!data) {
      return { title: String(urlOrId), description: 'No description available.' };
    }

    const title = cleanText(data.title || data.name || String(urlOrId));
    const description = cleanText(data.overview || 'No description available.');
    const year = String(
      (data.release_date || data.first_air_date || '').slice(0, 4) || data.year || '',
    );

    return {
      title,
      description,
      airdate: year,
      image: posterUrl(data.poster_path),
    };
  }

  async function extractEpisodes(seriesId) {
    const ref = parseRef(seriesId);
    if (!ref) return [];

    if (ref.type === 'movie') {
      return [
        {
          number: 1,
          href: 'movie/' + ref.id,
          title: 'Movie',
          isMovie: true,
          mediaType: 'movie',
          subAvailable: true,
          dubAvailable: false,
        },
      ];
    }

    const show = await tmdbRequest('/tv/' + ref.id);
    if (!show || !Array.isArray(show.seasons)) return [];

    const episodes = [];
    const seasons = show.seasons
      .filter((season) => season && Number(season.season_number) > 0)
      .sort((a, b) => Number(a.season_number) - Number(b.season_number));

    for (const season of seasons) {
      const seasonNumber = Number(season.season_number);
      if (!Number.isFinite(seasonNumber) || seasonNumber <= 0) continue;

      const seasonData = await tmdbRequest('/tv/' + ref.id + '/season/' + seasonNumber);
      const rows = Array.isArray(seasonData && seasonData.episodes) ? seasonData.episodes : [];
      for (const row of rows) {
        const episodeNumber = Number(row.episode_number);
        if (!Number.isFinite(episodeNumber) || episodeNumber <= 0) continue;
        episodes.push({
          number: episodeNumber,
          season: seasonNumber,
          href: episodeHref(ref, seasonNumber, episodeNumber),
          title: cleanText(row.name || 'S' + seasonNumber + 'E' + episodeNumber),
          subAvailable: true,
          dubAvailable: false,
        });
      }
    }

    episodes.sort((a, b) => {
      const seasonDelta = Number(a.season || 1) - Number(b.season || 1);
      if (seasonDelta !== 0) return seasonDelta;
      return Number(a.number) - Number(b.number);
    });

    return episodes;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseRef(episodeHref);
    if (!ref) return { streams: [] };

    const playbackRef = {
      type: ref.type,
      id: ref.id,
      season: ref.type === 'tv' ? ref.season || 1 : null,
      episode: ref.type === 'tv' ? ref.episode || 1 : null,
    };

    let sources = await collectSources(playbackRef, 13000);
    if (!sources.length) {
      // one retry after re-session; repeat emits are usually cached and fast
      sessionReady = false;
      await sleep(400);
      await ensureSession();
      sources = await collectSources(playbackRef, 8000);
    }

    if (!sources.length) {
      log('extractStreamUrl no sources for ' + episodeHref);
      return { streams: [] };
    }

    // Deep-verified HLS first, then soft HLS, then jay/other MP4 backups.
    // Entries are objects so every route carries its own request headers:
    // the app merges per-entry headers into each quality option and download
    // source, so a jay fallback never inherits nakastream headers (or the
    // reverse) — flat label/url pairs can only carry one shared header set.
    const top = sources.slice(0, 10);
    const entries = [];
    const seenLabels = {};
    let primaryHeaders = null;
    let primaryType = 'mp4';
    let primarySubs = [];

    function pushSource(source) {
      const streamUrl = normalizeSourceUrl(source.resolvedPlaylistUrl || source.url);
      if (!streamUrl) return;
      const label = labelForSource(source);
      const dedupeKey = label + '|' + (isJayHost(streamUrl) ? 'jay' : streamUrl.split('?')[0]);
      if (seenLabels[dedupeKey]) return;
      seenLabels[dedupeKey] = true;
      const headers = mergeSourceHeaders(source);
      entries.push({ label: label, url: streamUrl, headers: headers });
      if (!primaryHeaders) {
        primaryHeaders = headers;
        primaryType = streamTypeForSource(source);
        primarySubs = mapSubtitles(source);
      }
    }

    // Pass 1: deep-verified HLS (safe for player)
    for (let i = 0; i < top.length; i += 1) {
      const source = top[i];
      if (source.deepVerified && isHlsSource(source)) pushSource(source);
    }
    // Pass 2: other non-jay HLS
    for (let i = 0; i < top.length; i += 1) {
      const source = top[i];
      if (isHlsSource(source) && !isJayHost(source.url)) pushSource(source);
    }
    // Pass 3: jay / MP4 backups (race may drop some; still useful after HLS fail)
    for (let i = 0; i < top.length && entries.length < 14; i += 1) {
      pushSource(top[i]);
    }

    if (!entries.length) return { streams: [] };

    const preferred = String(lang || '').toLowerCase() === 'dub' ? 'dub' : 'sub';
    // Prefer dub/sub labelled source if present
    for (let i = 0; i < entries.length; i += 1) {
      const lab = String(entries[i].label || '').toLowerCase();
      if (preferred === 'dub' && lab.includes('dub')) {
        const picked = entries.splice(i, 1)[0];
        entries.unshift(picked);
        break;
      }
      if (preferred === 'sub' && (lab.includes('sub') || !lab.includes('dub'))) {
        break;
      }
    }

    const out = {
      streams: entries,
      headers: primaryHeaders || {
        'User-Agent': USER_AGENT,
        Referer: BASE_URL + '/',
        Origin: BASE_URL,
      },
      quality: 'auto',
      lang: preferred,
      streamType: primaryType,
    };
    if (primarySubs.length) out.subtitles = primarySubs;

    log(
      'extractStreamUrl href=' +
        episodeHref +
        ' streams=' +
        String(entries.length) +
        ' first=' +
        String(entries[0].label),
    );
    return out;
  }

  /**
   * Discovery V1 — Netflix-style home + endless feed scroll.
   * Catalog is pure TMDB (no Dulo session). Must finish well under app 8s timeout.
   * Regression note: v4.0.1–4.0.2 awaited ensureSession + sequential TMDB batches
   * and often completed AFTER the app TimeoutException, falling back to legacy.
   */
  async function discoveryHome() {
    // Do NOT await ensureSession here — TMDB does not need dulo cookies, and the
    // session hop alone can burn most of the 8s budget on mobile JS bridge.
    const started = Date.now();

    // One parallel wave only (6 lists). "upcoming" lives on feed, not home.
    const lists = await Promise.all([
      tmdbList('/trending/movie/week', 1),
      tmdbList('/trending/tv/week', 1),
      tmdbList('/movie/popular', 1),
      tmdbList('/tv/popular', 1),
      tmdbList('/movie/now_playing', 1),
      tmdbList('/tv/on_the_air', 1),
    ]);

    const trendMovie = lists[0];
    const trendTv = lists[1];
    const popularMovie = lists[2];
    const popularTv = lists[3];
    const nowPlaying = lists[4];
    const onTheAir = lists[5];

    const sections = [];
    const usedHrefs = {};

    function takeUnique(items, limit) {
      const out = [];
      for (let i = 0; i < (items || []).length && out.length < limit; i += 1) {
        const item = items[i];
        if (!item || !item.href || usedHrefs[item.href]) continue;
        usedHrefs[item.href] = true;
        out.push(item);
      }
      return out;
    }

    const heroItems = takeUnique(mapListResults(trendMovie, 'movie', 20), 8);
    if (heroItems.length) {
      sections.push({
        id: 'spotlight',
        title: 'Spotlight',
        style: 'hero',
        items: heroItems,
      });
    }

    const top10 = takeUnique(mapListResults(trendTv, 'tv', 20), 10);
    if (top10.length) {
      sections.push({
        id: 'trending_tv',
        title: 'Trending TV',
        style: 'top10',
        items: top10,
        viewAll: { mode: 'feed', feedId: 'trending_tv' },
      });
    }

    const popMovies = takeUnique(mapListResults(popularMovie, 'movie', 30), 20);
    if (popMovies.length) {
      sections.push({
        id: 'popular_movie',
        title: 'Popular Movies',
        style: 'poster',
        items: popMovies,
        viewAll: { mode: 'feed', feedId: 'popular_movie' },
      });
    }

    const popTv = takeUnique(mapListResults(popularTv, 'tv', 30), 20);
    if (popTv.length) {
      sections.push({
        id: 'popular_tv',
        title: 'Popular TV Shows',
        style: 'poster',
        items: popTv,
        viewAll: { mode: 'feed', feedId: 'popular_tv' },
      });
    }

    const theaters = takeUnique(mapListResults(nowPlaying, 'movie', 30), 18);
    if (theaters.length) {
      sections.push({
        id: 'now_playing',
        title: 'In Theaters',
        style: 'poster',
        items: theaters,
        viewAll: { mode: 'feed', feedId: 'now_playing' },
      });
    }

    const airing = takeUnique(mapListResults(onTheAir, 'tv', 30), 18);
    if (airing.length) {
      sections.push({
        id: 'on_the_air',
        title: 'On The Air',
        style: 'poster',
        items: airing,
        viewAll: { mode: 'feed', feedId: 'on_the_air' },
      });
    }

    // Trending movies row (hero may have consumed some hrefs)
    const moreTrendMovies = takeUnique(mapListResults(trendMovie, 'movie', 30), 16);
    if (moreTrendMovies.length) {
      sections.push({
        id: 'trending_movie',
        title: 'Trending Movies',
        style: 'poster',
        items: moreTrendMovies,
        viewAll: { mode: 'feed', feedId: 'trending_movie' },
      });
    }

    // Optional slower rows only if we still have budget (<5s used)
    if (Date.now() - started < 5000) {
      try {
        const extra = await Promise.all([
          tmdbList('/movie/top_rated', 1),
          tmdbList('/tv/top_rated', 1),
        ]);
        const ratedMovies = takeUnique(mapListResults(extra[0], 'movie', 30), 16);
        if (ratedMovies.length) {
          sections.push({
            id: 'top_rated_movie',
            title: 'Top Rated Movies',
            style: 'poster',
            items: ratedMovies,
            viewAll: { mode: 'feed', feedId: 'top_rated_movie' },
          });
        }
        const ratedTv = takeUnique(mapListResults(extra[1], 'tv', 30), 16);
        if (ratedTv.length) {
          sections.push({
            id: 'top_rated_tv',
            title: 'Top Rated TV',
            style: 'poster',
            items: ratedTv,
            viewAll: { mode: 'feed', feedId: 'top_rated_tv' },
          });
        }
      } catch (_) {}
    }

    if (!sections.length) {
      throw new Error('Discovery home returned no sections');
    }

    // Contract: max 12 sections
    const trimmed = sections.slice(0, 12);
    log(
      'discoveryHome sections=' +
        String(trimmed.length) +
        ' ms=' +
        String(Date.now() - started),
    );
    return { sections: trimmed };
  }

  async function discoveryFeed(feedId, page) {
    // Pure TMDB — no Dulo session required
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const id = String(feedId || '').toLowerCase().trim();

    if (!DISCOVERY_FEEDS[id]) {
      log('discoveryFeed unknown feedId=' + id);
      return { items: [], page: pageNum, hasMore: false };
    }

    const result = await loadFeedPage(id, pageNum);
    log(
      'discoveryFeed id=' +
        id +
        ' page=' +
        String(pageNum) +
        ' items=' +
        String(result.items.length) +
        ' hasMore=' +
        String(result.hasMore),
    );
    return result;
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      searchResults,
      extractDetails,
      extractEpisodes,
      extractStreamUrl,
      discoveryHome,
      discoveryFeed,
    };
  }
})();
